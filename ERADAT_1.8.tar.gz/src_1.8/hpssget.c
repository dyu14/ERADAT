#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include "hpssget.h"

int debug=0;

#define MAX_LOOP 5

void error(char *msg)
{
	perror(msg);
	exit(1);
}

int full_write(int fd, char *buf, size_t size)
{
	ssize_t written = 0;
	ssize_t this_write = 0;

	while(written < size)	{
		this_write = write(fd, buf, size - written);
		if(this_write < 0)
			return -1;
		written += this_write;
	}
	return 0;
}

int main(int argc, char *argv[])
{
	int sockfd, portno, n, terminated=0;
	struct sockaddr_in serv_addr;
	struct hostent *server;
	int count = 0, retry = 0;
	size_t added = 0;

	if (debug) printf("%s\n", argv[0]);

	char buffer[MAX_BUFFER_LEN];
	if (argc < 3) {
		fprintf(stderr, "%s Version %s\n", argv[0], HPSS_GET_ATTR_VERSION);
		fprintf(stderr,"usage %s hostname port plugin [args]\n", argv[0]);
		exit(0);
	}
	portno = atoi(argv[2]);
	if (debug) printf("Create socket\n");
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
		error("ERROR opening socket");

	if (debug) printf("Server: %s\n", argv[1]);
	server = gethostbyname(argv[1]);
	if (server == NULL) {
		fprintf(stderr,"ERROR, no such host\n");
		exit(0);
	}

	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	bcopy((char *)server->h_addr,
		  (char *)&serv_addr.sin_addr.s_addr,
		  server->h_length);
	serv_addr.sin_port = htons(portno);
	if (debug) printf("Connecting to %s\n", argv[1]);
	if (connect(sockfd,(const struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0)
		error("ERROR connecting");

	bzero(buffer,MAX_BUFFER_LEN);
	if (debug) printf("Connected, hand shacking\n");
	sprintf( buffer, "%s %s", HPSSGET_HANDSHAKE, HPSS_GET_ATTR_VERSION);
	if (debug) printf("Sending %s\n", buffer);

	if(full_write(sockfd, buffer, strlen(buffer)) < 0)
		error("ERROR writing handshake");

	bzero(buffer,MAX_BUFFER_LEN);

	/* To avoid a buffer overrun if arg-list is huge */
	added = 0;
	for (n = 3; n < argc; n++)	{
		added += strlen(argv[n]);
		strncat(buffer, argv[n], MAX_BUFFER_LEN - added);
		added += 1;
		strncat(buffer, " ", MAX_BUFFER_LEN - added);
	}

	if (debug) printf("Sending %s\n", buffer);

	retry = 0;
	while (retry < 5) {
		retry++;
		if(full_write(sockfd,buffer,strlen(buffer)) < 0)	{
			char msg[64];
			sprintf(msg, "ERROR writing to socket, retry %d\n", retry);
			error(msg);
                sleep(1);
		} else
			break;
	}

	count = 0;
	while (! terminated && count < MAX_LOOP) {
		int idx, cmd_token, *ch;
		char *token;

		bzero(buffer,MAX_BUFFER_LEN);
		if (debug) printf("Reading from socket\n");
		n = read(sockfd, buffer, MAX_BUFFER_LEN);

		if (n > 0) {
			if (debug) printf("buffer=[%s], %d bytes, n=%d\n", buffer, strlen(buffer), n);
			if (debug) printf("HPSSGET_CMD_TERMINATE=[%s]\n", HPSSGET_CMD_TERMINATE);
			cmd_token = 0;
			token = (char *)strtok(buffer, "|");
			while (token && cmd_token < 5) {
				cmd_token++;

				if (!strcmp(token, "COMPLETED")) {
					terminated = 1;
				} else
					printf("%s\n",token);

				if (cmd_token == 10)
					printf("Too many token, forced termination.\n");
				token = (char *)strtok(NULL, "|");
			}
		}
		count++;
	}
	close(sockfd);
	return 0;
}
