#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include <pwd.h>
#include <signal.h>
#include <sys/stat.h>
#include <pthread.h>

#include "u_signed64.h"
#include "hpss_api.h"
#include "hpss_queue.h"
#include "common.h"
#include "batch.h"
#include "thread_utils.h"
#include "batch_utils.h"
#include "dbutils.h"
#include "ns_Constants.h"
#include "hpss_get_attr.h"

char replay_file;
int stage_opt = 0;

void usage(char *progname)
{
    printf("Syntax error: INVALID ARGUMENTS\n");
    printf("    %s <username> <port number>\n", progname);
}

int Sigpipe_caught;
void pipe_handler(int status)
{
  printf("Received signal SIGPIPE\n");
  Sigpipe_caught = 1;
}

void sigHand(int status)
{
   printf("Received signal %d, processing unregist...\n", status);
   switch(status) {
   case SIGPIPE:
       printf("Reset signal %d\n", status);
       signal(SIGPIPE, sigHand);
       break;
   default:
       if (registed_client) {
           local_dbutils_unreg();
       }
   }
   exit(1);
}

void error(char *msg)
{
    perror(msg);
    exit(1);
}

int srv_init(int portno)
{
     int sockfd;
     struct sockaddr_in serv_addr;
     int opt=1;

     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0)
        error("ERROR opening socket");

     setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,
              (char *)&opt,sizeof(opt));

     bzero((char *) &serv_addr, sizeof(serv_addr));
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;
     serv_addr.sin_port = htons(portno);
     if (bind(sockfd, (struct sockaddr *) &serv_addr,
              sizeof(serv_addr)) < 0)
              error("ERROR on binding");

     return sockfd;
}

void show_status( char *stat_str)
{
     printf("%s\n", stat_str);
}

void show_timestamp()
{
     time_t now;
     struct tm ltime;

     now = time((time_t *)NULL);
     localtime_r(&now,&ltime);
     printf("%02d/%02d/%04d-%02d:%02d:%02d| ",
             ltime.tm_mon+1, ltime.tm_mday, ltime.tm_year+1900,
             ltime.tm_hour, ltime.tm_min, ltime.tm_sec );
}

int request_handle(int newsockfd, struct sockaddr_in *cli_addr)
{
     int peer_len, buffer_len, status, srv_run = 1;
     struct hostent *host;
     struct sockaddr_in peer;
     char *token;
     char line[MAX_BUFFER_LEN];
     char buffer[MAX_BUFFER_LEN];
     fstruct_t hpss_fs;

     Sigpipe_caught = 0;

     peer_len = sizeof(struct sockaddr);

     /** GET PEER HOSTNAME **/
     if ((host = gethostbyaddr((char *) &(cli_addr->sin_addr),
         sizeof(cli_addr->sin_addr), AF_INET)) == NULL) {
         perror("gethostbyaddr");
     }

     /* HAND SHAKE */
     bzero(line,MAX_BUFFER_LEN);
     sprintf( line, "%s %s", HPSSGET_HANDSHAKE, HPSS_GET_ATTR_VERSION);

     bzero(buffer, MAX_BUFFER_LEN);
     buffer_len = read(newsockfd, buffer, strlen(line));
     if (buffer_len < 0) error("ERROR reading from socket");

     if (!memcmp(buffer, "SHUTDOWN", 8)) {
         printf("Received SHUTDOWN request from %s\n", host->h_name);
         srv_run = 0;
         return (srv_run);
     }

     /* get filename */
     if (strcmp(buffer, line)) {
         printf("Incompetible version: %s\0", buffer);
         bzero(buffer, MAX_BUFFER_LEN);
         sprintf(buffer, "Incompetible version, please ungrade to %s\n", line);
         printf("%s\n", buffer);
         if (!Sigpipe_caught) {
             buffer_len = write(newsockfd, buffer, strlen(buffer));
             if (buffer_len < 0) {
                 return (srv_run);
             }
         }

         bzero(buffer, MAX_BUFFER_LEN);
         if (!Sigpipe_caught) {
             buffer_len = write(newsockfd, HPSSGET_CMD_TERMINATE, strlen(HPSSGET_CMD_TERMINATE));
             if (buffer_len < 0) {
                 return (srv_run);
             }
         }
     }
     else {

         bzero(buffer,MAX_BUFFER_LEN);

         /** READ REQUEST **/
         buffer_len = read(newsockfd, buffer, MAX_BUFFER_LEN);
         if (buffer_len < 0) error("ERROR reading from socket");
         if (host) 
             printf("%s %s|", host->h_name, buffer);
         else {
             printf("UNKNOWN HOST %s|", buffer);
         }

         log_access(imp_user, host->h_name);

         /** PROCESS COMMAND **/
         /* get command */
         token = strtok(buffer, " ");

         if (!token) {
             printf("Invalid requested, dropping request\n");
             return(srv_run);
         }

         hpss_fs.feature = 0;
         if (!strcmp(token, "tapeid"))
             hpss_fs.feature = 1;
         if (!strcmp(token, "statx"))
             hpss_fs.feature = 2;
         if (!strcmp(token, "level"))
             hpss_fs.feature = 3;
         if (!strcmp(token, "tapeids"))
             hpss_fs.feature = 4;
         if (!strcmp(token, "cos"))
             hpss_fs.feature = 5;
         if (!strcmp(token, "mediatype"))
             hpss_fs.feature = 6;

         token = strtok(NULL, " ");
         if (!token) {
             printf("Invalid requested, dropping request\n");
             return(srv_run);
         }

         hpss_fs.filename = (char *) strdup(token);

         token = strtok(NULL, " ");
         if(token && !strcmp(token, "-i"))
             hpss_fs.chkbadtape = 1;
         else
             hpss_fs.chkbadtape = 0;

         if (debug) printf("Calling process_request\n");
         status = process_request(&hpss_fs, newsockfd);
         if (debug) printf("End process_request\n");

         /** REQUEST COMPLETED **/
         bzero(buffer,MAX_BUFFER_LEN);
         strcpy(buffer, HPSSGET_CMD_TERMINATE);
         if (!Sigpipe_caught) {
             if (debug) printf("Sending Termination String\n");
             buffer_len = write(newsockfd, buffer, strlen(buffer));
         }
         if (debug) printf("Request is completed\n");
    
         free(hpss_fs.filename);
    }
    return (srv_run);
}

void permission2str(unsigned32 Perm, char *perm)
{
   char ch = ' ';

   if ( !perm )
       return;

   if ( Perm & HPSS_PERM_READ ) ch='r'; else ch='-';
   perm[0]=ch;
   if ( Perm & HPSS_PERM_WRITE ) ch='w'; else ch='-';
   perm[1]=ch;
   if ( Perm & HPSS_PERM_EXEC ) ch='x'; else ch='-';
   perm[2]=ch;
   perm[3]='\0';
}

int process_request(fstruct_t *hpss_fs, int sockfd)
{
   int status, buffer_len, i;
   char buffer[MAX_BUFFER_LEN], tmp_buf[512];

   if (debug) printf("Entering process_request\n");
   if (hpss_fs->filename) {
       if (debug) printf("DEBUG: %s|%d\n", __FILE__, __LINE__);
       status = get_file_attr(hpss_fs);
       if (debug) printf("DEBUG: %s|%d\n", __FILE__, __LINE__);

       bzero(buffer,MAX_BUFFER_LEN);
       if (status == 0 || hpss_fs->ftype == 'd') {
             if (hpss_fs->chkbadtape) {
                 if (chk_tape_stat(hpss_fs->volnum[0]) == 1) {
                   status = -ENOENT;
                 }
             }
             if (hpss_fs->ftype == 'd') {
                 status = -EISDIR;
             }

             buffer[0]='\0';
             /* Tape ID */
             if (hpss_fs->feature == 1 || hpss_fs->feature == 0) {
               sprintf(buffer, "%s", hpss_fs->volnum[0]);
             }

             /* Tape IDs */
             if (hpss_fs->feature == 4) {
               i = 0;
               while ( strlen(hpss_fs->volnum[i]) ) {
                   if (i) strcat(buffer, " ");
                   strcat(buffer, hpss_fs->volnum[i]);
                   i++;
               }
             }

             /* statx */
             if (hpss_fs->feature == 2 || hpss_fs->feature == 0) {
               if (strlen(buffer))
                   strcat(buffer, " ");
               sprintf(tmp_buf, "%c ", hpss_fs->ftype);
               permission2str(hpss_fs->User_Perms, tmp_buf+2);
               permission2str(hpss_fs->Group_Perms, tmp_buf+5);
               permission2str(hpss_fs->Other_Perms, tmp_buf+8);
               sprintf(tmp_buf+11, "%lu %lu %lu %lu %lu %s", hpss_fs->uid, hpss_fs->gid, hpss_fs->atime, hpss_fs->ctime, hpss_fs->mtime, hpss_fs->size_str);
               strcat(buffer, tmp_buf);
             }

             if (hpss_fs->feature == 3 || hpss_fs->feature == 0) {
               if (strlen(buffer))
                   strcat(buffer, " ");
               switch(hpss_fs->storagelevel) {
               case 0:
                   sprintf(tmp_buf, "DISK");
                   break;
               case 1:
                   sprintf(tmp_buf, "TAPE");
                   break;
               default:
                   sprintf(tmp_buf, "UNKNOWN");
                   break;
               }
               strcat(buffer, tmp_buf);
             }

             if (hpss_fs->feature == 5 || hpss_fs->feature == 0) {
               if (strlen(buffer))
                   strcat(buffer, " ");
               sprintf(tmp_buf, "%d", hpss_fs->cos_id);
               strcat(buffer, tmp_buf);
             }

             if (hpss_fs->feature == 6 || hpss_fs->feature == 0) {
               if (strlen(buffer))
                   strcat(buffer, " ");
               local_dbutils_get_MediaType(hpss_fs->volnum[0], tmp_buf);
               strcat(buffer, tmp_buf);
             }


             if (!Sigpipe_caught) {
                 strcat(buffer, "|");
                 buffer_len = write(sockfd, buffer, strlen(buffer));
             }
       }
       else {
           sprintf(buffer, "ERROR: %d\n", status);
           if (!Sigpipe_caught) {
               buffer_len = write(sockfd, buffer, strlen(buffer));
           }
       }
   }
   show_status(buffer);
   return status;
}

int main (int argc, char *argv[])
{
  /* Must initialize the utils functions. Used to protect logging in the */
  /* threaded environment. Read in the configuration file.               */
  int rc, status;
  fstruct_t hpss_fs;
  int srv_run = 1, buffer_len, peer_len, ret;
  int sockfd, newsockfd, clilen;
  pid_t pID;
  time_t now;
  struct tm ltime;
  FILE *fpipe;
  pthread_t Tid;
  char command[MAX_BUFFER_LEN];
  char line[MAX_BUFFER_LEN];
  char *hpss_home;
  char buffer[MAX_BUFFER_LEN];
  struct sockaddr_in cli_addr;
  long count = 0;

  signal(SIGHUP, sigHand);
  signal(SIGINT, sigHand);
  signal(SIGQUIT, sigHand);
  signal(SIGILL, sigHand);
  signal(SIGABRT, sigHand);
  signal(SIGSEGV, sigHand);
  signal(SIGTERM, sigHand);
  signal(SIGPIPE, pipe_handler);

  debug = 0;

  if ( argc < 3 ) {
      usage(argv[0]);
      exit(1);
  }

  progname = (char *)strdup(argv[1]);
  strcpy(imp_user, argv[1]);

  sockfd = srv_init(atoi(argv[2]));

  init_utils();
  status = hpss_login();

  printf("Listing\n");
  fflush(stdout);
  fflush(stderr);
  while (srv_run) {
     /** LISTENING **/
     listen(sockfd,SOMAXCONN);

     clilen = sizeof(cli_addr);
     /** ACCEPT **/
     newsockfd = accept(sockfd,
                 (struct sockaddr *) &cli_addr,
                 &clilen);
     if (newsockfd < 0) {
        printf("ERROR on accept ...\n");
        printf("Pause ...\n");
        sleep(2);
     }
     count++;
     printf("Request %ld: ", count);

     show_timestamp();
     local_dbutils_mkcl();
     srv_run = request_handle(newsockfd, &cli_addr);
     local_dbutils_unreg();
     close(newsockfd);
     fflush(stdout);
     fflush(stderr);
  }

  dbutils_disconnect();
  exit(status);
}

