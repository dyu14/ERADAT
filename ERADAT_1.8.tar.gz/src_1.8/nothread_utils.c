#include  <stdio.h>
#include  <stdarg.h>
#include  <errno.h>
#include  <string.h>
#include  <sys/param.h>
#include  <time.h>
#include  <pwd.h>
 
#include "u_signed64.h" 
#include "hpss_api.h"
#include "nothread_utils.h"

/* Global variables */

config_t  Config;  /* Global configuration table information */

/*=================================================================================*/
/* submit_read_config() : Read the configuration files into the config structure.  */
/*                                                                                 */
/* Externals:                                                                      */
/*     config_t   Config                                                           */
/*     int        errno                                                            */
/*                                                                                 */
/* Assumptions:                                                                    */
/*     init_utils() has already been called.                                       */
/*                                                                                 */
/* Notes: exactly same as read_config in thread_utils.c                            */
/*=================================================================================*/

void submit_read_config()
{
  FILE  *config_fp;
  char  *config_file;
  int    rc;

  config_file = getenv("HPSS_BATCH_CONFIG");

  if (config_file == (char *)NULL)
    config_file = DEFAULT_CONFIG_PATH;
 
  if ((config_fp = fopen(config_file, "r")) == (FILE *)NULL)
  {
    fprintf(stderr, "Unable to open config file(%s): %d\n", config_file, errno);
    exit(1);
  }
 
  /* Read the configuration file.  The format must be the following:     */
  /*      email address                                                  */
  /*      principal server is run under (hpss_ftp)                       */
  /*      path of keytab file (/krb5/hpss.keytabs)                       */
  /*      path of offline table                                          */
  /*      path of input directory                                        */
  /*      path of working directory                                      */
  /*      path of output directory                                       */
  /*      path of bad directory                                          */
  /*      path to the external data transfer script                      */
  /* Only 9 lines allowed and no other checking is performed.  Keep this */
  /* file correct!                                                       */

  rc  = fscanf(config_fp, "%s", Config.admin_email);
  rc += fscanf(config_fp, "%s", Config.principal);
  rc += fscanf(config_fp, "%s", Config.keytab);
  rc += fscanf(config_fp, "%s", Config.offline_table);
  rc += fscanf(config_fp, "%s", Config.input_dir);
  rc += fscanf(config_fp, "%s", Config.working_dir);
  rc += fscanf(config_fp, "%s", Config.output_dir);
  rc += fscanf(config_fp, "%s", Config.bad_dir);
  rc += fscanf(config_fp, "%s", Config.transfer_script);

  if (rc != 9)
  {
    fprintf(stderr, "Config file(%s): bad format\n", config_file);
    exit(1);
  }

  fclose(config_fp);
  return;
}

/*=========================================================================*/
/* submit_file(): Build and submit the user request of files to be staged  */
/*                and copied to local disk space.                          */
/*                                                                         */
/* Arguments:                                                              */
/*     char  *local_username                                               */
/*     char  *hpss_username                                                */
/*     char  *email_addr                                                   */
/*     char  *request_file                                                 */
/*                                                                         */
/* Externals:                                                              */
/*     config_t   Config                                                   */
/*=========================================================================*/

void submit_file( char *local_username, /* In - AIX user name                  */
                  char *hpss_username,  /* In - HPSS principal name            */
                  char *email_addr,     /* In - Address to send notifications  */
                  char *request_file,   /* In - File of list of files          */
                  char *output_file)    /* In - Name of file to send output    */
{
  int      rc;

  FILE    *fp_in;
  FILE    *fp_out;

  char     job_file[MAXPATHLEN+1];
  char     tmp_file[MAXPATHLEN+1];
  char     work_file[MAXPATHLEN+1];
  char     out_file[MAXPATHLEN+1];
  char     buffer[4096];
  char     hpss_file[4096];
  char     local_file[4096];
 
  char    *ptr;
  char     partial[_D_NAME_MAX+1];

  /* Potential security hole: we are running as root and can read any file      */
  /* on the system.  However, what can we do with it?  Even submitting some     */
  /* kind of list we aren't priviledged to see will not affect getting files    */
  /* off of HPSS.  Only if we have local and HPSS authority by our usernames    */
  /* we just authenticated, do we have a chance to get files.  Files protected  */
  /* in HPSS are still protected!                                               */

  fp_in = fopen(request_file, "r");

  if (fp_in == (FILE *)NULL)
  {
    fprintf(stderr, "Unable to open file(%s): %d\n", request_file, errno);
    exit(1);
  }

  /* Now get the last segment of the request file from the path.  This name */
  /* is what we will use to submit a job                                    */

  ptr = strrchr(request_file, '/');

  if (ptr == (char *)NULL)
    ptr = request_file;
  else
    ptr++;

  if (strlen(ptr) > (_D_NAME_MAX - 1))
  {
    fprintf(stderr, "Request file(%s) is too long\n", request_file);
    exit(1);
  }

  strcpy(partial, ptr);
  
  /* Go build the full pathname of the files we will be submitting */
   
  sprintf(job_file,  "%s/%s",  Config.input_dir,   partial);
  sprintf(tmp_file,  "%s/.%s", Config.input_dir,   partial);
  sprintf(work_file, "%s/%s",  Config.working_dir, partial);
  sprintf(out_file,  "%s/%s",  Config.output_dir,  partial);

  /* Make sure a job by the same name doesn't already exist.   This isn't bullet */
  /* proof.  Someone could sneak in but that is highly unlikely.  If someone     */
  /* really gets worried, they can write a directory locking scheme as an        */
  /* addition to this stuff.                                                     */
   
  if (!access(job_file,  F_OK) || !access(tmp_file, F_OK) ||
      !access(work_file, F_OK) || !access(out_file, F_OK))
  {
    fprintf(stderr, "Request by the same name(%s) already exists, try again later\n", partial);
    exit(1);
  }

  /* Create our request file */

  fp_out = fopen(tmp_file, "w");

  if (fp_out == (FILE *)NULL)
  {
    fprintf(stderr, "Unable to create file(%s): %d\n", tmp_file, errno);
    exit(1);
  }

  fprintf(fp_out, "%s %s %s %s\n", email_addr, local_username, hpss_username, output_file);

  /* Oh nasty, must process user input and who knows what we will get.  Make */
  /* sure each line contains two file names (determine if real files while   */
  /* processing) and that the names aren't too long.                         */

  fgets(buffer, sizeof(buffer), fp_in);

  while(!feof(fp_in))
  {
    rc = sscanf(buffer, "%s %s", hpss_file, local_file);

    if (rc != 2)
    {
      fprintf(stderr, "Format of request file is bad\n");
      exit(1);
    }

    if (strlen(hpss_file) > MAXPATHLEN)
    {
      fprintf(stderr, "Format of request file is bad, HPSS file name is too long\n");
      exit(1);
    }

    if (strlen(local_file) > MAXPATHLEN)
    {
      fprintf(stderr, "Format of request file is bad, local file name is too long\n");
      exit(1);
    }

    fprintf(fp_out, "%s %s\n", hpss_file, local_file);
    fgets(buffer, sizeof(buffer), fp_in);
  }

  fclose(fp_in);
  fclose(fp_out);
  
  /* Now activate the job by removing its "." prefix. */
   
/*
printf("nothread_utils: submit_file: tmp_file = %s\n", tmp_file);
printf("nothread_utils: submit_file: job_file = %s\n", job_file);
*/
  if (rename(tmp_file, job_file) < 0)
  {
    fprintf(stderr, "Unable to activate job(%s), please alert HPSS administrator\n",job_file);
    exit(1);
  }

  return;
}

/*================================================================================*/
/* _tprintf(): Print the current date and time along with the normal format.      */
/*             This is the non-thread/non-locking version.                        */
/*                                                                                */
/* Arguments:                                                                     */
/*    char  *format                                                               */
/*    ...                                                                         */
/*================================================================================*/

int  _tprintf(char *format,   /* In - Format to use when printing */
              ...)            /* In - Potluck, just like printf   */
{
  va_list    ap; 
  struct tm  ltime;
  time_t     current_time;

  va_start(ap,format);
  current_time = time((time_t *) NULL);
  memcpy(&ltime, localtime(&current_time), sizeof(struct tm));

  printf("%02d/%02d/%04d-%02d:%02d:%02d ", ltime.tm_mon+1, ltime.tm_mday,
                ltime.tm_year+1900, ltime.tm_hour, ltime.tm_min, ltime.tm_sec);

  vprintf(format, ap);
  va_end(ap);
  fflush(stdout);
  return(0);
}

/*==============================================================================*/
/* _dtprintf(): Print the current date and time. First two arguments are the    */
/*              same of the file and line number. Rest of format is then        */
/*              processed. This is the non-thread/non-locking version.          */
/*                                                                              */
/* Arguments:                                                                   */
/*     char   *file                                                             */
/*     int     line                                                             */
/*     char   *format                                                           */
/*     ...                                                                      */
/*==============================================================================*/

int _dtprintf(char *file,    /* In - Name of file called from    */
              int   line,    /* In - Line number where called    */
              char *format,  /* In - Format to use when printing */
              ...)
{
  va_list     ap;
  struct tm   ltime;
  time_t      current_time;

  va_start(ap,format);
  current_time = time((time_t *) NULL);
  memcpy(&ltime, localtime(&current_time), sizeof(struct tm));

  printf("%02d/%02d/%04d-%02d:%02d:%02d \"%s:%d\" ", ltime.tm_mon+1,
                ltime.tm_mday, ltime.tm_year+1900, ltime.tm_hour,
                ltime.tm_min, ltime.tm_sec, file, line);

  vprintf(format, ap);
  va_end(ap);
  fflush(stdout);
  return(0);
}

