#ifndef _NOTHREAD_UTILS_H_
#define _NOTHREAD_UTILS_H_

#include  <stdio.h>
#include  <stdarg.h>
#include  <errno.h>
#include  <string.h>
#include  <sys/param.h>
#include  <dirent.h>		/* 11/13/2002 Added by Razvan for non-DCE */
#include  "common.h"

/* First argument to function dtprint.              */
/* Places filename and line number in debug message */
 
#define HERE  __FILE__,__LINE__

/* Declare global externs */

extern config_t  Config;      /* Holder of all config info */

/* Declaration of local functions */

void submit_read_config();
void submit_file(char *, char *, char *, char *, char *);
void _tprint(char *, ...);
void _dtprint(char *, int, char *, ...);

#endif /* _NOTHREAD_UTILS_H_ */
