#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include <pwd.h>
#include <signal.h>
#include <sys/stat.h>
#include <pthread.h>

#include "u_signed64.h"
#include "hpss_api.h"
#include "hpss_queue.h"
#include "common.h"
#include "batch.h"
#include "thread_utils.h"
#include "batch_utils.h"
#include "dbutils.h"
#include "ns_Constants.h"
#include "hpss_get_attr.h"

char replay_file;
int stage_opt = 0;

void usage(char *progname)
{
    printf("Syntax error: INVALID ARGUMENTS\n");
    printf("    %s <username> <port number>\n", progname);
}

int Sigpipe_caught;
void pipe_handler(int status)
{
  printf("Received signal SIGPIPE\n");
  Sigpipe_caught = 1;
}

void sigHand(int status)
{
   printf("Received signal %d, processing unregist...\n", status);
   switch(status) {
   case SIGPIPE:
       printf("Reset signal %d\n", status);
       signal(SIGPIPE, sigHand);
       break;
   default:
       if (registed_client) {
           local_dbutils_unreg();
       }
   }
   exit(1);
}

void error(char *msg)
{
    perror(msg);
    exit(1);
}

void show_status( char *stat_str)
{
     printf("%s\n", stat_str);
}

void show_timestamp()
{
     time_t now;
     struct tm ltime;

     now = time((time_t *)NULL);
     localtime_r(&now,&ltime);
     printf("%02d/%02d/%04d-%02d:%02d:%02d| ",
             ltime.tm_mon+1, ltime.tm_mday, ltime.tm_year+1900,
             ltime.tm_hour, ltime.tm_min, ltime.tm_sec );
}

int request_handle(char *filename)
{
     int status;
     fstruct_t hpss_fs;

     hpss_fs.feature = 0;
     hpss_fs.filename = (char *) strdup(filename);

     if (debug) printf("Calling process_request\n");
     status = process_request(&hpss_fs);
     if (debug) printf("End process_request\n");

     free(hpss_fs.filename);
}

void permission2str(unsigned32 Perm, char *perm)
{
   char ch = ' ';

   if ( !perm )
       return;

   if ( Perm & HPSS_PERM_READ ) ch='r'; else ch='-';
   perm[0]=ch;
   if ( Perm & HPSS_PERM_WRITE ) ch='w'; else ch='-';
   perm[1]=ch;
   if ( Perm & HPSS_PERM_EXEC ) ch='x'; else ch='-';
   perm[2]=ch;
   perm[3]='\0';
}

int process_request(fstruct_t *hpss_fs)
{
   int status, buffer_len;
   char buffer[MAX_BUFFER_LEN], tmp_buf[512];

   if (debug) printf("Entering process_request\n");
   if (hpss_fs->filename) {
       if (debug) printf("DEBUG: %s|%d\n", __FILE__, __LINE__);
       status = get_file_attr(hpss_fs);
       if (debug) printf("DEBUG: %s|%d\n", __FILE__, __LINE__);
       bzero(buffer,MAX_BUFFER_LEN);
       if (status == 0 || hpss_fs->ftype == 'd') {
             if (hpss_fs->chkbadtape) {
                 if (chk_tape_stat(hpss_fs->volnum) == 1) {
                   status = -ENOENT;
                 }
             }
             if (hpss_fs->ftype == 'd') {
                 status = -EISDIR;
             }

             buffer[0]='\0';
             /* Tape ID */
             if (hpss_fs->feature == 1 || hpss_fs->feature == 0) {
               sprintf(buffer, "%s", hpss_fs->volnum);
             }

             /* statx */
             if (hpss_fs->feature == 2 || hpss_fs->feature == 0) {
               if (strlen(buffer))
                   strcat(buffer, " ");
               sprintf(tmp_buf, "%c ", hpss_fs->ftype);
               permission2str(hpss_fs->User_Perms, tmp_buf+2);
               permission2str(hpss_fs->Group_Perms, tmp_buf+5);
               permission2str(hpss_fs->Other_Perms, tmp_buf+8);
               sprintf(tmp_buf+11, "%lu %lu %lu %lu %lu %lu", hpss_fs->uid, hpss_fs->gid, hpss_fs->atime, hpss_fs->ctime, hpss_fs->mtime, hpss_fs->size);
               strcat(buffer, tmp_buf);
             }

             if (hpss_fs->feature == 3 || hpss_fs->feature == 0) {
               if (strlen(buffer))
                   strcat(buffer, " ");
               switch(hpss_fs->storagelevel) {
               case 0:
                   sprintf(tmp_buf, "DISK");
                   break;
               case 1:
                   sprintf(tmp_buf, "TAPE");
                   break;
               default:
                   sprintf(tmp_buf, "UNKNOWN");
                   break;
               }
               strcat(buffer, tmp_buf);
             }

             printf("%s\n", buffer);
       }
   }
   show_status(buffer);
   return status;
}

int main (int argc, char *argv[])
{
  /* Must initialize the utils functions. Used to protect logging in the */
  /* threaded environment. Read in the configuration file.               */
  int status;
  fstruct_t hpss_fs;
  char imp_user[32];
  char soidZ[128];

  debug = 0;

  if ( argc < 2 ) {
      usage(argv[0]);
      exit(1);
  }

  strcpy(imp_user, argv[1]);
  strcpy(soidZ, argv[2]);

  init_utils();
  status = hpss_login();

  status = request_handle(soidZ);
  exit(status);
}

