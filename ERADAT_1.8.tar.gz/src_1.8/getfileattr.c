#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include <pwd.h>
#include <sys/stat.h>

#include "u_signed64.h"
#include "hpss_api.h"
#include "hpss_queue.h"
#include "common.h"
#include "batch.h"
#include "thread_utils.h"
#include "batch_utils.h"
#include "ns_Constants.h"

/*   Global Variables    */                                                                    
extern int hpss_GetStorageLevel_Etc( char    *Filename,
                                     hpssoid_t  *BitFile_Id,
                                     u_signed64 *Length,
                                     hpssoid_t  *VVID,
                                     signed32   *Position,
                                     unsigned32 *File_Type, 
                                     unsigned32 *Composite_Perms, 
                                     signed32   *Storage_Level,
                                     cos_t   *Cos_Id,
                                     char   *Vol_Name 
                                     );

config_t Config;     /* Master configuration                         */

int R_Log = FALSE;   /* Flag for local logging */


#define MAX_VOL_NAME_LEN 15  /* actual length 12 */
unsigned32 get_file_attr(char *filename, char *perm, char *uid, char *gid, unsigned long *fsize, char *mtime);
int get_file_attr2(char *, unsigned long *);

void usage(char *progname)
{
    printf("Syntax error: INVALID ARGUMENTS\n");
    printf("    %s <directory name> <filename>\n", progname);
}

int main (int argc, char *argv[])
{
  /* Must initialize the utils functions. Used to protect logging in the */
  /* threaded environment. Read in the configuration file.               */
  int     rc;
  unsigned32 status;
  char *dirname;
  char *filename;
  char volnum[MAX_VOL_NAME_LEN];
  char perm[12], uid[32], gid[32], mtime[16];
  long fsize;
  int rtn_code = 0;
  char *fullpath;

  if ( argc < 2 ) {
      usage(argv[0]);
      exit(1);
  }
  dirname = (char *)strdup(argv[1]);
  filename = (char *)strdup(argv[2]);
  fullpath = (char *)malloc(sizeof(char)*(strlen(dirname)+strlen(filename)+2));
  sprintf(fullpath, "%s/%s", dirname, filename);

  if ((rc = hpss_SetAuthType(API_AUTH_LOGIN_NONE)) < 0)
  {
    dtprintf(HERE, "ERROR: hpss_SetAuthType() failed: %d\n", rc);
    exit(1);
   }

  /* ROOT=0, uid of dce user "root" */

  if ((rc = hpss_LoadThreadState(ROOT,DMASK,0)) < 0)
  {
    dtprintf(HERE, "ERROR: hpss_LoadThreadState() failed: %d\n", rc);
    exit(1);
   }

/*
   if (filename) {
       status = get_file_attr(fullpath, perm, uid, gid, &fsize, mtime);
       if ( status == NS_OBJECT_TYPE_FILE || 
            status == NS_OBJECT_TYPE_HARD_LINK) {
           rtn_code = 0;
       }
       else {
           rtn_code = 70;
           status = get_file_attr(dirname, perm, uid, gid, &fsize, mtime);
           if ( status == 0)
               rtn_code = 72;
       }
   }
*/
   status = get_file_attr2(fullpath, &fsize);
   if (status == -2) {
       rtn_code = 70;
       status = get_file_attr2(dirname, &fsize);
       if (status == -2) 
           rtn_code = 72;
   }

   switch (rtn_code) {
   case  0: printf("%u %s\n", fsize, fullpath); break;
   case 70: printf("*** hpss_Lstat: No such file or directory [-2: HPSS_ENOENT]\n\t%s\n", fullpath); break;
   case 72: printf("*** hpss_Lstat: No such directory [-2: HPSS_ENOENT]\n\t%s\n", dirname); break;
   default: printf("error: %d\n", rtn_code);
   }
   if (fullpath)
       free (fullpath);
   if (filename)
       free(filename);
   if (dirname)
       free(dirname);
   exit(rtn_code);
}

int get_file_attr2(char *filename, unsigned long *fsize) 
{
    hpssoid_t      bitfile_id;
    u_signed64     length;
    hpssoid_t      vvid;
    signed32       rel_position;
    unsigned32     file_type;
    unsigned32     all_perms;
    signed32       storage_level;
    cos_t         cosid;
    int status;
    char volnum[MAX_VOL_NAME_LEN];

    status = hpss_GetStorageLevel_Etc(filename,   
                                      &bitfile_id,
                                      &length,
                                      &vvid,
                                      &rel_position,
                                      &file_type,
                                      &all_perms,
                                      &storage_level,
                                      &cosid,
                                      volnum);
    *fsize = u64_to_ul(length);

    return status;
}

unsigned32 get_file_attr(char *filename, char *perm, char *uid, char *gid, unsigned long *fsize, char *mtime)
{
    unsigned32     CompositePerms;
    unsigned32     UID;
    unsigned32     GID;
    u_signed64     length;
    timestamp_sec_t TimeModified;
    unsigned32     flags = API_GET_STATS_FOR_ALL_LEVELS;
    unsigned32     storagelevel = 0;
    hpss_xfileattr_t file_attr;
    unsigned32     file_type;

    int	rc, i;

    rc = hpss_FileGetXAttributes(filename,flags,storagelevel,&file_attr);

    for (i=0; i<HPSS_MAX_STORAGE_LEVELS; i++)
    {
      if (file_attr.SCAttrib[i].Flags & BFS_BFATTRS_DATAEXISTS_AT_LEVEL)
      {
        length = file_attr.SCAttrib[i].BytesAtLevel;

        file_type       = file_attr.Attrs.Type;
        CompositePerms = file_attr.Attrs.CompositePerms;
        storagelevel    = i;
      }

      if (file_attr.SCAttrib[i].Flags == 0)
      {
          file_type = file_attr.Attrs.Type;
          break;
      }
    }

    if (file_type == NS_OBJECT_TYPE_FILE ||
        file_type == NS_OBJECT_TYPE_HARD_LINK)
    {
        *fsize = u64_to_ul(length);
    }
    return(file_type); 
}

int get_tape_id(char *filename, char *volnum)
{
    hpssoid_t      bitfile_id;
    u_signed64     length;
    hpssoid_t      vvid;
    signed32       rel_position;
    unsigned32     file_type;
    unsigned32     all_perms;
    signed32       storage_level;
    cos_t         cosid;
    int status;

    status = hpss_GetStorageLevel_Etc(filename,   
                                      &bitfile_id,
                                      &length,
                                      &vvid,
                                      &rel_position,
                                      &file_type,
                                      &all_perms,
                                      &storage_level,
                                      &cosid,
                                      volnum);

    return status;
}
