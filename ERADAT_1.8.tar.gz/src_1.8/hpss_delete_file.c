#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include <pwd.h>
#include <signal.h>
#include <sys/stat.h>

#include "u_signed64.h"
#include "hpss_api.h"
#include "hpss_queue.h"
#include "common.h"
#include "batch.h"
#include "thread_utils.h"
#include "batch_utils.h"
#include "dbutils.h"
#include "ns_Constants.h"

#define VERSION "1.4"

#define HPSS_PERM_READ  32
#define HPSS_PERM_WRITE 64
#define HPSS_PERM_EXEC  128

#define MAX_VOL_NAME_LEN 15  /* actual length 12 */
#define VOL_NAME_LEN  6

#define MAX_RETRY    5
#define RETRY_PERIOD 1
#define DEF_CORE_SERVER "hpsscore.rcf.bnl.gov"
#define MAX_BUFFER   4096

/*   Global Variables    */ 
int registed_client = 0;

/*   Global dummy Variables    */ 
char replay_file = ' ';
int stage_opt = 0;

typedef struct fstruct
{
  FILE *fp;
  char *filename;             /* Name of HPSS file              */
  unsigned32 User_Perms;
  unsigned32 Group_Perms;
  unsigned32 Other_Perms;
  char ftype;
  unsigned32 uid;
  unsigned32 gid;
  timestamp_sec_t atime;
  timestamp_sec_t ctime;
  timestamp_sec_t mtime;
  unsigned long size;
  char volnum[MAX_VOL_NAME_LEN];
} fstruct_t;

extern int hpss_GetStorageLevel_Etc( char    *Filename,
                                     hpssoid_t  *BitFile_Id,
                                     u_signed64 *Length,
                                     hpssoid_t  *VVID,
                                     signed32   *Position,
                                     unsigned32 *File_Type, 
                                     unsigned32 *Composite_Perms, 
                                     signed32   *Storage_Level,
                                     cos_t   *Cos_Id,
                                     char   *Vol_Name 
                                     );

config_t Config;     /* Master configuration                         */
char localhost[128];

int R_Log = FALSE;   /* Flag for local logging */

int local_dbutils_connect();
int  local_dbutils_init();
int chk_tape_stat(char *tapid);
void print_timestamp_sec (timestamp_sec_t data);
void local_dbutils_unreg();
char *get_next_request(fstruct_t *, char *);
void log_request(char *user, char *request, int status);

void usage(char *progname)
{
    printf("Syntax error: INVALID ARGUMENTS\n");
    printf("    %s <userid> <fullpath filename> \n", progname);
    printf("    where:\n");
    printf("  userid: Your name or email\n");
    printf("  fullpath filename: Filename with fully qualified path\n");
}

void print_permission(unsigned32 Perm)
{
   if ( Perm & HPSS_PERM_READ ) printf("r"); else printf("-");
   if ( Perm & HPSS_PERM_WRITE ) printf("w"); else printf("-");
   if ( Perm & HPSS_PERM_EXEC ) printf("x"); else printf("-");
}

void sigHand(int status)
{
   if (registed_client) {
        printf("Received signal %d...\n", status);
   }
   exit(1);
}

void sigReg(int signalType, void (*func)(int)){
  struct sigaction sa;
  sa.sa_handler = func;
  sa.sa_flags = 0;
  sa.sa_restorer = NULL;
  sigaction(signalType,  &sa, NULL);
}

int main (int argc, char *argv[])
{
  /* Must initialize the utils functions. Used to protect logging in the */
  /* threaded environment. Read in the configuration file.               */
  int rc, status;
  fstruct_t hpss_fs;
  int feature = 0, chkbadtape = 1;
  char buffer[MAX_BUFFER];
  char *user;
  char confirm;
  char ktpath[HPSS_MAX_PATH_NAME];
  char auth_type[16]="unix";
  hpss_authn_mech_t mech_type = hpss_authn_mech_krb5;
  api_config_t      api_config;
  char	  *hpss_home;


  sigReg(SIGHUP, sigHand);
  sigReg(SIGINT, sigHand);
  sigReg(SIGQUIT, sigHand);
  sigReg(SIGILL, sigHand);
  sigReg(SIGABRT, sigHand);
  sigReg(SIGKILL, sigHand);
  sigReg(SIGSEGV, sigHand);
  sigReg(SIGTERM, sigHand);
  sigReg(SIGSTOP, sigHand);

  if ( getenv("HPSS_NDCG_SERVERS") == 0) {
      char envstr[128];
      fprintf(stderr, "HPSS_NDCG_SERVERS is not set\n");
      fprintf(stderr, "Use default: HPSS_NDCG_SERVERS=%s\n", DEF_CORE_SERVER);
      sprintf(envstr, "HPSS_NDCG_SERVERS=%s", DEF_CORE_SERVER);
      putenv(envstr);
  }

  if ( argc < 3 ) {
      usage(argv[0]);
      exit(1);
  }

  status = local_dbutils_connect();
  if (status == 0) 
      status = log_init();

  if (status != 0) {
      printf("%s Initialization fail, please check your environment variables\n", argv[0]);
      exit(1);
  }

  user = (char *)strdup(argv[1]);
  hpss_fs.filename = (char *)strdup(argv[2]);

  if (argc == 4 && !strcmp(argv[3],"-q"))
      confirm = 'Y';
  else {
      printf("WARNING: You are about to DELETE file(s) from HPSS, are you sure? (y/N)\n");
      scanf("%c", &confirm);
  }

  if (toupper(confirm) != 'Y') {
      printf("Quit\n");
      exit(1);
  }

#if HPSS_5_1_NON_DCE
  if ((rc = hpss_SetAuthType(API_AUTH_LOGIN_NONE)) < 0)
  {
    dtprintf(HERE, "ERROR: hpss_SetAuthType() failed: %d\n", rc);
    exit(1);
   }

  /* ROOT=0, uid of dce user "root" */

  if ((rc = hpss_LoadThreadState(ROOT,DMASK,0)) < 0)
  {
    dtprintf(HERE, "ERROR: hpss_LoadThreadState() failed: %d\n", rc);
    exit(1);
   }
#else
  rc = hpss_AuthnMechTypeFromString(auth_type, &mech_type);
  if(rc != 0) {
    dtprintf(HERE, "ERROR: hpss_AuthnMechTypeFromString() failed: %d\n", rc);
    dtprintf(HERE, "invalid authentication type %s\n",auth_type);
    exit(rc);
  }

  rc = hpss_GetConfiguration(&api_config);
  if(rc != 0) {
    dtprintf(HERE, "ERROR: hpss_GetConfiguration() failed: %d\n", rc);
    bu_terminate();
    exit( rc );
  }

  api_config.AuthnMech = mech_type;
  api_config.Flags |= API_USE_CONFIG;

  rc = hpss_SetConfiguration(&api_config);
  if(rc != 0) {
    dtprintf(HERE, "ERROR: hpss_SetConfiguration() failed: %d\n", rc);
    bu_terminate();
    exit( rc );
  }

  sprintf(ktpath, "%s/config/keytabs/%s.unix.keytab", hpss_home, client_str.user);
  printf("Loading keytab: %s\n", ktpath);

  rc = hpss_SetLoginCred(client_str.user,
                         mech_type,
                         hpss_rpc_cred_client,
                         hpss_rpc_auth_type_keytab,
                         ktpath);
  if (rc != 0)
  {
    dtprintf(HERE, "ERROR: hpss_SetLoginCred() failed: %d\n", rc);
    bu_terminate();
    exit(1);
  }
   sleep(1);
#endif

   if (hpss_fs.filename) {
       if ( init_request(&hpss_fs)) {
           while (*get_next_request(&hpss_fs, buffer)) {
               status = 0;
               if (*(buffer+strlen(buffer)-1) == '\n')
                   *(buffer+strlen(buffer)-1) = '\0';
               status = hpss_Unlink(buffer);
               printf("%s|%d\n", buffer, status); 
               log_request(user, buffer, status);
           }
       }
       else {
           printf("Unable to open file \"%s\"\n", hpss_fs.filename);
       }
       free(hpss_fs.filename);
       free(user);
   }

   exit(status);
}

void log_request(char *user, char *request, int status)
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char **row = NULL;
    char stmt[MAX_STMT_LEN];
    time_t now;

    now = time((time_t *) NULL);
    sprintf(stmt, "INSERT INTO hpss_delete_log SET timestamp = %ld, user = '%s', filename = '%s', status = %d", now, user, request, status);
    client_h = dbutils_exec_query(stmt);
    registed_client = 0; /* in case if 2nd signal arrives... */
}

int log_init()
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char **row = NULL;
    char stmt[MAX_STMT_LEN];
    int status = -1;
    time_t now;

    now = time((time_t *) NULL);
    sprintf(stmt, "SELECT COUNT(*) FROM hpss_delete_log");
    client_h = dbutils_exec_query(stmt);
    if (client_h) 
        return 0;
}

int get_file_attr(fstruct_t *fs)
{
  int              rc;
  int              retry_cnt;
  int              i;
  int              j;
  hpss_xfileattr_t file_attr;
  unsigned32       flags;
  unsigned32       storagelevel;
  char             uuid_str[64];
  u_signed64       Length;
  unsigned32       File_Type;
  unsigned32       Composite_Perms;

  retry_cnt = -1;
  flags     = API_GET_STATS_FOR_ALL_LEVELS;
  storagelevel     = 0;

retry:
  retry_cnt++;

  rc = hpss_FileGetXAttributes(fs->filename,flags,storagelevel,&file_attr);

  if (rc < 0)
  {
    if (rc != -ENOENT && retry_cnt < MAX_RETRY)
    {
      fprintf(stderr,"hpss_FileGetXAttributes: %d, retry(%d)..\n", rc, retry_cnt);
      sleep(RETRY_PERIOD);
      goto retry;
    }
    return(rc);
  }

  fs->size = 0;

  for (i=0; i<HPSS_MAX_STORAGE_LEVELS; i++)
  {
#if 0
    if (file_attr.SCAttrib[i].Flags == 0)
    {
      if (i == 0)
      {
        if (file_attr.Attrs.Type == NS_OBJECT_TYPE_FILE)
        {
          fprintf(stderr,"No segments exist for this file?\n");
          return(-2);
        }
        return(-EISDIR);
      }
      return(0);
    }
#endif

    if (file_attr.Attrs.Type == NS_OBJECT_TYPE_FILE || 
        file_attr.Attrs.Type == NS_OBJECT_TYPE_DIRECTORY) {
      switch (file_attr.Attrs.Type) {
      case NS_OBJECT_TYPE_FILE: fs->ftype = 'f'; break;
      case NS_OBJECT_TYPE_DIRECTORY: fs->ftype = 'd'; break;
      default: fs->ftype = ' ';
      } 
      fs->User_Perms = file_attr.Attrs.UserPerms - 1;
      fs->Group_Perms = file_attr.Attrs.GroupPerms;
      fs->Other_Perms = file_attr.Attrs.OtherPerms;
      fs->atime = (file_attr.Attrs.TimeLastRead > file_attr.Attrs.TimeLastWritten?file_attr.Attrs.TimeLastRead:file_attr.Attrs.TimeLastWritten);
      fs->ctime = file_attr.Attrs.TimeCreated;
      fs->mtime = file_attr.Attrs.TimeModified;
      fs->uid = file_attr.Attrs.UID;
      fs->gid = file_attr.Attrs.GID;
    }
    if (file_attr.SCAttrib[i].Flags & BFS_BFATTRS_DATAEXISTS_AT_LEVEL) {
      Length = file_attr.SCAttrib[i].BytesAtLevel;
      fs->size = u64_to_ul(Length);

      for (j=0; j<file_attr.SCAttrib[i].NumberOfVVs; j++)
      {
        if (file_attr.SCAttrib[i].VVAttrib[j].PVList != NULL) {
          memcpy(fs->volnum,
                 file_attr.SCAttrib[i].VVAttrib[j].PVList[0].List.List_val[0].Name,
                 VOL_NAME_LEN);
          fs->volnum[VOL_NAME_LEN] = '\0';
          free(file_attr.SCAttrib[i].VVAttrib[j].PVList[0].List.List_val);
          free(file_attr.SCAttrib[i].VVAttrib[j].PVList);
        }
      }
    }
  }

  return(0);
}

int local_dbutils_connect() 
{
  local_dbutils_init();

  mysql_init(&mysql_db);

  return (dbutils_real_connect());
}

int local_dbutils_init()
{
    char *host, *user, *pw, *db;

    dbutils_get_cfg();

    host = (char *)getenv("DB_HOST");
    user = (char *)getenv("DB_USER");
    pw = (char *)getenv("DB_PW");
    db = (char *)getenv("DB_DATABASE");

    if (host) strcpy(client_str.host, host);
    if (user) strcpy(client_str.user, user);
    if (pw) strcpy(client_str.pw, pw);
    if (db) strcpy(client_str.db, db);

    /* Now, briefly validate the parameters... */
    validate_cfg();

    client_str.reconnect_int = 60;
    client_str.log_enabled = 1;
}

int chk_tape_stat(char *volnum)
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char **row = NULL;
    char stmt[MAX_STMT_LEN];
    int status = 0;

    batch_str.command = BATCH_CMD_OK;
    sprintf(stmt, "SELECT status FROM cartridges WHERE volnum = '%s'", volnum);

    client_h = dbutils_exec_query(stmt);
    if (client_h) {
        row = dbutils_fetch(client_h);
        if (row) {
            status = atoi(row[0]);
        }
    }
    else
        status = -1;

    return status;
}

int init_request(fstruct_t *fs)
{
    fs->fp = NULL;
    fs->fp = fopen(fs->filename, "r");

    return (fs->fp?1:0);
}

char *get_next_request(fstruct_t *fs, char *buffer)
{
    if (!buffer)
        return NULL;

    return (fgets(buffer,MAX_BUFFER,fs->fp));
}
