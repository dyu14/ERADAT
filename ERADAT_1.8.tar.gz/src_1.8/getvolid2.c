#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include <pwd.h>
#include <sys/stat.h>

#include "u_signed64.h"
#include "hpss_api.h"
#include "hpss_queue.h"
#include "common.h"
#include "batch.h"
#include "thread_utils.h"
#include "batch_utils.h"
#include "dbutils.h"

/*   Global Variables    */                                                                    
extern int hpss_GetStorageLevel_Etc( char    *Filename,
                                     hpssoid_t  *BitFile_Id,
                                     u_signed64 *Length,
                                     hpssoid_t  *VVID,
                                     signed32   *Position,
                                     unsigned32 *File_Type, 
                                     unsigned32 *Composite_Perms, 
                                     signed32   *Storage_Level,
                                     cos_t   *Cos_Id,
                                     char   *Vol_Name 
                                     );

config_t Config;     /* Master configuration                         */

int R_Log = FALSE;   /* Flag for local logging */


#define MAX_VOL_NAME_LEN 15  /* actual length 12 */

int local_dbutils_connect();
void local_dbutils_init();
int chk_tape_stat(char *tapid);

void usage(char *progname)
{
    printf("Syntax error: INVALID ARGUMENTS\n");
    printf("    %s <fullpath filename>\n", progname);
}

void main (int argc, char *argv[])
{
  /* Must initialize the utils functions. Used to protect logging in the */
  /* threaded environment. Read in the configuration file.               */
  int     rc;
  int status;
  char *filename;
  char volnum[MAX_VOL_NAME_LEN];
  unsigned long fsize;

  if ( argc == 1 ) {
      usage(argv[0]);
      exit(1);
  }
  filename = (char *)strdup(argv[1]);

  if ((rc = hpss_SetAuthType(API_AUTH_LOGIN_NONE)) < 0)
  {
    dtprintf(HERE, "ERROR: hpss_SetAuthType() failed: %d\n", rc);
    exit(1);
   }

  /* ROOT=0, uid of dce user "root" */

  if ((rc = hpss_LoadThreadState(ROOT,DMASK,0)) < 0)
  {
    dtprintf(HERE, "ERROR: hpss_LoadThreadState() failed: %d\n", rc);
    exit(1);
   }

   if (filename) {
       status = get_file_attr(filename, volnum, &fsize);
       if (status == 0) {
           local_dbutils_connect();
           if (chk_tape_stat(volnum) == 1) {
               printf("%s %u ENOENT\n", volnum, fsize);
               status = -ENOENT;
           }
           else
               printf("%s %u\n", volnum, fsize);
       }

       free(filename);
   }
   exit(status);
}

int get_file_attr(char *filename, char *volnum, unsigned long *fsize)
{
    hpssoid_t      bitfile_id;
    u_signed64     length;
    hpssoid_t      vvid;
    signed32       rel_position;
    unsigned32     file_type;
    unsigned32     all_perms;
    signed32       storage_level;
    cos_t         cosid;
    int status;

    status = hpss_GetStorageLevel_Etc(filename,   
                                      &bitfile_id,
                                      &length,
                                      &vvid,
                                      &rel_position,
                                      &file_type,
                                      &all_perms,
                                      &storage_level,
                                      &cosid,
                                      volnum);

    if (status == 0)
        *fsize = u64_to_ul(length);

    return status;
}

int local_dbutils_connect() 
{
  local_dbutils_init();

  mysql_init(&mysql_db);

  return (dbutils_real_connect());
}

void local_dbutils_init()
{
    strcpy(client_str.host, "hpssdb02.rcf.bnl.gov");
    strcpy(client_str.user, "starrdat");
    strcpy(client_str.pw, "ciiydlmpw");
    strcpy(client_str.db, "batch");
    client_str.reconnect_int = 60;
    client_str.log_enabled = 1;
}

int chk_tape_stat(char *volnum)
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char **row = NULL;
    char stmt[MAX_STMT_LEN];
    int status = 0;

    batch_str.command = BATCH_CMD_OK;
    sprintf(stmt, "SELECT status FROM cartridges WHERE volnum = '%s'", volnum);

    client_h = dbutils_exec_query(stmt);
    if (client_h) {
        row = dbutils_fetch(client_h);
        if (row) {
            status = atoi(row[0]);
        }
    }
    else
        status = -1;

    return status;
}

