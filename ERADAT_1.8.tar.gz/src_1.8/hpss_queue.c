#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <sys/stat.h>
#include <limits.h>
#include <sys/param.h>

#include "hpss_api.h" 
#include "hpss_net.h" 
#include "hpss_types.h"
#include "hpss_thread_safe.h"
#include "hpss_interop.h"
#include "u_signed64.h"
#include "hpss_queue.h"
#include "thread_utils.h"
#include "ns_Constants.h"
#include "batch_utils.h"
#include "batch.h"
#include "hpss_batch_error.h"

#define MAX_ARGS             20
#define DEFAULT_BUFFERSIZE   1048576
#define SCRUB_MAX_HISTORY    500

#define EXT_UNKNOWN_ERROR    (-99999)
#define EXT_EOF              (-99998)
#define EXT_INCOMPLETE       (-99997)
#define EXT_XDR_SETPOS       (-99996)
#define EXT_XDR_DECODE       (-99995)

#define  MAX_RETRIES   10
#define  MAX_PVR_QUE   32
#define  VOL_NAME_LEN  6
#define  QUE_ALG_DEF   0
#define  QUE_SIZE_DESC 1
#define  QUE_SIZE_ASC  2

#define  BATCH_STAGE_SOCKET_FAIL -101
#define  BATCH_STAGE_GETHOSTNAME_FAIL -102
#define  BATCH_STAGE_BIND_FAIL -103
#define  BATCH_STAGE_LISTEN_FAIL -104
#define  BATCH_STAGE_GETSOCKNAME_FAIL -105
#define  BATCH_STAGE_ACCEPT_FAIL -106

/*
#define  HPSS_TAPE_LOCKED -150
#define  HPSS_LSM_DOWN -151
*/

int stage_callback_command(char *filename, u_signed64 offset, u_signed64 length, unsigned32 level, unsigned32 flags);

static boolean_t       Queue_Inited = FALSE;
static Master_Queue_t  Master_Queue[MAX_PVR_QUE]; /* Master_Queue_t defined in hpss_queue.h */
static int Master_Queue_Rows = 0;
struct timespec        Retry_Delay = {1,0};
int                    Q_Log = FALSE;        /* State of queue logging                 */
int                    Q_Lock = FALSE;        /* State of queue logging                 */
extern int             R_Log;
int                    q_alg = QUE_ALG_DEF;
int                    crs = 0;
int                    Q_Dump = FALSE;

extern int reserved_staging_thrs;
extern int stage_opt;
 
/*=================================================================================*/
/* create_entry() : Create a stage request entry to be placed into managed queues. */
/*                                                                                 */
/* Arguments:                                                                      */
/*      char             *Filename                                                 */
/*      hpssoid_t        *BitFile_Id                                               */
/*      u_signed64        Length                                                   */
/*      signed32          Position                                                 */
/*      int               Priority                                                 */
/*      u_signed64        PosOffset                                                */
/*      int               Priority                                                 */
/*      long             create_time                                               */
/*      void             (*Function)()                                             */
/*      void             *Func_Arg                                                 */
/*                                                                                 */
/* Externals:                                                                      */
/*      int      errno (if error occurs)                                           */
/*                                                                                 */
/* Return Values:                                                                  */
/*      Pointer to new entry or NULL if an error occurs                            */
/*=================================================================================*/
 
static Entry_t * create_entry (char        *Filename,    /* In - Full name of file            */
                               hpssoid_t   *BitFile_Id,  /* In - Bit file id                  */
                               u_signed64   Length,      /* In - Length of file               */
                               signed32     Position,    /* In - Position of file start       */
                               u_signed64   PosOffset,   /* In - Length of file               */
                               int          Priority,    /* In - Priority of stage request    */
                               long         create_time, /* In - File Creation time           */
                               void       (*Function)(), /* In - Function to call after stage */
                               void        *Func_Arg)    /* In - Argument to function         */
{
  Entry_t   *new_entry;
  request_t     *request_ptr;
  char 		*jobid;
  char      fsize[DEC64_LEN+1];
  char      foffset[DEC64_LEN+1];

  request_ptr = (request_t *)Func_Arg;
  jobid = request_ptr->job_ptr->job_id;


  /* Get memory for the new entry element. */
  new_entry = (Entry_t *)malloc(sizeof(Entry_t));

  if (new_entry == (Entry_t *)NULL)
    return((Entry_t *)NULL);

  /* Get memory for the full file name. */
  new_entry->filename = (char *)malloc(sizeof(char) * (strlen(Filename) + 1));

  if (new_entry->filename == (char *)NULL)
  {
    free(new_entry);
    return((Entry_t *)NULL);
  }

  strcpy(fsize, u64tostr(Length));
  strcpy(foffset, u64tostr(PosOffset));

  /* Now initialize the new queue's components. */

  strcpy(new_entry->filename, Filename);
  memcpy(&new_entry->bitfile_id, BitFile_Id, sizeof(hpssoid_t));
  new_entry->length     = Length;
  new_entry->position   = Position;
  new_entry->pos_offset = PosOffset;
  new_entry->offset_double = u64todouble(PosOffset);
  new_entry->priority   = Priority;
  new_entry->time_start = time((time_t) NULL);
  new_entry->function   = Function;
  new_entry->func_arg   = Func_Arg;
  new_entry->active     = FALSE;
  new_entry->next       = (Entry_t *)NULL;
  new_entry->previous   = (Entry_t *)NULL;

  if (Q_Log)
  {
    char  uuid_str[64];

    uuidtoa(new_entry->bitfile_id.ObjectID, uuid_str);
    tprintf("Q: Added File(%s)\n", uuid_str);
  }

  bu_log(BATCHLOG_REQUEST, new_entry->time_start, new_entry->filename, NULL, 0, 0, NULL, fsize, 0, jobid, new_entry->position, foffset, create_time);

  return(new_entry);
}

/*===================================================================================*/
/* search_for_entry() : Given the position information, find a matching entry in the */
/*                      queue.  (Should we have to verify the filename? or perform a */
/*                      comparison of bitfile Ids?  Assume that position is unique   */
/*                      enough.)                                                     */
/*                                                                                   */
/* Arguments:                                                                        */
/*      Queue_t          *Queue_Ptr                                                  */
/*      signed32          Position                                                   */
/*                                                                                   */
/* Externals: None                                                                   */
/*                                                                                   */
/* Return Values:                                                                    */
/*      Pointer to matching entry or NULL if not found.                              */
/*===================================================================================*/
 
static Entry_t * search_for_entry (Queue_t   *Queue_Ptr, /* In - Queue where file should be */
                                   signed32   Position,  /* In - Position of data start     */
                                   u_signed64 PosOffset)
{
  Entry_t  *rover_ptr;

  rover_ptr = Queue_Ptr->head;

  while (rover_ptr != (Entry_t *)NULL)
  {
    /* Test relative position informaton to determine if an entry is */
    /* already in the queue or not.                                  */

    if (rover_ptr->position == Position)
    {
      break;
    }

    rover_ptr = rover_ptr->next;
    rover_ptr = rover_ptr->next;
  }
  return(rover_ptr);
}

/*============================================================*/
/* destroy_entry() : Free up resources associated with entry. */
/*                                                            */
/* Arguments:                                                 */
/*    Entry_t   *Entry_Ptr                                    */
/*============================================================*/
 
static void destroy_entry(Entry_t  *Entry_Ptr) /* In - Pointer to entry */
{
  if (Q_Log)
  {
    char    uuid_str[64];

    uuidtoa(Entry_Ptr->bitfile_id.ObjectID, uuid_str);
    tprintf("Q: Removed File(%s)\n", uuid_str);
  }

  free(Entry_Ptr->filename);
  free(Entry_Ptr);

  return;
}
 
/*==========================================================================*/
/* insert_entry : Place an entry into the queue in ascending order based on */
/*                relative position of the start of data on tape.           */
/*                                                                          */
/* Arguments:                                                               */
/*    Queue_t   *Queue_Ptr                                                  */
/*    Entry_t   *Entry_Ptr                                                  */
/*==========================================================================*/

static void insert_entry (Queue_t *Queue_Ptr,  /* In - Queue to place entry into */
                          Entry_t *Entry_Ptr)  /* In - Entry member              */
{
  int       i;
  Entry_t   *rover_ptr;
  char      fsize[DEC64_LEN+1];
  char      foffset[DEC64_LEN+1];

  /* Common to all branches */

  Entry_Ptr->queue_ptr = Queue_Ptr;
  Queue_Ptr->num_entries++;

  if (Entry_Ptr->priority == PRIORITY_HIGH) {
    Queue_Ptr->high_priority++;
  }

  if (Entry_Ptr->priority == PRIORITY_MEDIUM) {
    Queue_Ptr->medium_priority++;
  }

  /* Start with an empty queue. */
 
  if (Queue_Ptr->head == (Entry_t *)NULL)
  {
    Entry_Ptr->next = (Entry_t *)NULL;
    Entry_Ptr->previous = (Entry_t *)NULL;
    Queue_Ptr->head = Entry_Ptr;
    Queue_Ptr->tail = Entry_Ptr;
  }
  else
  {
    /* Non-empty queue.  Start by looking at new entry's position in */
    /* comparison with positions of items already in queue.          */

    rover_ptr = Queue_Ptr->head;

    while (rover_ptr != (Entry_t *)NULL)
    {
      /* Do an insert if the new item's position is less than the current */
      /* entry's value.                                                   */

      if (Entry_Ptr->position == rover_ptr->position) /* Same Pos?  Must be aggregated, use Offset */
      {
        /* Two cases: 1st is the condition of the first entry in the queue.  */
        /* 2nd case is the normal one where we will be inserting between two */
        /* already existing entries.                                         */

        if (Entry_Ptr->offset_double < rover_ptr->offset_double) {
          if (rover_ptr->previous == (Entry_t *)NULL)  /* First entry... */
            Queue_Ptr->head = Entry_Ptr;
          else 
            rover_ptr->previous->next = Entry_Ptr;     /* Normal, insert it */

          /* Common code to both cases */

          Entry_Ptr->previous = rover_ptr->previous;
          Entry_Ptr->next = rover_ptr;
          rover_ptr->previous = Entry_Ptr;

          strcpy(fsize, u64tostr(Entry_Ptr->length));
          strcpy(foffset, u64tostr(Entry_Ptr->pos_offset));

          if (Q_Log)
          {
            char   uuid_str1[64], uuid_str2[64];

            uuidtoa(Queue_Ptr->queue_name.ObjectID, uuid_str1);
            uuidtoa(Entry_Ptr->bitfile_id.ObjectID, uuid_str2);
            tprintf("Q: Inserted File [%s](%s) into PVR[%d]->Queue(%s), position: %ld, offset: %s\n", Entry_Ptr->filename, uuid_str2, Entry_Ptr->queue_ptr->master_queue->pvrid, uuid_str1, Entry_Ptr->position, foffset);
          }

          bu_log(BATCHLOG_QUEUED, Entry_Ptr->time_start, Entry_Ptr->filename, Entry_Ptr->vol_num, Entry_Ptr->queue_ptr->master_queue->pvrid, 0, NULL, fsize, 0, NULL, Entry_Ptr->position, foffset, 0);
          bu_files_queued_incr();
          return;
        }
      }

      if (Entry_Ptr->position < rover_ptr->position)
      {
        /* Two cases: 1st is the condition of the first entry in the queue.  */
        /* 2nd case is the normal one where we will be inserting between two */
        /* already existing entries.                                         */

        if (rover_ptr->previous == (Entry_t *)NULL)  /* First entry... */
          Queue_Ptr->head = Entry_Ptr;
        else 
          rover_ptr->previous->next = Entry_Ptr;     /* Normal, insert it */

        /* Common code to both cases */

        Entry_Ptr->previous = rover_ptr->previous;
        Entry_Ptr->next = rover_ptr;
        rover_ptr->previous = Entry_Ptr;

        if (Q_Log)
        {
          char   uuid_str1[64], uuid_str2[64];

          uuidtoa(Queue_Ptr->queue_name.ObjectID, uuid_str1);
          uuidtoa(Entry_Ptr->bitfile_id.ObjectID, uuid_str2);
          tprintf("Q: Inserted File [%s](%s) into PVR[%d]->Queue(%s), position: %ld, offset: %s\n", Entry_Ptr->filename, uuid_str2, Entry_Ptr->queue_ptr->master_queue->pvrid, uuid_str1, Entry_Ptr->position, foffset);

        }

        strcpy(fsize, u64tostr(Entry_Ptr->length));
        strcpy(foffset, u64tostr(Entry_Ptr->pos_offset));
        bu_log(BATCHLOG_QUEUED, Entry_Ptr->time_start, Entry_Ptr->filename, Entry_Ptr->vol_num, Entry_Ptr->queue_ptr->master_queue->pvrid, 0, NULL, fsize, 0, NULL, Entry_Ptr->position, foffset, 0);
        bu_files_queued_incr();
        return;
      }

      rover_ptr = rover_ptr->next;
    }

    /* Only one condition left.  We must place the entry at the end of the */
    /* list.                                                               */

    Entry_Ptr->next       = (Entry_t *)NULL;
    Entry_Ptr->previous   = Queue_Ptr->tail;
    Queue_Ptr->tail->next = Entry_Ptr;
    Queue_Ptr->tail       = Entry_Ptr;
  }

  if (Q_Log)
  {
    char   uuid_str1[64], uuid_str2[64];

    uuidtoa(Queue_Ptr->queue_name.ObjectID, uuid_str1);
    uuidtoa(Entry_Ptr->bitfile_id.ObjectID, uuid_str2);
    tprintf("Q: Inserted File [%s](%s) into PVR[%d]->Queue(%s), position: %ld, offset: %s\n", Entry_Ptr->filename, uuid_str2, Entry_Ptr->queue_ptr->master_queue->pvrid, uuid_str1, Entry_Ptr->position, foffset);
  }
  if (Q_Lock) tprintf("Q: insert_entry(%x): SQL_LOG start\n", Entry_Ptr);

  strcpy(fsize, u64tostr(Entry_Ptr->length));
  strcpy(foffset, u64tostr(Entry_Ptr->pos_offset));
  bu_log(BATCHLOG_QUEUED, Entry_Ptr->time_start, Entry_Ptr->filename, Entry_Ptr->vol_num, Entry_Ptr->queue_ptr->master_queue->pvrid, 0, NULL, fsize, 0, NULL, Entry_Ptr->position, foffset, 0);
  if (Q_Lock) tprintf("Q: insert_entry(%x): SQL_LOG end\n", Entry_Ptr);
  bu_files_queued_incr();

  return;
}
 
/*==========================================================*/
/* remove_entry() : Remove the given entry from the queue.  */
/*                                                          */
/* Arguments:                                               */
/*      Entry_t         *Entry_Ptr                          */
/*                                                          */
/* Externals: None                                          */
/*                                                          */
/* Return Values: None                                      */
/*                                                          */
/* Assumptions:                                             */
/*      We've been given a valid entry to start with.       */
/*==========================================================*/

static void remove_entry ( Entry_t  *Entry_Ptr)  /* In - Entry member */
{
  Queue_t *queue_ptr;

  /* Common to all branches */

  queue_ptr            = Entry_Ptr->queue_ptr;

  if (Entry_Ptr->priority == PRIORITY_HIGH)
    queue_ptr->high_priority--;

  if (Entry_Ptr->priority == PRIORITY_MEDIUM)
    queue_ptr->medium_priority--;

  Entry_Ptr->queue_ptr = (Queue_t *)NULL;
  queue_ptr->num_entries--;

  /* Case of only one entry. */

  if ((Entry_Ptr->next == (Entry_t *)NULL) &&
      (Entry_Ptr->previous == (Entry_t *)NULL))
  {
    queue_ptr->head = (Entry_t *)NULL;
    queue_ptr->tail = (Entry_t *)NULL;
  }
  else
  if (Entry_Ptr->next == (Entry_t *)NULL)
  {
    /* Case of last entry in list. */
    queue_ptr->tail = Entry_Ptr->previous;
    Entry_Ptr->previous->next = (Entry_t *)NULL;
    Entry_Ptr->previous = (Entry_t *)NULL;
  }
  else
  if (Entry_Ptr->previous == (Entry_t *)NULL)
  {
    /* Case of first entry in list. */
    queue_ptr->head = Entry_Ptr->next;
    Entry_Ptr->next->previous = (Entry_t *)NULL;
    Entry_Ptr->next = (Entry_t *)NULL;
  }
  else
  {
    /* Last case with an entry having both a previous and next entry. */
    Entry_Ptr->next->previous = Entry_Ptr->previous;
    Entry_Ptr->previous->next = Entry_Ptr->next;
    Entry_Ptr->next = (Entry_t *)NULL;
    Entry_Ptr->previous = (Entry_t *)NULL;
  }

  if (Q_Log)
  {
    char   uuid_str1[64], uuid_str2[64];

    uuidtoa(queue_ptr->queue_name.ObjectID, uuid_str1);
    uuidtoa(Entry_Ptr->bitfile_id.ObjectID, uuid_str2);
    tprintf("Q: Removed File(%s) from Queue(%s)\n", uuid_str2, uuid_str1);
  }
  bu_files_queued_decr();

  return;
}

/*======================================================================*/
/* dump_queue() : Dump the current queue                                */
/*                                                                      */
/* Arguments:                                                           */
/*      Queue_t    *Queue_Ptr                                           */
/*      int        opt                                                  */
/*======================================================================*/
void dump_queue(Queue_t  *Queue_Ptr, int opt,
                          Entry_t *Entry_Ptr)  
{
  Entry_t  *rover_ptr, *active_ptr;
  char  Q_uuid_str[64];
  char  cur_entry[4];
  char  foffset[DEC64_LEN+1];

  rover_ptr = Queue_Ptr->head;

  if (opt == 0)
      return;

  uuidtoa(Queue_Ptr->queue_name.ObjectID, Q_uuid_str);
  tprintf("Dump Queue[%s]: %s\n", Queue_Ptr->volnum, Q_uuid_str);

  while (rover_ptr != (Entry_t *)NULL) {
      strcpy(cur_entry, "  ");

      if (rover_ptr->active)
          strcpy(cur_entry, "=>");
      if (rover_ptr == Entry_Ptr)
          strcpy(cur_entry, " *");

      strcpy(foffset, u64tostr(rover_ptr->pos_offset));

      printf("  %s%ld:%s\t%s\n", cur_entry, rover_ptr->position, foffset, rover_ptr->filename);

      rover_ptr = rover_ptr->next;
  }
  printf("    End of Queue\n");
}

/*======================================================================*/
/* set_active_entry() : Find and set a new entry as active for staging. */
/*                                                                      */
/* Arguments:                                                           */
/*      Queue_t    *Queue_Ptr                                           */
/*======================================================================*/

static Entry_t * set_active_entry(Queue_t  *Queue_Ptr) /* In - Queue to set entry */
{
  Entry_t  *rover_ptr;
  Entry_t  *active_ptr;

  dump_queue(Queue_Ptr, Q_Dump, NULL);

  /* Find Current active one, so we will continue to read forward, not backward */
  active_ptr = Queue_Ptr->head;
  while (active_ptr->next != (Entry_t *)NULL) {
      if (active_ptr->active)
          break;
      active_ptr = active_ptr->next;
  }
  if (active_ptr == (Entry_t *)NULL)  /* No active entry yet... */
      active_ptr = Queue_Ptr->head;

  /* Find an inactive entry.  Entries are in ascending order, keying off of */
  /* position on the virtual volume of the first data block.                */
 
  /* If it's the end of the queue, go back to the begining */
  if (active_ptr->next == (Entry_t *)NULL) {
      rover_ptr = Queue_Ptr->head;
      if (Q_Log) {
         tprintf("Q: No activated entry found in queue [%s].\n", Queue_Ptr->volnum);
      }
  }
  else {
      rover_ptr = active_ptr;
  }

  if (rover_ptr != (Entry_t *)NULL) {
      while (rover_ptr->active) {
          rover_ptr = rover_ptr->next;
          if (rover_ptr == (Entry_t *)NULL) {
              break;
          }
      }
  }

  /* Set the entry active and increment the number of active entries */

  if (rover_ptr != (Entry_t *)NULL)
  {
    rover_ptr->active = TRUE;
    Queue_Ptr->num_active_entries++;

    if (Q_Log)
    {
       char  uuid_str[64];

       uuidtoa(rover_ptr->bitfile_id.ObjectID, uuid_str);
       tprintf("Q: Activating [%s] File \"%s\" (%s)\n", Queue_Ptr->volnum, rover_ptr->filename, uuid_str);
    }
  }
  return(rover_ptr);
}

/*=====================================================================================*/
/* unset_active_entry(): Remove the active status to an entry that has been staged.    */
/*                                                                                     */
/* Arguments:                                                                          */
/*    Entry_t   *Entry_Ptr                                                             */
/*=====================================================================================*/

static void unset_active_entry(Entry_t  *Entry_Ptr)      /* In - Entry member */
{
  Entry_Ptr->queue_ptr->num_active_entries--;
  Entry_Ptr->active = FALSE;

  if (Q_Log)
  {
    char    uuid_str[64];

    uuidtoa(Entry_Ptr->bitfile_id.ObjectID, uuid_str);
    tprintf("Q: Deactivating File [%s] (%s)\n", Entry_Ptr->filename, uuid_str);
  }

  return;
}

/*=====================================================================================*/
/* create_queue(): Create a new queue with the name of vvid associated with its tape   */
/*                 storage.                                                            */
/*                                                                                     */
/* Arguments:                                                                          */
/*     hpssoid_t    *Queue_Name                                                        */
/*                                                                                     */
/* Externals:                                                                          */
/*     int  errnor (if an error occurs)                                                */
/*                                                                                     */
/* Return Values:                                                                      */
/*     The pointer to the new queue or NULL upon an error.                             */
/*=====================================================================================*/

static Queue_t * create_queue(hpssoid_t *Queue_Name, char* volnum)    /* In - Name of new queue */
{
  Queue_t  *new_queue;

  /* Get memory for the new queue element. */
  new_queue = (Queue_t *)malloc(sizeof(Queue_t));

  if (new_queue == (Queue_t *)NULL)
    return(new_queue);   /* Calling program handles error */
 
  /* Now initialize the new queue's components. */
  memcpy(&new_queue->queue_name,Queue_Name,sizeof(hpssoid_t));
  new_queue->num_entries        = 0;
  new_queue->num_active_entries = 0;
  new_queue->active             = FALSE;
  new_queue->high_priority      = 0;
  new_queue->medium_priority    = 0;
  new_queue->head               = (Entry_t *)NULL;
  new_queue->tail               = (Entry_t *)NULL;
  strcpy(new_queue->volnum, volnum);
  
  if (Q_Log)
  {
    char    uuid_str[64];

    uuidtoa(new_queue->queue_name.ObjectID, uuid_str);
    tprintf("Q: Creating Queue(%s) [%s]\n",uuid_str, new_queue->volnum);
  }

  return(new_queue);
}

/*======================================================================*/
/* search_for_queue() : Find a matching queue in our list of queues.    */
/*                                                                      */
/* Arguments:                                                           */
/*    hpssoid_t  *Queue_Name                                            */
/*                                                                      */
/* Externals:                                                           */
/*    Master_Queue_t  Master_Queue                                      */
/*                                                                      */
/* Return Values:                                                       */
/*    Pointer to found queue or NULL if it doesnt exist.                */
/*======================================================================*/

static Queue_t * search_for_queue(hpssoid_t *Queue_Name, int pvr)   /* In - Name of queue being sought */
{
  Queue_t  *rover_ptr;

  rover_ptr = Master_Queue[pvr].head;

  while (rover_ptr != (Queue_t *)NULL)
  {
    if (memcmp(&rover_ptr->queue_name, Queue_Name, sizeof(hpssoid_t)) == 0)
      break;

    rover_ptr = rover_ptr->next;
  }

  return(rover_ptr);
}

/*===================================================================*/
/* destroy_queue() : To free up resources associated with a queue.   */
/*                                                                   */
/* Arguments:                                                        */
/*    Queue_t  *Queue_Ptr                                            */
/*===================================================================*/
 
static void destroy_queue(Queue_t *Queue_Ptr)  /* In - Pointer to queue */
{
  if (Q_Log)
  {
    char  uuid_str[64];
 
    uuidtoa(Queue_Ptr->queue_name.ObjectID,uuid_str);
    tprintf("Q: Destroying Queue(%s)\n",uuid_str);
  }

  free(Queue_Ptr);
  return;
}

/*=====================================================================================*/
/* insert_queue(): Insert a new queue into our list of queues. Insertion of a new queue*/
/*                 always occurs at the end of the list.                               */
/*                                                                                     */
/* Arguments:                                                                          */
/*     Queue_t       *Queue_Ptr                                                        */
/*                                                                                     */
/* Externals:                                                                          */
/*     Master_Queue_t  Master_Queue                                                    */
/*=====================================================================================*/
 
static void insert_queue(Queue_t *Queue_Ptr, int pvr) /* In - Pointer to queue */
{
  /* Special case if queue is empty. Otherwise, last queue will now point to the new queue */
  
  if (Master_Queue[pvr].head == (Queue_t *)NULL)
    Master_Queue[pvr].head = Queue_Ptr;
  else
    Master_Queue[pvr].tail->next = Queue_Ptr;

  /* Link other pointers and increment the queue count. */
  Queue_Ptr->previous = Master_Queue[pvr].tail;
  Queue_Ptr->next     = (Queue_t *)NULL;
  Queue_Ptr->master_queue  = &Master_Queue[pvr];
  Master_Queue[pvr].tail   = Queue_Ptr;
  Master_Queue[pvr].num_queues++;

  if (Q_Log)
  {
    char  uuid_str[64];

    uuidtoa(Queue_Ptr->queue_name.ObjectID, uuid_str);
    tprintf("Q: Inserting Queue(%s)(%x)\n", uuid_str, Queue_Ptr);
  }

  return;
}

/*====================================================================*/
/* remove_queue(): To remove an unused queue from our list of queues. */
/*                                                                    */
/* Arguments:                                                         */
/*     Queue_t   *Queue_Ptr                                           */
/*                                                                    */
/* Externals:                                                         */
/*     Master_Queue_t   Master_Queue                                  */
/*====================================================================*/

static void remove_queue(Queue_t  *Queue_Ptr, int MQ_index)  /* In - Pointer to queue */
{
  if ((Queue_Ptr->next     == (Queue_t *)NULL) &&    /* Case of only one queue */
      (Queue_Ptr->previous == (Queue_t *)NULL)
     )
  {
    Master_Queue[MQ_index].head = (Queue_t *)NULL;
    Master_Queue[MQ_index].tail = (Queue_t *)NULL;
  }
  else
  if (Queue_Ptr->next == (Queue_t *)NULL)            /* remove last queue in list */
  {
    Queue_Ptr->previous->next = (Queue_t *)NULL;
    Master_Queue[MQ_index].tail         = Queue_Ptr->previous;
  }
  else
  if (Queue_Ptr->previous == (Queue_t *)NULL)        /* remove first queue in list */
  {
    Queue_Ptr->next->previous = (Queue_t *)NULL;
    Master_Queue[MQ_index].head = Queue_Ptr->next;
  }
  else                                               /* Queue is in the middle of the list */
  {
    Queue_Ptr->next->previous = Queue_Ptr->previous;
    Queue_Ptr->previous->next = Queue_Ptr->next;
  }

  /* Common code */

  Queue_Ptr->next     = (Queue_t *)NULL;
  Queue_Ptr->previous = (Queue_t *)NULL;
  Master_Queue[MQ_index].num_queues--;
 
  if (Q_Log)
  {
    char  uuid_str[64];
  
    uuidtoa(Queue_Ptr->queue_name.ObjectID,uuid_str);
    tprintf("Q: Remove Queue(%s)\n",uuid_str);
  }

  return;
}

/*=====================================================================*/
/* set_active_queue(): Find and set a new queue as active for staging. */
/*                                                                     */
/* Externals:                                                          */
/*     Master_Queue_t  Master_Queue                                    */
/*                                                                     */
/* Assumptions:                                                        */
/*     There is at least one queue available to make active.           */
/*=====================================================================*/

static void set_active_queue(int pvr) 
{
  Queue_t    *rover_ptr, *active_queue;
  char       uuid_str[64];
  int alg_altered=0;

  active_queue = (Queue_t *)NULL;
  rover_ptr    = Master_Queue[pvr].head;

  /* Loop through the entire list of queues finding ones that are not */
  /* currently active.                                                */
  
/*
  if (Q_Log) {
    tprintf("Dump Queue\n");
  }
*/
  if (Master_Queue[pvr].pri_high > 0 ) {
    if (Q_Log) tprintf("PVR %d has at least one high priority request, Queue-Selection is switching to PRIORITY\n", pvr);
    alg_altered=1;
  } else
  if (Master_Queue[pvr].pri_med > 0) {
    if (Q_Log) tprintf("PVR %d has at least one med priority request, Queue-Selection is switching to PRIORITY\n", pvr);
    alg_altered=1;
  }

  while (rover_ptr != (Queue_t *)NULL)
  {
    if (Q_Log) {
      tprintf("Q: MQ[%d] Queue [%s|H:%d|L:%d|D:%d]\n",pvr, rover_ptr->volnum, rover_ptr->high_priority, rover_ptr->medium_priority, rover_ptr->num_entries);
    }
      
    if (rover_ptr->active == FALSE) 
    {
      if (active_queue == (Queue_t *)NULL)  /* If this is the first inactive queue, start with it */
        active_queue = rover_ptr;
      else {

        if ( q_alg == 0 || alg_altered ) {
          /* Default Logic */
          if (rover_ptr->high_priority > active_queue->high_priority)  
            /* if we encounter another inactive queue,      */
            active_queue = rover_ptr;                                  
            /* compare high pripriority counts if any exist */
          else
          if ((rover_ptr->high_priority == 0) &&            
            /* Do the same for medium priority counts. */
              (rover_ptr->medium_priority > active_queue->medium_priority))
            active_queue = rover_ptr;
        }
        else if (q_alg == QUE_SIZE_DESC ) {
          /* Queue selecting Logic - based on Queue Size large to small */
          if (rover_ptr->num_entries > active_queue->num_entries)
              active_queue = rover_ptr;
        }
        else if (q_alg == QUE_SIZE_ASC) {
          /* Queue selecting Logic - based on Queue Size small to large */
          if (rover_ptr->num_entries < active_queue->num_entries)
              active_queue = rover_ptr;
        }
      }
    }
 
    rover_ptr = rover_ptr->next;
  }

  /* We have a problem. Internal structure of our queues is hosed or the calling */
  /* program has made a bad assumptions.                                         */
         
  if (active_queue == (Queue_t *)NULL)
  {
    dtprintf(HERE,"ERROR: no available queues, dumping queue...\n");
    exit(-1);
  }

  /* Set the entry active and increment the number of active entries */

  active_queue->active = TRUE;
  Master_Queue[pvr].num_active++;

/*
  if (Q_Log)
  {
    uuidtoa(active_queue->queue_name.ObjectID,uuid_str);
    tprintf("Q: MQ[%d] Activate Queue [%s|H:%d|L:%d|D:%d]\n",pvr, active_queue->volnum, active_queue->high_priority, active_queue->medium_priority, active_queue->num_entries);
  }
*/

/*
printf("hpss_queue: set_active_queue: uuid_str = %s\n", uuid_str);
*/

  return;
}
 
/*=============================================================*/
/* unset_active_queue() : Remove the active status of a queue. */
/*                                                             */
/* Arguments:                                                  */
/*     Queue_t   *Queue_Ptr                                    */
/*                                                             */
/* Externals:                                                  */
/*     Master_Queue_t   Master_Queue                           */
/*=============================================================*/

static void unset_active_queue(Queue_t *Queue_Ptr, int MQ_index) /* In - Pointer to Queue */
{
  if (Q_Log)
      tprintf("%s %d: unset_active_queue(MQ[%d])\n", __FILE__, __LINE__, MQ_index);
  Master_Queue[MQ_index].num_active--;
  Queue_Ptr->active = FALSE;

  if (Q_Log)
  {
    char  uuid_str[64];

    uuidtoa(Queue_Ptr->queue_name.ObjectID,uuid_str);
    tprintf("Q: Deactivating Queue(%s)\n",uuid_str);
  }

  return;
}
    
/*=====================================================================================*/
/* hpss_GetStorageLevel_Etc(): This poorly named function atempts to get a bunch of    */
/*                             information from the BFS on how and where a file is     */
/*                             stored.                                                 */
/*                                                                                     */
/* Arguments:                                                                          */
/*     char          *Filename                                                         */
/*     hpssoid_t     *BitFile_Id                                                       */
/*     u_signed64    *Length                                                           */
/*     hpssoid_t     *VVID                                                             */
/*     signed32      *Position                                                         */
/*     unsigned32    *File_Type                                                        */
/*     unsigned32    *Composite_Perms                                                  */
/*     signed32      *Storage_Level                                                    */
/*                                                                                     */
/* Externals:                                                                          */
/*     int           errno (if an error occurs)                                        */
/*                                                                                     */
/* Return Values:                                                                      */
/*     0 if successful, otherwise an error code                                        */
/*                                                                                     */
/* Assumptions:                                                                        */
/*     A bunch                                                                         */
/*=====================================================================================*/

int hpss_GetStorageLevel_Etc( char    *Filename,            /* In  - Name of file                 */
                                     hpssoid_t  *BitFile_Id,       /* Out - Bit file id                  */
                                     u_signed64 *Length,           /* Out - Length of file               */
                                     hpssoid_t  *VVID,             /* Out - VVID of file, if on tape     */
                                     signed32   *Position,         /* Out - Position of file, if on tape */
                                     u_signed64 *PosOffset,        /* Out - Position of file, if on tape */
                                     unsigned32 *File_Type,        /* Out - Kind of file                 */
                                     unsigned32 *Composite_Perms,  /* Out - Omni-Perms                   */
                                     signed32   *Storage_Level,    /* Out - Level in hierarchy           */
                                     cos_t      *Cos_Id,    	   /* Out - Class of services            */
                                     char       *Vol_Name,     	   /* Out - Physical Volume Name         */
                                     time_t     *create_time       /* Out - File create time for job     */
                                     )
{
  int              rc;
  int              retry_cnt;
  int              i;
  int              j;
  signed32         pos;
  hpss_xfileattr_t file_attr;
  unsigned32       flags;
  unsigned32       storagelevel;
  char             uuid_str[64];
  int              foundVol=0;
 
  retry_cnt = -1;
  u_signed64 size;

  char volnum[10];
  char errmsg[256];

retry:
  retry_cnt++;

  flags     = API_GET_STATS_FOR_ALL_LEVELS;
  storagelevel     = 0;

  rc = bu_check_black_list(Filename, &size, volnum, &pos);

  if ( rc > 0 ) { 
    return(rc);
  }

  rc = hpss_FileGetXAttributes(Filename,flags,storagelevel,&file_attr);

  if (rc < 0)
  {
    if (retry_cnt < bu_getRetryVal(rc))
    {
      fprintf(stderr,"hpss_FileGetXAttributes: %d, retry(%d)..\n", rc, retry_cnt);
      sleep(Retry_Delay.tv_sec);
      goto retry;
    }
    return(rc);
  }

  for (i=0; i<HPSS_MAX_STORAGE_LEVELS; i++)
  {
    if (file_attr.SCAttrib[i].Flags == 0)
    {
      if (i == 0)
      {
        if (file_attr.Attrs.Type == NS_OBJECT_TYPE_FILE)
        {
          fprintf(stderr,"No segments exist for this file?\n");
          return(-2);
        }
        return(-EISDIR);
      }
      return(0);
    }

    if (file_attr.SCAttrib[i].Flags & BFS_BFATTRS_DATAEXISTS_AT_LEVEL)
    {
      memcpy(BitFile_Id,&file_attr.Attrs.BitfileId,sizeof(hpssoid_t));
      *Length = file_attr.SCAttrib[i].BytesAtLevel;

/*
      memcpy(VVID,&file_attr.SCAttrib[i].VVAttrib[0].VVID,sizeof(hpssoid_t));
      *Position        = file_attr.SCAttrib[i].VVAttrib[0].RelPosition;
      *PosOffset       = file_attr.SCAttrib[i].VVAttrib[0].RelPositionOffset;
*/
      *File_Type       = file_attr.Attrs.Type;
      *Composite_Perms = file_attr.Attrs.CompositePerms;
      *Cos_Id          = file_attr.Attrs.COSId;
      *create_time     = file_attr.Attrs.TimeCreated;
      *Storage_Level   = i;
    }
 
    for (j=0; j<file_attr.SCAttrib[i].NumberOfVVs; j++)
    {
      if ( file_attr.SCAttrib[i].VVAttrib[j].PVList != NULL) {

        /* Only use the 1st found copy... */
        if ( !foundVol ) {
            memcpy(VVID,&file_attr.SCAttrib[i].VVAttrib[0].VVID,sizeof(hpssoid_t));
            memcpy(Vol_Name, 
               file_attr.SCAttrib[i].VVAttrib[j].PVList[0].List.List_val[0].Name,
               VOL_NAME_LEN);
            Vol_Name[VOL_NAME_LEN] = '\0';

            *Position        = file_attr.SCAttrib[i].VVAttrib[j].RelPosition;
            *PosOffset       = file_attr.SCAttrib[i].VVAttrib[j].RelPositionOffset;
            foundVol++;
        }

        free(file_attr.SCAttrib[i].VVAttrib[j].PVList[0].List.List_val);
        free(file_attr.SCAttrib[i].VVAttrib[j].PVList);
      }
    }
  }

  return(0);
}

/*=====================================================================================*/
/* Queue_Worker() : This is the routine which actually performs the stage. This        */
/*                  function is spawned from Mr_Monitor_Queue() and keeps staging      */
/*                  files until the queue is empty.                                    */
/*                                                                                     */
/* Arguments:                                                                          */
/*    void   *Arg (But it is really an (Entry_t *) pointer)                            */
/*                                                                                     */
/* Externals:                                                                          */
/*    Master_Queue_t  Master_Queue                                                     */
/*=====================================================================================*/
 
static void Queue_Worker(void *Arg)
{
  int       rc, fid = 0, retry_cnt, pvr_locked=0;
  Entry_t  *stage_entry_ptr;
  Queue_t  *queue_ptr;
  char      uuid_str[64];
  int pvr, MQ_index, locked = 1;
  int err_h_idx = 0;
  char      fsize[DEC64_LEN+1];
  char      foffset[DEC64_LEN+1];

  /* Initialize our pointers to the current entry and queue the entry resides in */

  stage_entry_ptr = (Entry_t *)Arg;
  queue_ptr       = stage_entry_ptr->queue_ptr;
  pvr = queue_ptr->master_queue->pvrid;
 
  /* Loop until there is no more work to do. */

  do
  {
    pvr_locked=0;
    /* Check if the PVR is locked.  If yes, hold the job submission... until the PVR is unlocked */
    MQ_index = search_MQ_by_pvr(pvr);  /* Always get from the latest table */
    while (Master_Queue[MQ_index].max_num_queues == 0) {
        if ( ! pvr_locked) {
            tprintf("*** PVR[%s] is locked, %s staging is on hold. ***\n", Master_Queue[MQ_index].pvr_name, stage_entry_ptr->vol_num );
            tprintf("FIle %s is on hold.\n", stage_entry_ptr->filename);
            pvr_locked=1;
        }
        sleep(5);
    }

    if ( pvr_locked ) {
        tprintf("*** PVR[%s] is unlocked, %s staging continues. ***\n", Master_Queue[MQ_index].pvr_name, stage_entry_ptr->vol_num );
    }
    

    if (Q_Log)
    {
      char  Q_uuid_str[64];
      uuidtoa(queue_ptr->queue_name.ObjectID, Q_uuid_str);
      uuidtoa(stage_entry_ptr->bitfile_id.ObjectID, uuid_str);
      tprintf("Q: Queue_Worker(): PVR[%d]|Thread:%x]|Staging File \"%s\" (%s) from Queue[%s]\n", stage_entry_ptr->queue_ptr->master_queue->pvrid, pthread_self(), stage_entry_ptr->filename, uuid_str, Q_uuid_str);
    }
    /*  Log the Staging Time */
    strcpy(fsize, u64tostr(stage_entry_ptr->length));
    strcpy(foffset, u64tostr(stage_entry_ptr->pos_offset));
    bu_log(BATCHLOG_STAGING, stage_entry_ptr->time_start, stage_entry_ptr->filename, stage_entry_ptr->vol_num, pvr, 0, NULL, fsize, locked, NULL, 0, foffset, 0);

    if (bu_check_lsm_status(stage_entry_ptr->vol_num) == 1) {
        printf ("Cartridge is located in a offline LSM, unable to Stage.  Return error %d\n", -HPSS_LSM_DOWN);
        bu_log(BATCHLOG_FAILED, stage_entry_ptr->time_start, stage_entry_ptr->filename, NULL, 0, -HPSS_LSM_DOWN, NULL, 0, 0, NULL, 0, 0, 0);
        goto StageCompleted;
    }

    bu_files_staging_incr();
 
    /* First try to open the file for read only.  This should be okay since  */
    /* we already tested for read access in the hpss_QueueFileX routine.  If */
    /* the mode changed on the file between then and now... Oh well the user */
    /* loses.                                                                */
 
    retry_cnt = -1;

retry1:
    retry_cnt++;

    if (stage_opt == 0) {
        fid = hpss_Open(stage_entry_ptr->filename, O_RDONLY, 0,
                    (hpss_cos_hints_t *) NULL,
                    (hpss_cos_priorities_t *) NULL,
                    (hpss_cos_hints_t *) NULL);
    }

    if (fid < 0)
    {
      printf ("fid: %d, Retry value: %d\n", fid, bu_getRetryVal(fid));
      if (retry_cnt < bu_getRetryVal(fid))
      {
        if (Q_Log) tprintf("Queue_Worker: hpss_Open: %d, retrying(%d).. [%s]\n", fid, retry_cnt, stage_entry_ptr->filename);
        sleep(Retry_Delay.tv_sec);
        goto retry1;
      } 

      dtprintf(HERE, "ERROR: hpss_Open(%s) failed: rc = %d\n", stage_entry_ptr->filename, fid);
      bu_log(BATCHLOG_FAILED, stage_entry_ptr->time_start, stage_entry_ptr->filename, NULL, 0, fid, NULL, 0, 0, NULL, 0, 0, 0);
      bu_files_staging_decr();
    }
    else
    {
      /* Now try to stage the file.  This call will block until the stage is */
      /* complete.  The user loses if this call fails.                       */
      retry_cnt = -1;
retry2:
      retry_cnt++;

    if (stage_opt == 0) {
      if (Q_Log) tprintf("Queue_Worker: Calling hpss_Stage [%s] Synchonized Stage\n", stage_entry_ptr->filename);
      rc = hpss_Stage(fid, cast64m((unsigned32) 0),
                           stage_entry_ptr->length,
                           (unsigned long) 0, BFS_STAGE_ALL);
    } else {
      if (Q_Log) tprintf("Queue_Worker: Calling hpss_StageCallBack [%s] Asynchonized Stage\n", stage_entry_ptr->filename);
      rc = stage_callback_command(stage_entry_ptr->filename,
                                  cast64m((unsigned32) 0),
                                  stage_entry_ptr->length,
                                  (unsigned long) 0, BFS_STAGE_ALL);
    }

      if (rc < 0)
      {
        if (retry_cnt < bu_getRetryVal(rc))
        {
          tprintf("Queue_Worker: hpss_Stage: %d, retry(%d)..[%s]\n", rc, retry_cnt, stage_entry_ptr->filename);
          sleep(Retry_Delay.tv_sec);
          goto retry2;
        }

        dtprintf(HERE, "ERROR: hpss_Stage(%s) failed: rc = %d [%s]\n", stage_entry_ptr->filename, rc, stage_entry_ptr->filename);
        bu_log(BATCHLOG_FAILED, stage_entry_ptr->time_start, stage_entry_ptr->filename, NULL, 0, rc, NULL, 0, 0, NULL, 0, 0, 0);
        bu_files_staging_decr();
      }
      else
      {
        if (Q_Log)
        {
          tprintf("Q: PVR[%d]|Q[%x]|File [%s](%s)|Stage Complete in %d Seconds\n",
                  stage_entry_ptr->queue_ptr->master_queue->pvrid, pthread_self(), stage_entry_ptr->filename, uuid_str,
                  time((time_t *)NULL) - stage_entry_ptr->time_start);
        }

        if (batch_str.purlock_life > 0) {
            locked = hpss_PurgeLock(fid,PURGE_LOCK);
            if (Q_Log) {
              tprintf("Q: File \"%s\" Purge Lock = %d\n", 
                       stage_entry_ptr->filename, locked);
            }
        }

        strcpy(fsize, u64tostr(stage_entry_ptr->length));
        strcpy(foffset, u64tostr(stage_entry_ptr->pos_offset));
        bu_log(BATCHLOG_STAGED, stage_entry_ptr->time_start, stage_entry_ptr->filename, NULL, 0, 0, NULL, fsize, locked, NULL, 0, foffset, 0);
        bu_files_staging_decr();
      }

      hpss_Close(fid);
    }

StageCompleted:
    /* Now update the entry by removing its active status.  First lock the */
    /* data structure.                                                     */

//  Maybe not necessary....
    if (Q_Lock) tprintf("Queue_Worker: Trying to lock Master_Queue[%d]\n", MQ_index);
    lock(&Master_Queue[MQ_index].lock);
    if (Q_Lock) tprintf("Queue_Worker: Master_Queue[%d] is locked\n", MQ_index);
    unset_active_entry(stage_entry_ptr);

    /* Execute the function the user specified.  Pass along their argument as */
    /* well as any error code.                                                */

    if (stage_entry_ptr->function != (void (*)())NULL)
    {
      int     error_code = 0;

      if (fid < 0)
        error_code = fid;
      else
      if (rc < 0)
        error_code = rc;

      if (Q_Log)
      {
        tprintf("Q: PVR[%d]|Q[%x]: File(%s) Invoking User Function\n", stage_entry_ptr->queue_ptr->master_queue->pvrid, pthread_self(), uuid_str);
      }

      /* Security hole !!  User call and we are root! */

      stage_entry_ptr->function(stage_entry_ptr->func_arg, error_code);
    }

    /* Whether the staged worked or not, remove the entry from the queue and */
    /* destroy it.                                                           */

    if (stage_entry_ptr->priority == PRIORITY_HIGH)
        Master_Queue[MQ_index].pri_high--;
    if (stage_entry_ptr->priority == PRIORITY_MEDIUM)
        Master_Queue[MQ_index].pri_med--;

    remove_entry(stage_entry_ptr);
    destroy_entry(stage_entry_ptr);
    stage_entry_ptr = (Entry_t *)NULL;

    /* Now find a new entry to stage. */

    if (queue_ptr->num_entries > queue_ptr->num_active_entries)
    {
      stage_entry_ptr = set_active_entry(queue_ptr);
    }
    else
    if (queue_ptr->num_entries == 0)
    {
      /* Check to see if the queue is empty.  If so, remove and destroy it */
      unset_active_queue(queue_ptr, MQ_index);
      remove_queue(queue_ptr, MQ_index);
      destroy_queue(queue_ptr);
    }

    /* Unlock our data structure for other threads to use. */
    unlock(&Master_Queue[MQ_index].lock);
    if (Q_Lock) tprintf("Queue_Worker: Master_Queue[%d] is unlocked\n", MQ_index);

    /* Continue to loop until there are no more entries.  Then just exit the */
    /* thread.                                                               */
  }
  while (stage_entry_ptr != (Entry_t *)NULL);

  kill_thread("Queue_Worker");
}

/*=====================================================================================*/
/* Mr_Queue_Monitor() : Task that loops forever looking at the queue and the entries   */
/*                      therein to keep processing entries within the window specified */
/*                      at initialization.                                             */
/*                                                                                     */
/* Arguments:                                                                          */
/*    void   *Arg                                                                      */
/*                                                                                     */
/* Externals:                                                                          */
/*    Master_Queue_t  Master_Queue                                                     */
/*=====================================================================================*/

static void Mr_Queue_Monitor( void *Arg )    /* In - A no-op in our case */
{
  int                i, j, rc, new_queues, new_entries;
  Queue_t           *rover_queue_ptr, *new_active_queue, *Queue_Ptr;
  Entry_t           *rover_entry_ptr, *Entry_Ptr, *Tmp_Entry_Ptr;
  pthread_t          dummy;
  char               msg[512];
  struct timespec    delay_time;
  int		     delay_counter = 0;
#define DELAY_COUNTER 30
 
  /* The wakeup interval should all be the same, just use the first one */
  delay_time.tv_sec  = Master_Queue[0].poll_time;
  delay_time.tv_nsec = 0;
 
  /* Loop forever */
 
  while (TRUE)
  {
/*  Removed by David Yu at 2010-08-24
    if (Q_Log && delay_counter == DELAY_COUNTER ) 
        tprintf("++ Queue Monitor ++ DELAY_COUNTER: %d, Real delay: %d\n", delay_counter, delay_time.tv_sec);
*/

    for (j = 0; j < MAX_PVR_QUE; j++) {

    /* Start by locking the Master Queue */
        if (Q_Lock) tprintf("Queue Monitor: Trying to lock Master_Queue[%d]\n", j);
        lock(&Master_Queue[j].lock);
        if (Q_Lock) tprintf("Queue Monitor: Master_Queue[%d] is locked\n", j);

    /* Look to see if there is anything to do. Our job in life is to kickoff new */
    /* stage requests and decide which queues get priority.                      */

        if (Master_Queue[j].num_queues > 0)
        {
          Queue_Ptr = Master_Queue[j].head;
          while ( Queue_Ptr != NULL ) {
              Entry_Ptr = Queue_Ptr->head;
              while ( Entry_Ptr != NULL ) {  /* Queue NOT empty */
                  Tmp_Entry_Ptr = (Entry_t *) NULL;
                  if (Entry_Ptr->exp_time && (Entry_Ptr->exp_time < (time((time_t *)NULL)))){ /*Expired*/
                      Tmp_Entry_Ptr = Entry_Ptr->next;

                      bu_log(BATCHLOG_FAILED, Entry_Ptr->time_start, Entry_Ptr->filename, NULL, 0, (ETIME * -1), NULL, 0, 0, NULL, 0, 0, 0);
                      if (Q_Lock) tprintf("Queue Monitor: Request %s is expired.\n", Entry_Ptr->filename);
                      Entry_Ptr->function(Entry_Ptr->func_arg, (ETIME * -1));
                      remove_entry(Entry_Ptr);
                      destroy_entry(Entry_Ptr);
                      Entry_Ptr = Tmp_Entry_Ptr;
                  }
                  else
                      Entry_Ptr = Entry_Ptr->next;
              }
              Queue_Ptr = Queue_Ptr->next;
          }

      /* First check to see if we have enough active queues. If not, go mark a */
      /* queue active by determining who should be next. Look at priority and  */
      /* time on a queue to determine this.                                    */
          if (Master_Queue[j].num_queues > Master_Queue[j].max_num_queues)
          {
            new_queues = Master_Queue[j].max_num_queues - Master_Queue[j].num_active;
          }
          else
          {
            new_queues = Master_Queue[j].num_queues - Master_Queue[j].num_active;
          }

/*
          if (Q_Log) 
              tprintf("Queue Monitor: PVR[%d]: num_queues-%d, max_num_queues-%d,num_active-%d, new_queues-%d \n", Master_Queue[j].pvrid, Master_Queue[j].num_queues, Master_Queue[j].max_num_queues, Master_Queue[j].num_active, new_queues );
*/
       
      /* dyu 03-01-06: The queue is a link list, so the most easist way to sort
                       is the linier search, the function set_active_queue() 
                       will only loop once, so we need the outer loop outside
                       this function.  */
          for (i=0; i<new_queues; i++)
          {
            set_active_queue(j);
          }
 
        }
    /* For each active queue, look to see if we have the full number of possible */
    /* entries active or not. If not, start new stage worker bees for each entry */
    /* to be made active. Since each worker bee will start a new entry when      */
    /* complete with the current one, our work here is actually simplified.      */
 
        rover_queue_ptr = Master_Queue[j].head;

        while (rover_queue_ptr != (Queue_t *)NULL)
        {
          if (rover_queue_ptr->active)
          {
            if (rover_queue_ptr->num_entries > Master_Queue[j].queue_depth)
            {
              new_entries = Master_Queue[j].queue_depth - rover_queue_ptr->num_active_entries;
            }
            else
            {
              new_entries = rover_queue_ptr->num_entries - rover_queue_ptr->num_active_entries;
            } 
 
            for (i=0; i<new_entries; i++)
            {
              rover_entry_ptr = set_active_entry(rover_queue_ptr);
              if (rover_entry_ptr != (Entry_t *)NULL) {
                if (Q_Log) tprintf("== Spawning Queue Worker (Vol: [%s])==\n", rover_entry_ptr->vol_num);
                spawn_thread(&dummy, Queue_Worker, rover_entry_ptr, "Queue_Worker");
              }
            }
          } 
 
          rover_queue_ptr = rover_queue_ptr->next;
        }

    /* Unlock the Master Queue before going to sleep a while */
        unlock(&Master_Queue[j].lock);
        if (Q_Lock) tprintf("Queue Monitor: Master_Queue[%d] is unlocked\n", j);
    }
/* Removed by David Yu at 2010-08-24
    if (Q_Log && delay_counter == DELAY_COUNTER) tprintf("-- Queue Monitor --\n");
*/
    if (delay_counter == DELAY_COUNTER)
        delay_counter = 0;
    else
        delay_counter++;

/* tv_sec = POLL_TIME = 2 secs  */
    if (Q_Lock) tprintf("Queue Monitor: Sleeping for %d secs\n", delay_time.tv_sec);
    sleep(delay_time.tv_sec);
  }

  /* Never get here */

  return;
}

int get_pvr_queue_by_vol_name(char *vol_name, int *tape_status)
{
   int pvrid, i, queue_id = -1;

   pvrid = bu_get_pvr_by_volname(vol_name, tape_status);

   if (pvrid) {
       for (i = 0; i < MAX_PVR_QUE; i++) {
           if (Master_Queue[i].pvrid == pvrid) {
               queue_id = i;
               break;
           }
       }
   }
   return queue_id;
}

/*====================================================================================*/
/* hpss_QueueFileX(): To place a file given by the user in queue to orderly stage the */
/*                    file as to not overwhelm the HPSS system with large number of   */
/*                    threads.                                                        */
/*                                                                                    */
/* Arguments:                                                                         */
/*     char    *Filename                                                              */
/*     int      Priority                                                              */
/*     void   (*Function)()                                                           */
/*     void    *Func_Arg                                                              */
/*                                                                                    */
/* Externals:                                                                         */
/*     int             errno (if an error occurs)                                     */
/*     int             Queue_Inited                                                   */
/*     Master_Queue_t  Master_Queue                                                   */
/*                                                                                    */
/* Return Values:                                                                     */
/*     One of the following: FILE_DISK, FILE_STAGING, FILE_IN_QUEUE, FILE_TAPE, or    */
/*     the negative value of the error code.                                          */
/*====================================================================================*/
 
int hpss_QueueFileX( char  *Filename,        /* In - Name of File to Stage */
                     int    Priority,        /* In - Priority of Stage     */
                     void (*Function)(),     /* In - Function to Call      */
                     void  *Func_Arg)        /* In - Argument to Function  */
{
  int            rc;
  signed32       storage_level;
  signed32       rel_position;
  u_signed64     pos_offset;
  unsigned32     file_type;
  unsigned32     all_perms;
  u_signed64     length;
  hpssoid_t      vvid;
  hpssoid_t      bitfile_id;
  Queue_t       *queue_ptr;
  Entry_t       *entry_ptr;
  cos_t		cosid;
  char		vol_name[12];                 /* Volume name, see ss_pvlist.h */
  int           pvr_queue;
  int           tape_status;
  char errmsg[256];
  request_t     *request_ptr;
  char 		*jobid;
  char      fsize[DEC64_LEN+1];
  char      fpos_offset[DEC64_LEN+1];
  time_t        create_time;

  request_ptr = (request_t *)Func_Arg;
  jobid = request_ptr->job_ptr->job_id;

  if (!Queue_Inited)
  {
    errno = ECHILD;    /* Must call hpss_QueueInit first */
    return(-errno);
  }
 
  /* See if the file is already on disk or not. If so, then return FILE_DISK */
  cosid = -1;

  memset(vol_name, '\0', 12);
  rc = hpss_GetStorageLevel_Etc(Filename,
                                &bitfile_id,
                                &length,
                                &vvid,
                                &rel_position,
                                &pos_offset,
                                &file_type,
                                &all_perms,
                                &storage_level,
                                &cosid,
				vol_name,
                                &create_time);
 
  if (rc > 0) {
    switch (rc) {
      case HPSS_TAPE_REPACK: sprintf(errmsg, "%s is temporary blocked for Repack.", Filename); break;
      case HPSS_TAPE_ERROR: sprintf(errmsg, "%s is temporary blocked due to I/O error.", Filename); break;
    }
    tprintf("hpss_GetStorageLevel_Etc(): File \"%s\" %s\n", Filename, errmsg);
    tprintf("Error: %s(%s:%s)\n", errmsg, request_ptr->job_ptr->job_id, Filename);
    bu_log(BATCHLOG_ERROR, 0, Filename, vol_name, pvr_queue, rc, errmsg, 0, 0, jobid, 0, 0, 0);
    return(-rc);
  }

  if (rc < 0) {
    sprintf(errmsg, "File does not exist in HPSS");
    tprintf("Error: %s(%s:%s)\n", errmsg, request_ptr->job_ptr->job_id, Filename);
    bu_log(BATCHLOG_ERROR, 0, Filename, vol_name, pvr_queue, rc, errmsg, 0, 0, jobid, 0, 0, 0);
    return(rc);
  }

  if (rc == 0 && cosid == -1) {
    sprintf(errmsg, "Bad Cartridge ID or COS.  File is no longer available in HPSS");
    tprintf("Error: %s(%s:%s)\n", errmsg, request_ptr->job_ptr->job_id, Filename);
    bu_log(BATCHLOG_ERROR, 0, Filename, vol_name, pvr_queue, -HPSS_BAD_COS, errmsg, 0, 0, jobid, 0, 0, 0);
    return(-HPSS_BAD_COS);
  }

  /* Make sure the object we wanted is really a file */
 
  if (!(file_type == NS_OBJECT_TYPE_FILE || file_type == NS_OBJECT_TYPE_HARD_LINK))
  {
    if (file_type == NS_OBJECT_TYPE_DIRECTORY) {
      sprintf(errmsg, "Requested object is a directory.");
      tprintf("Error: %d %s(%s:%s)\n", -EISDIR, errmsg, jobid, Filename);
      bu_log(BATCHLOG_ERROR, 0, Filename, NULL, 0, -EISDIR, errmsg, 0, 0, jobid, 0, 0, 0);
      return(-EISDIR);
    }

    sprintf(errmsg, "Requested object is NOT a file.");
    tprintf("Error: %d %s(%s:%s)\n", -EXDEV, errmsg, jobid, Filename);
    bu_log(BATCHLOG_ERROR, 0, Filename, NULL, 0, -EXDEV, "Requested object is NOT a file.", 0, 0, jobid, 0, 0, 0);
    return(-EXDEV);
  }

  /* Now check for permissions to stage file (Read) */

  if ((all_perms & NS_PERMS_RD) == 0) {
    sprintf(errmsg, "Permission denied.");
    tprintf("Error: %d %s(%s:%s)\n", -EACCES, errmsg, jobid, Filename);
    bu_log(BATCHLOG_ERROR, 0, Filename, NULL, 0, -EACCES, errmsg, 0, 0, jobid, 0, 0, 0);
    return(-EACCES);
  }

  /* If the storage level is 0, then the file is on disk */
  
  if (storage_level == 0) {
    bu_log(BATCHLOG_CACHED, 0, Filename, NULL, 0, 0, NULL, 0, 0, NULL, 0, 0, create_time);
    return(FILE_DISK);
  }

  if (strlen(vol_name) == 0) {
    sprintf(errmsg, "Unabled to locate the Tape ID (COS: %d)", cosid);
    tprintf("Error: %d %s (%s:%s)\n", -ENOENT, errmsg, jobid, Filename);
    bu_log(BATCHLOG_ERROR, 0, Filename, NULL, 0, -ENOENT, errmsg, 0, 0, jobid, 0, 0, 0);
    return(-ENOENT);
  }

  /* We have determined what the VVID is, now we check to see if there is a */
  /* queue by that name. If the file is not found in a queue, then we return*/
  /* FILE_TAPE. Lock the master queue first.                                */

  pvr_queue = get_pvr_queue_by_vol_name(vol_name, &tape_status);

  if (tape_status == 1) {
    sprintf(errmsg, "Tape cartridge %s is locked/broken", vol_name);
    tprintf("Error: %s(%s:%s)\n", errmsg, request_ptr->job_ptr->job_id, Filename);
    bu_log(BATCHLOG_ERROR, 0, Filename, vol_name, pvr_queue, -HPSS_TAPE_LOCKED, errmsg, 0, 0, jobid, 0, 0, 0);
    return(-HPSS_TAPE_LOCKED);
  }

  if (pvr_queue == -1) {
      char pvrname[128];
      bu_get_pvrname_by_volname(vol_name, pvrname);

      if ( strlen(pvrname) )
          sprintf(errmsg, "PVR \"%s\" is not defined for this user.  Please check the following tables: batchconfig, cartridge.", pvrname);
      else
          sprintf(errmsg, "Unable to identify the correct PVR for VOL %s.  Please check the following tables: pvrconfig, cartridge .", vol_name);

      if (Q_Log)
      {
          tprintf("File [%s]: COS:%d, Vol: %s, PVR-Queue: NOT FOUND\n", Filename, cosid, vol_name, pvr_queue);
          tprintf("Error: %s\n", errmsg);
      }
      bu_log(BATCHLOG_ERROR, 0, Filename, vol_name, 0, -EACCES, errmsg, 0, 0, jobid, 0, 0, 0);
      return(-EACCES);
  }

  if (Q_Lock) tprintf("hpss_QueueFileX: Trying to lock Master_Queue[%d]\n", pvr_queue);
  lock(&Master_Queue[pvr_queue].lock);
  if (Q_Lock) tprintf("hpss_QueueFileX: Master_Queue[%d] is locked\n", pvr_queue);
  if (Q_Log)
  {
      strcpy(fsize, u64tostr(length));
      strcpy(fpos_offset, u64tostr(pos_offset));
      tprintf("File [%s]: COS:%d, Vol: %s, MQ[%d]/PVR[%d], Size: %s, POS: %d, Offset: %s\n", Filename, cosid, vol_name, pvr_queue, Master_Queue[pvr_queue].pvrid, fsize, rel_position, fpos_offset);
  }

  if ((queue_ptr = search_for_queue(&vvid, pvr_queue)) == (Queue_t *)NULL)
  {
    /* If the queue doesnt exist, then create it. */
 
    if ((queue_ptr = create_queue(&vvid, vol_name)) == (Queue_t *)NULL)
    {
      unlock(&Master_Queue[pvr_queue].lock);
      if (Q_Lock) tprintf("hpss_QueueFileX: Master_Queue[%d] is unlocked\n", pvr_queue);
      bu_log(BATCHLOG_ERROR, 0, Filename, NULL, 0, -errno, "Internal error - create_queue() failed.", 0, 0, jobid, 0, 0, 0);
      return(-errno);
    }

    /* Insert that puppy */
 
    insert_queue(queue_ptr, pvr_queue);
  }
 
  /* The entry does not exist in the queue. Go create a new entry and insert */
  /* it into the queue.                                                      */
  
  entry_ptr = create_entry(Filename, &bitfile_id, length, rel_position, pos_offset,
                                     Priority, create_time, Function, Func_Arg);

  if (entry_ptr == (Entry_t *)NULL)
  {
    sprintf(errmsg, "Internal error - create_entry() failed.");
    tprintf("Error: %d %s(%s:%s)\n", -errno, errmsg, jobid, Filename);
    bu_log(BATCHLOG_ERROR, 0, Filename, NULL, 0, -errno, errmsg, 0, 0, jobid, 0, 0, 0);
    rc = -errno;
  }
  else
  {
    strcpy(entry_ptr->vol_num, vol_name);
    if (request_ptr->exp_minute)
        entry_ptr->exp_time = (time((time_t *)NULL)) + (request_ptr->exp_minute * 60);
    else
        entry_ptr->exp_time = 0;

    insert_entry(queue_ptr,entry_ptr);
    dump_queue(queue_ptr, Q_Dump, entry_ptr);

    if (entry_ptr->priority == PRIORITY_HIGH)
        Master_Queue[pvr_queue].pri_high++;
    if (entry_ptr->priority == PRIORITY_MEDIUM)
        Master_Queue[pvr_queue].pri_med++;

    rc = FILE_IN_QUEUE;
  }
 
  /* Return to user after unlocking our queue structure */
  unlock(&Master_Queue[pvr_queue].lock);
  if (Q_Lock) tprintf("hpss_QueueFileX: Master_Queue[%d] is unlocked\n", pvr_queue);
  return(rc);
}

int search_MQ_by_pvr(int pvr)
{
    int i, row = -1;

//    printf("search_MQ_by_pvr(pvrid: %d)\n", pvr);
    for (i = 0; i < MAX_PVR_QUE; i++) {
//       printf("search_MQ_by_pvr() Master_Queue[%d].pvrid: %d\n", i, Master_Queue[i].pvrid);
       if (Master_Queue[i].pvrid == pvr) {
//          printf("search_MQ_by_pvr() found pvrid in row %d\n", i);
          row = i;
          break;
       }
    }
//    printf("search_MQ_by_pvr() return entry: %d\n", row);
    return row;
}

/*****
   ACTION routings.  Action routing is the interface between data in 
   batch_utils and the existing variables.
 *****/
void action_copy_threads_changed(int val)
{
    int suggest_threads;
    
    if (Q_Log || R_Log)
        printf("Requesting %d COPY THREADS.\n", val);
    suggest_threads = set_reserved_copy_threads(val);

    if (suggest_threads != val) {
        printf("Requested Max COPY THREAD %d is too large, adjusted to %d\n",
            val, suggest_threads);
        bu_update_copy_threads(suggest_threads);
    }
    update_que_job_threads();
    show_thread_alloc();
}

void action_resv_que_threads_changed(int val)
{
    int suggest_threads;
    
    if (Q_Log || R_Log)
        printf("Requesting %d QUEUE JOB THREADS\n", val);
    suggest_threads = set_reserved_que_threads(val);

    if (suggest_threads != val) {
        printf("Requested Min Reserved Que Job Thread %d is too large, adjusted to %d\n",
            val, suggest_threads);
        bu_update_resv_que_threads(suggest_threads);
    }
    update_que_job_threads();
    show_thread_alloc();
}

void action_max_que_threads_changed(int val)
{
    int suggest_threads;
    
    if (Q_Log || R_Log)
        printf("Set Max %d QUEUE JOB THREADS\n", val);
    suggest_threads = set_max_que_threads(val);

    if (val > suggest_threads) {
        printf("Requested Max Que Job Thread %d is too large, adjusted to %d\n", val, suggest_threads);
        bu_update_max_que_threads(suggest_threads);
    }
    /* update_max_que_job_threads(); */
    update_que_job_threads();
    show_thread_alloc();
}

void action_queue_algorithm_changed(int val)
{
    char alg_name[64];

    switch (val) {
        case 0: strcpy(alg_name, "FIFO"); break;
        case 1: strcpy(alg_name, "High Demand first"); break;
        case 2: strcpy(alg_name, "Low Demand first"); break;
        default: strcpy(alg_name, "Unknown"); break;
    }

    if ( q_alg == val ) {
        printf("Queue Selection Logic: No change. [%d - %s]\n", q_alg, alg_name);
    }
    else {
        q_alg = val;
        printf("Updated Queue Selection Logic: %d - %s\n", q_alg, alg_name);
    }
}

void action_crs_changed(int val)
{
    char crs_str[64];

    switch (val) {
        case 1: strcpy(crs_str, "ON"); break;
        default: strcpy(crs_str, "OFF"); break;
    }

    if ( crs == val ) {
        printf("CRS batchjob table: No change. [%d - %s]\n", crs, crs_str);
    }
    else {
        crs = val;
        printf("Updated CRS batchjob table Flag: %d - %s\n", crs, crs_str);
    }
}

void action_debug_changed(unsigned long val)
{
    Q_Log = val & DEBUG_QLOG;

    R_Log = val & DEBUG_RLOG;

    debug_lock = val & DEBUG_SQLLOCK;
    bu_lock_debug = val & DEBUG_BATCHLOCK;

    Q_Dump = val & DEBUG_QDUMP;

    dbutils_set_debug(val & DEBUG_SQL);
    switch(stage_opt) {
        case 0: tprintf("Staging option: Synchronized Call\n"); break;
        case 1: tprintf("Staging option: Asynchronized Call (Call back)\n"); break;
    }
}

void action_pvr_config_changed()
{
    int i, row , pvrid, thread_size = 0;

    tprintf("Received new configuration:\n");

    for (i = 0; i < pvr_str.pvr_num; i++) {
      pvrid = pvr_str.pvrcfg_str[i].pvrid;
      row = search_MQ_by_pvr(pvrid);
      if (row == -1) { /* not found */
        row = Master_Queue_Rows;
        Master_Queue[row].pvrid = pvrid;
        strcpy(Master_Queue[row].pvr_name, pvr_str.pvrcfg_str[i].pvr_name);
        Master_Queue_Rows++;
      }

      if (Q_Lock) tprintf("action_pvr_config_changed: Trying to lock Master_Queue[%d]\n", row);
      lock(&Master_Queue[row].lock);
      if (Q_Lock) tprintf("action_pvr_config_changed: Master_Queue[%d] is locked\n", row);

      Master_Queue[row].max_num_queues = pvr_str.pvrcfg_str[i].queue;
      Master_Queue[row].queue_depth    = pvr_str.pvrcfg_str[i].depth;

      thread_size += (Master_Queue[row].max_num_queues * Master_Queue[row].queue_depth);

      if (Q_Log || R_Log)
      {
          printf("                        PVR %d (%s): Allocated Drives: %d, Srv Que Size: %d\n",
               Master_Queue[row].pvrid,
               Master_Queue[row].pvr_name,
               Master_Queue[row].max_num_queues, Master_Queue[row].queue_depth);
      }

      unlock(&Master_Queue[row].lock);
      if (Q_Lock) tprintf("action_pvr_config_changed: Master_Queue[%d] is unlocked\n", row);
    }

    if (Q_Log || R_Log)
        tprintf("Reserving %d threads for Staging...\n", thread_size);

    set_reserved_staging_threads(thread_size);
    update_que_job_threads();
    show_thread_alloc();
//    i = set_maxthreads(thread_size);
}

void init_Master_Lock()
{
  int i;

  for (i = 0; i < MAX_PVR_QUE; i++) {
    if (Q_Lock) 
        printf("Q: Initializing Master_Queue[%d].lock\n", i);

    /* Also initialize some other variables */
    Master_Queue[i].pvrid = 0;
    Master_Queue[i].pri_high = 0;
    Master_Queue[i].pri_med = 0;
    Master_Queue[i].pri_low = 0;

    init_lock(&Master_Queue[i].lock); /* init_lock defined in thread_utils.c */
  }
}

/*==========================================================================*/
/* hpss_QueueInit() : Initialize the environment for the "queueing code"    */
/*                                                                          */
/* Arguments:                                                               */
/*     int   PollTime                                                       */
/*                                                                          */
/* Externals:                                                               */
/*     int             errno (if an error occurs)                           */
/*     int             Queue_Inited                                         */
/*     int             Q_Log                                                */
/*     Master_Queue_t  Master_Queue                                         */
/*                                                                          */
/* Return Values:                                                           */
/*     0 if successful.                                                     */
/*     Otherwise, the negative of the error code is returned.               */
/*==========================================================================*/

int hpss_QueueInit( int  PollTime)     /* In - Time to Poll Stages        */
{
  pthread_t  dummy;
  char       msg[64]; 
  int        i;
 
  /* We only init once. */
  if (Queue_Inited)
  {
    errno = EFAULT;    /* Function can only be called once */
    return(-errno);
  }
 
  /* Initialize the master queue structure.  */
  /*-- Make sure it was deleted in the end --*/
  /* Master_Queue is claimed at the beginning of the .c */

  printf("Master_Queue (%d / %d)\n", Master_Queue_Rows, MAX_PVR_QUE);
  if ( Master_Queue_Rows >= MAX_PVR_QUE ) {
      printf("WARNING: *** Master_Queue IS FULL !!!!!  ***\n");
  }
  else if ( Master_Queue_Rows > (MAX_PVR_QUE * .9)) {
      printf("WARNING: Master_Queue is nearly full!\n");
  }

  for (i = 0; i < Master_Queue_Rows; i++) {
    Master_Queue[i].num_queues     = 0;
    Master_Queue[i].num_active     = 0;
    Master_Queue[i].poll_time      = PollTime;
    Master_Queue[i].head           = (Queue_t *)NULL;
    Master_Queue[i].tail           = (Queue_t *)NULL;

    if (Q_Log)
    {
/*      printf("Queue Log Starting\n"); */
      printf("Q: MQ[%d]->PVR-id: %d [%s] Allocated Drives: %d, Server Queue Size: %d files, Poll interval: %d secs\n",
               i,  Master_Queue[i].pvrid, Master_Queue[i].pvr_name, Master_Queue[i].max_num_queues, Master_Queue[i].queue_depth, PollTime);
    }
  }
  if (Q_Log) {
      printf("\n");
  }

  Queue_Inited                = TRUE;

  /* Start the monitor thread to watch and work the queue. */
 
  /* tprintf and spawn_thread defined in thread_utils.c */

  if (Q_Log)
    printf("Spawning the Queue Monitor\n");

  spawn_thread(&dummy,Mr_Queue_Monitor,(void *)0,"Mr_Queue_Monitor"); 
  return(0);
}

int action_unlock_hpss_file(char *filename)
{
    int fid = -1, locked = 0;

    if (R_Log || Q_Log)
        tprintf("Unlock HPSS file: \"%s\"\n", filename);

    fid = hpss_Open(filename, O_RDONLY, 0,
                    (hpss_cos_hints_t *) NULL,
                    (hpss_cos_priorities_t *) NULL,
                    (hpss_cos_hints_t *) NULL);

    if (fid < 0)
    {
        tprintf("unlock_file(): hpss_Open: %s, will try again later\n");
        bu_log(BATCHLOG_UNLOCK, 0, filename, NULL, 0, -fid, "unable to unlock this file.", 0, 0, NULL, 0, 0, 0);
    }
    else {
        locked = hpss_PurgeLock(fid,PURGE_UNLOCK);
        if (Q_Log) {
          tprintf("File \"%s\" Purge Unlock status: %d\n", filename, locked);
        }
        bu_log(BATCHLOG_UNLOCK, 0, filename, NULL, 0, 0, NULL, 0, 0, NULL, 0, 0, 0);

        hpss_Close(fid);
    }

    return(fid);
}

/*==============================================================================
 * stage_callback_command
 *============================================================================*/

int stage_callback_command(char *filename, u_signed64 offset, u_signed64 length, unsigned32 level, unsigned32 flags)
{
  int                 Status;
  hpss_reqid_t        req_id;
  int                 ret,sock,cli_sockfd;
  unsigned32          bytes_to_read;
  XDR                 xdrs;
  char                buf[32];
  char                *buf_ptr;
  int                 namelen,len;
  hpss_sockaddr_t     sockaddr, cli_addr;
  char                hostname[HPSS_MAX_HOST_NAME];
  bfs_callback_addr_t callback_parm;
  hpssoid_t           bfid;
  bfs_callback_ret_msg_t callback_ret;
  signed32            req_status;
  char                err_msg[HPSS_NET_MAXBUF];
  int                 optval=1;

  /*
   *  Set up a socket and do a listen
   */

  ret = gethostname(hostname,HPSS_MAX_HOST_NAME);
  if (ret < 0) {
      printf("gethostname call failed, errno = %d\n",errno);
      return BATCH_STAGE_GETHOSTNAME_FAIL;
  }

  ret = hpss_net_getaddrinfo(hostname, NULL, 0,
                             HPSS_IPPROTO_TCP,
                             &sockaddr,
                             err_msg, sizeof(err_msg));
  if (ret != 0) {
      printf("hpss_net_getaddrinfo failed, rc = %d - %s\n", ret, err_msg);
      return;
  }

  sock = hpss_net_socket(&sockaddr, SOCK_STREAM, 0, err_msg, sizeof(err_msg));
  if (sock < 0)  {
      printf("hpss_net_socket failed, errno = %d - %s\n",errno, err_msg);
      return BATCH_STAGE_SOCKET_FAIL;
  }

  /* In case if the process crash ... */
  setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *)&optval, sizeof(optval));

  ret = hpss_net_bind(sock,&sockaddr, err_msg, sizeof(err_msg));
  if(ret < 0) {
      printf("hpss_net_bind call failed, rc = %d - %s\n",ret, err_msg);
      close(sock);
      return BATCH_STAGE_BIND_FAIL;
  }

  ret = hpss_net_listen(sock,SOMAXCONN, err_msg, sizeof(err_msg));

  if(ret < 0) {
      printf("hpss_net_listen call failed, errno = %d - %s\n",errno, err_msg);
      close(sock);
      return BATCH_STAGE_GETSOCKNAME_FAIL;
  }

  ret = hpss_net_getsockname(sock,&sockaddr,err_msg, sizeof(err_msg));
  if(ret < 0) {
      printf("hpss_net_getsockname call failed, errno = %d - %s\n",ret, err_msg);
      close(sock);
      return BATCH_STAGE_GETSOCKNAME_FAIL;
  }

  /*
   *  Now that we have a bound socket and know the info, build the
   *  callback parameters to the call.  Let the client API pick
   * the request id.
   */

  memcpy(&callback_parm.sockaddr, &sockaddr, sizeof(sockaddr));
  callback_parm.id              = 0;

  Status = hpss_StageCallBack (filename, offset, length,
                               level, &callback_parm,
                               flags, &req_id, &bfid);
  /*
   *  If stage got started, then wait for HPSS to connect back to the callback
   *  address and send the results.  Note that in a real situation, you would
   *  probably want to use select so that a timer could be associated with the
   *  call to prevent any possible hangs.  Given that scrub is a test tool I have
   *  not went to this level of effort.
   */

  if (Status == 0) {
      tprintf("[%s] stage initiated, Asyn Request ID (ARID) assigned = %d\n",filename, req_id);

      /*
       *  Status the request
       */

      Status = hpss_GetAsynchStatus(req_id,
                                    &bfid,
                                    &req_status);
      if (Status == 0) {
          switch (req_status) {
              case HPSS_STAGE_STATUS_QUEUED: tprintf("ARID: %d, status = HPSS_STAGE_STATUS_QUEUED\n", req_id); break;
              case HPSS_STAGE_STATUS_ACTIVE: tprintf("ARID: %d, status = HPSS_STAGE_STATUS_ACTIVE\n", req_id); break;
          }
      }

      tprintf("ARID: %d, hpss_StageCallBack Handler is listening\n", req_id);

      cli_sockfd = hpss_net_accept(sock, &cli_addr, err_msg, sizeof(err_msg));

      if (cli_sockfd < 0) {
          printf("ARID: hpss_net_accept failed, errno = %d - %s\n", errno, err_msg);
          close(sock);  /* Added by DYU */
          return BATCH_STAGE_ACCEPT_FAIL;
      }
      else {
          bytes_to_read = INTEROP_32_SIZE;
          tprintf("ARID: %d, Received Callback from HPSS: %ld\n",req_id, bytes_to_read);

          buf_ptr = buf;
          while (bytes_to_read > 0) {
              ret = read(cli_sockfd,buf_ptr,bytes_to_read);
              if (ret < 0) {
                  tprintf("ARID: %d, socket read failed, errno = %d\n", req_id, errno);
                  break;
              }
              buf_ptr += ret;
              bytes_to_read -= ret;
          }
          if (ret >= 0)  {
              /*
               *  decode the arguments in the buffer
               */
              xdrmem_create(&xdrs,buf,sizeof(buf),XDR_DECODE);

              if (xdr_setpos(&xdrs,INTEROP_32_SIZE) == FALSE)
              {
                  printf("setpos during decode failed\n");
              }
              else
              {
                 if (xdr_bfs_callback_ret_msg_t(&xdrs,&callback_ret)
                     == FALSE)
                 {
                     printf("decoding of return parms failed\n");
                 }

                 else {
                     printf("stage completed, code = %d, request id = %d\n",
                             callback_ret.retcode,callback_ret.reqid);
                 }
              }
              xdr_destroy(&xdrs);
          }
          close(cli_sockfd);
      }
      close(sock);
  }
  else close(sock);

  return Status;
}

Queue_t *search_vol(int pvrid, char *volnum)
{
    Queue_t  *rover_q_ptr;
    int i, row ;

    /** Search for PVR **/
    row=0;
    while ( Master_Queue[row].pvrid != pvrid && row < MAX_PVR_QUE) 
        row++;

    if (row < MAX_PVR_QUE) {
        /** Search for Vol Num **/
        rover_q_ptr = Master_Queue[row].head;
        i = 0;
        while (rover_q_ptr != (Queue_t *)NULL)
        {
            if (!strcmp(rover_q_ptr->volnum, volnum)) {
                printf("    Found Vol %s in row[%d]\n", volnum, i);
                break;
            }
            i++;
            rover_q_ptr = rover_q_ptr->next;
        }

        if ( rover_q_ptr == (Queue_t *)NULL) {
                printf("    Vol %s is NOT found in PVR[%d]\n", volnum, i);
        }
    }
    else {
        printf("    PVR %d is NOT a defined PVR for this client\n", pvrid);
    }

    return rover_q_ptr;
}

int action_cancel_req_file(int pvrid, char *volnum, char *filename)
{
    int status = 0;
    int i;
    Queue_t *q_ptr;
    Entry_t  *rover_ptr;

    tprintf("Canceling request: [PVR:%d][Vol:%s][%s]\n", pvrid, volnum, filename);

    q_ptr = search_vol(pvrid, volnum);
    
    /** Search for file */
    i=0;
    if (q_ptr != (Queue_t *)NULL) {
        rover_ptr = q_ptr->head;
        while (rover_ptr != (Entry_t *)NULL) {
            if (!strcmp(rover_ptr->filename, filename)) {
                printf("    Found in entry[%d]\n", i, filename);
                break;
            }
            i++;
            rover_ptr = rover_ptr->next;
        }
        if (rover_ptr == (Entry_t *)NULL)
            tprintf("File %s not found\n", filename);
    }
    else
        tprintf("Vol %s not found\n", volnum);

    tprintf("Request cancellation completed\n");

    return status;
}


int action_cancel_req_queue(int pvrid, char *volnum)
{
    int status = 0;
    Queue_t *q_ptr;

    tprintf("Canceling request: [PVR:%d][Vol:%s][all]\n", pvrid, volnum);

    q_ptr = search_vol(pvrid, volnum);

    return status;
}
