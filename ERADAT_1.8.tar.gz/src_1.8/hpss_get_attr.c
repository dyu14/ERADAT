#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include <pwd.h>
#include <signal.h>
#include <sys/stat.h>

#include "u_signed64.h"
#include "hpss_api.h"
#include "hpss_queue.h"
#include "common.h"
#include "batch.h"
#include "thread_utils.h"
#include "batch_utils.h"
#include "dbutils.h"
#include "ns_Constants.h"
#include "hpss_get_attr.h"

char replay_file;
int stage_opt = 0;

void usage(char *progname)
{
    printf("Syntax error: INVALID ARGUMENTS\n");
    printf("    %s <username> <statx|tapeid> <fullpath filename> [-i]\n", progname);
    printf("    where:\n");
    printf("  statx: list detail info\n");
    printf("  tapeid: return volnum only\n");
    printf("  fullpath filename: Filename with fully qualified path\n");
    printf("  -i: Do not care if the file is in 'badtape list'\n");
}

void sigHand(int status)
{
   if (registed_client) {
        printf("Received signal %d, processing unregist...\n", status);
        local_dbutils_unreg();
   }
   exit(1);
}

void sigReg(int signalType, void (*func)(int)){
  struct sigaction sa;
  sa.sa_handler = func;
  sa.sa_flags = 0;
#if ! _AIX
  sa.sa_restorer = NULL;
#endif
  sigaction(signalType,  &sa, NULL);
}

int main (int argc, char *argv[])
{
  /* Must initialize the utils functions. Used to protect logging in the */
  /* threaded environment. Read in the configuration file.               */
  int rc, status;
  fstruct_t hpss_fs;

  sigReg(SIGHUP, sigHand);
  sigReg(SIGINT, sigHand);
  sigReg(SIGQUIT, sigHand);
  sigReg(SIGILL, sigHand);
  sigReg(SIGABRT, sigHand);
  sigReg(SIGKILL, sigHand);
  sigReg(SIGSEGV, sigHand);
  sigReg(SIGTERM, sigHand);
  sigReg(SIGSTOP, sigHand);

  if ( argc < 4 ) {
      usage(argv[0]);
      exit(1);
  }

  progname = (char *)strdup(argv[1]);
  strcpy(imp_user, argv[1]);

  hpss_fs.feature = 0;
  if (!strcmp(argv[2], "statx"))
      hpss_fs.feature = 1;

  hpss_fs.chkbadtape = 1;
  if (argc == 5 && !strcmp(argv[4], "-i"))
      hpss_fs.chkbadtape = 0;

  hpss_fs.filename = (char *)strdup(argv[3]);

  status = hpss_login(&hpss_fs);

  status = show_file_attr(&hpss_fs);
  free(hpss_fs.filename);

  local_dbutils_unreg();
  exit(status);
}

