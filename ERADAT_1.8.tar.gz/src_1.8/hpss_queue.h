#ifndef _HPSS_QUEUE_H_
#define _HPSS_QUEUE_H_

#include <sys/types.h>
#include <pthread.h>
#include "hpss_api.h"
#include "common.h"

/* File Status */

#define  FILE_DISK      0    /* File on disk, ready for retrieval */
#define  FILE_STAGING   1    /* File is being staged              */
#define  FILE_IN_QUEUE  2    /* File in queue to be staged        */
#define  FILE_TAPE      3    /* File on tape, no request to stage */

/* Priority definitions */

#define PRIORITY_LOW    0
#define PRIORITY_MEDIUM 1
#define PRIORITY_HIGH   2

/* Allow caller to turn logging on */
extern int Q_Log;

/* Function prototypes */
int  hpss_QueueFileX(char *, int, void (*)(void *), void *);
int  hpss_QueueInit(int);

/* Request entry structure. Used for each stage request made. */

typedef struct entry
{
  char           *filename;         /* Full name of file to stage           */
  hpssoid_t       bitfile_id;       /* Bit file id of the file              */
  u_signed64      length;           /* Length of file                       */
  signed32        position;         /* Logical position on tape             */
  u_signed64      pos_offset;       /* Logical pos + offset 64 bites        */
  double	  offset_double;    /* offset in bouble type                */
  int             priority;         /* Priority of stage request            */
  void          (*function)();      /* Pointer to function to call          */
  void           *func_arg;         /* Argument to function                 */
  time_t          time_start;       /* Time the stage request started       */
  char		 vol_num[7];        /* Volumn Number                        */
  boolean_t       active;           /* Currently being staged               */
  time_t	exp_time;           /* Expiration time                      */
  struct entry   *next;             /* Pointer to next     sequential entry */
  struct entry   *previous;         /* Pointer to previous sequential entry */
  struct queue   *queue_ptr;        /* Pointer to queue                     */
} Entry_t;

/* Tape volume queue structure. Each 'kind' of tape has its own unique name. */ 

typedef struct queue
{
  hpssoid_t      queue_name;             /* Name of queue (VVID)                */
  int            num_entries;            /* Number of entries in queue          */
  int            num_active_entries;     /* Number of active members            */
  boolean_t      active;                 /* Queue is active or not              */
  int            high_priority;          /* Number of high priority requests    */
  int            medium_priority;        /* Number of med  priority requests    */
  struct entry  *head;                   /* Pointer to first sequential request */
  struct entry  *tail;                   /* Pointer to last  sequential request */
  struct queue  *next;                   /* Poitner to next queue               */
  struct queue  *previous;               /* Pointer to previous queue           */
  struct pvr_queue *master_queue;
  char          volnum[8];
} Queue_t;

/* Master queue structure. Its the queue of the queues. */

typedef struct pvr_queue
{
  int              pvrid;            /* PVR ID                          */
  char             pvr_name[128];    /* PVR Name                        */
  int              num_queues;       /* Number of queues                */
  int              num_active;       /* Number of active queues         */
  int              max_num_queues;   /* Maximum number of active queues */
  int              queue_depth;      /* Polling time during stages      */
  int              poll_time;        /* Polling time during stages      */
  struct queue    *head;             /* Pointer to first queue          */
  struct queue    *tail;             /* Pointer to last  queue          */
  pthread_mutex_t  lock;             /* Lock for master queue           */
  int              pri_high;         /* Total number of HIGH pri reqs   */
  int              pri_med;          /* Total number of MID pri reqs   */
  int              pri_low;          /* Total number of LOW pri reqs   */
} Master_Queue_t;

#endif /* _HPSS_QUEUE_H_ */
