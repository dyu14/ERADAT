#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include <pwd.h>
/* 022703 Grace removed it since not found in Linux
#include <procinfo.h>
*/
#include <sys/types.h>

#include "common.h"
#include "nothread_utils.h"

/* Declare all functions defined in this file */

void	 usage();
void	 main(int, char **);
char	*figure_local_user();
void	 lookup_offline_user(char *, char **, char **);

/*===========================================================================*/
/* usage() : Show user what arguments to use with this program               */
/*===========================================================================*/

void usage()
{
  printf("Usage: offline_submit [-H hpss_username] [-E email-address] <file-list> <output_file>\n");
  exit(1);
}

/*============================================================================*/
/* main(): Entry point for this program. Process user inputs and initialize   */
/*         the data structures used to control jobs. Kick off some threads to */
/*         process incoming jobs and then keep statistics of activity.        */
/*                                                                            */
/* Arguments:                                                                 */
/*	int	 argc	- Number of arguments                                 */
/*      char	*argv[] - Array of arguments                                  */
/*                                                                            */
/* Externals:                                                                 */
/*      int      errno	- System error values                                 */
/*============================================================================*/

void main( int argc, char *argv[])
{
  int          c;
  int          rc;
  int          i;
  char        *local_username;
  char        *hpss_username;
  char        *email_addr;
  char        *request_file;
  char        *output_file;
  extern int   opterr;
  extern int   optind;
  extern char *optarg;

  hpss_username = email_addr = (char *)NULL;

  /* Go process the user arguments */

  while ((c = getopt (argc, argv, "H:E:h")) != EOF)
  {
    switch (c)
    {
      case 'H':
        hpss_username = optarg;
        break;
      case 'E':
        email_addr = optarg;
        break;
      case 'h':
        usage();
        break;
      default:
        printf("Unknown option \"%c\"...\n\n", c);
        usage();
    }
  }
	
  if (optind != (argc - 2)) usage();

  request_file = argv[optind];
  output_file = argv[optind+1];
/*
printf("offline_submit: main: request_file = %s\n", request_file);
printf("offline_submit: main: output_file  = %s\n", output_file);
*/

  if (strlen(request_file) == 0 || strlen(output_file) == 0)
    usage();

  /* Must initialize the utils functions.  Used to protect logging */
  /* in the threaded environment.  Read in the configuration file. */

  submit_read_config();

  /* Now ask for local user name, hpss user name, and the email address */
  /* to notify when job is complete                                     */

  local_username = figure_local_user();
  lookup_offline_user(local_username, &hpss_username, &email_addr);
 
  /* Build and submit the request to the batch processor. */

  submit_file(local_username, hpss_username, email_addr, request_file, output_file);
  printf("Successfully submitted job(%s)\n", request_file);
  return ;
}

/*=================================================================================*/
/* figure_local_user(): Determine who called us. Need to get the name of the user. */
/*                                                                                 */
/* Externals:                                                                      */
/*      int      errno	- System error values                                      */
/*                                                                                 */
/* Return Values:                                                                  */
/*	Pointer to name of user.                                                   */
/*=================================================================================*/

/* 022703 Grace commented out all the lines and added getenv at the end of the function */
/*              I couldnt find the a funtion in Linux to replace getprocs, if you found */
/*              it, feel free to change it                                              */

char * figure_local_user()
{
/*
  int			 ppid;
  struct procsinfo	 process_buf;
  struct fdsinfo	 not_used;
  struct passwd		*pwd;
*/
  char			*username;

  /* Since we are running as root, we need to figure out who is calling    */
  /* us.  Specifically, we need to find out the uid of the invoker.  This  */
  /* is what we will base the user name on.  Do what ps does, get the      */
  /* process table which is chalked full of information.                   */

/*
  ppid = getppid();

  if (getprocs(&process_buf, sizeof(process_buf), &not_used, sizeof(not_used), &ppid, 1) < 0)
  {
    fprintf(stderr, "Error in getprocs: %d\n", errno);
    exit(1);
  }
*/

  /* Now get the name of the user by looking up the uid in the password */
  /* file.                                                              */

/*
  pwd = getpwuid(process_buf.pi_uid);

  if (pwd == (struct passwd *)NULL)
  {
    fprintf(stderr, "Error from getpwuid: %d\n", errno);
    exit(1);
  }
*/

  /* Now allocate space for the user name and return to user */

/*
  username = (char *)malloc(strlen(pwd->pw_name)+1);

  if (username == (char *)NULL)
  {
    fprintf(stderr, "Malloc failed with: %d\n", errno);
    exit(1);
  }

  strcpy(username, pwd->pw_name);
*/
username = (char *)getenv("LOGNAME");
  return(username);
}

/*===========================================================================*/
/* lookup_offline_user(): Check to see if the user is in our crude database. */
/*                        Mach hpss id if invoker specified one. Load email  */
/*                        address unless invoker overrides.                  */
/*                                                                           */
/* Arguments:                                                                */
/*	char	 *local_username                                             */
/*	char	**hpss_username                                              */
/*	char	**email_addr                                                 */
/*                                                                           */
/* Externals:                                                                */
/*      int      errno	- System error values                                */
/*===========================================================================*/

void lookup_offline_user(char   *local_username,   /* In     - Name of invoker */
	                 char  **hpss_username,    /* In/Out - Hpss user       */
	                 char  **email_addr)	   /* In/Out - Notification id */
{
  int      rc;
  FILE    *fp_in;
  char     luser[USER_LEN+1];
  char     huser[USER_LEN+1];
  char     email[EMAIL_LEN+1];

  /* Open up the lookup table. */

  fp_in = fopen(Config.offline_table, "r");

  if (fp_in == (FILE *)NULL)
  {
    fprintf(stderr, "Unable to open file(%s), %d\n", Config.offline_table, errno);
    exit(1);
  }

  /* Loop until we find a match or run out of entries */

  rc = fscanf(fp_in, "%s %s %s", luser, huser, email);

  while(!feof(fp_in))
  {
    /* Hopefully the admin didn't mess up the table.  If something seems */
    /* wrong then the admin needs to be contacted                        */

    if (rc != 3)
    {
      fprintf(stderr, "Format of offline lookup table is bad, contact HPSS administrator");
      exit(1);
    }
  
    /* See if the local user name matches. */

    if (!strcmp(luser, local_username))
    {
      /* If no HPSS id is specified, then we are done.  The logic will load */
      /* in the HPSS id for us.                                             */

      if (*hpss_username == (char *)NULL) break;

      /* The invoker wants to use a certain HPSS id, we don't let them unless */
      /* there is a match in the file.                                        */

      if (!strcmp(huser, *hpss_username)) break;
    }

    rc = fscanf(fp_in, "%s %s %s", luser, huser, email);
/*
    printf("offline_submit: lookup_offline_user: luser = %s\n", luser);
    printf("                                     huser = %s\n", huser);
    printf("                                     email = %s\n", email);
*/

  }

  /* If we get here because we ran out of entries then the invoker is */
  /* not in our lookup table.  Therefore, the job will be submitted.  */
   
  if (feof(fp_in))
  {
    fprintf(stderr, "No authorization for id(%s %s)\n", local_username, *hpss_username);
    exit(1);
  }

  /* Load in the HPSS id unless the variable already has a value */

  if (*hpss_username == (char *)NULL)
  {
    *hpss_username = (char *)malloc(strlen(huser)+1);

    if (*hpss_username == (char *)NULL)
    {
      fprintf(stderr, "malloc failed: %d\n", errno);
      exit(1);
    }

    strcpy(*hpss_username, huser);
  }

  /* Ditto for the email address */

  if (*email_addr == (char *)NULL)
  {
    *email_addr = (char *)malloc(strlen(email)+1);

    if (*email_addr == (char *)NULL)
    {
      fprintf(stderr, "malloc failed: %d\n", errno);
      exit(1);
    }

    strcpy(*email_addr, email);
  }

  /* Be nice and close the input file */
  fclose(fp_in);
  return;
}
