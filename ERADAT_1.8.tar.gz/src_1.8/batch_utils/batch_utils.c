#include <stdio.h>
#include <sys/param.h>
#include <pthread.h>
#include "batch_utils.h"
#include "dbutils.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

extern char replay_file;
extern int stage_opt;
extern int crs;

/* bu_update_debug_val()
   Modify client's debug level.  The purpose is to allow user to change 
   debugging level dynamically.
*/
int bu_debug = 0;
int bu_lock_debug = 0;
extern int action_unlock_hpss_file(char *filename);

/* 
 * All previous requests should be cancelled, by marking 'X' in invalid column 
 */
void bu_cancel_old_requests()
{
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];
    char *cancel_oldjob;

    cancel_oldjob = (char *)getenv("CANCEL_JOB");

    pthread_mutex_lock(&batch_str.lock);
    if (cancel_oldjob && !strcmp(cancel_oldjob, "DELETE")) {
            sprintf(stmt,
                "DELETE FROM batchlog WHERE user = '%s' AND host='%s' AND completed_time IS NULL AND errcode=0 AND invalid is NULL", batch_str.id, batch_str.localhost);
            printf("DELETE the old requests in databases\n");
    }
    else {
        sprintf(stmt,
            "UPDATE batchlog SET invalid = 'X' WHERE user = '%s' AND host='%s' AND completed_time IS NULL AND errcode=0 AND invalid is NULL", batch_str.id, batch_str.localhost);
        printf("Marking the old requests as invalid in databases\n");
    }

    pthread_mutex_unlock(&batch_str.lock);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    DB_UNLOCK();
}

void bu_update_debug_val(unsigned long dbg_val)
{
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];

    pthread_mutex_lock(&batch_str.lock);
    sprintf(stmt,
        "UPDATE clients SET debug = %d WHERE id = '%s' AND host = '%s' AND pid = %d", dbg_val, batch_str.id, batch_str.localhost, batch_str.pid);
    pthread_mutex_unlock(&batch_str.lock);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    DB_UNLOCK();
}

/*  set_current_status()
    Set the current status of the betch.
    The value will be populated to MySQL table:"client", column:status.
*/
void set_current_status(int val)
{
    batch_str.status = val;
}

/*  bu_init()
    To initialize batch utility 
*/
int bu_init()
{
    int status, q_val;
    unsigned long debug_val;

    pthread_mutex_init(&batch_str.lock, NULL);
    pthread_mutex_init(&err_handler_lock, NULL);
    batch_str.files_queued = 0;
    batch_str.files_staging = 0;
    batch_str.files_pending = 0;
    batch_str.files_copying = 0;
    batch_str.files_delivered = 0;

    if ( (status = dbutils_connect()) == P_SUCCESS ) {
        printf("Registering...\n");
        bu_regist();

        printf("Dowloading...\n");
        bu_download_pvr_cfg();

        debug_val = bu_download_debug_cfg();
        action_debug_changed(debug_val);

        printf("Updating the Master Queues...\n");
        action_pvr_config_changed();

        q_val = bu_download_que_alg_cfg();
        if (q_val != -1) {
            printf("Updating the Queue Selection Algorithm (%d)\n", q_val);
            action_queue_algorithm_changed(q_val);
        }

        q_val = bu_download_crs_cfg();
        if (q_val != -1) {
            printf("Updating the Request by Table Flag (%d)\n", q_val);
            action_crs_changed(q_val);
        }

/*        printf("Downloading Error Handler Configuration\n"); */
        bu_download_errhandler_cfg();

/*        printf("Downloading General Configuration\n"); */
        bu_download_general_cfg();

        printf("Activate Copy Thread Change\n");
        action_copy_threads_changed(batch_str.copy_thread);

        printf("Activate Max Queue Thread Change\n");
        action_max_que_threads_changed(batch_str.max_que_thread);

        printf("Activate Reserved Queue Thread Change\n");
        action_resv_que_threads_changed(batch_str.resv_que_thread);

    }

    return status;
}

/* bu_log()
   This function will populate the status of requested file into MySQL
   database.
*/
void bu_log(int action, long start_time, char *filename, char *volnum, int pvrid, int error, char *desc, char *fsize, int locked, char *jobid, int pos, char *foffset, long create_time)
{
    char stmt[MAX_STMT_LEN], stmt_tb_jobs[MAX_STMT_LEN];
    time_t logtime = time(NULL);
    int status = -1, retry = 0;
    char *file_size;

    if (fsize)
        file_size = fsize;
    else
        file_size = strdup("0");

    stmt_tb_jobs[0]='\0';
    switch (action) {
    case BATCHLOG_REQUEST:
        sprintf(stmt,
            "INSERT INTO batchlog SET user = '%s', host='%s', filename = '%s', req_time = %ld, size = %s, pos=%d, offset=%s, errcode = %d, jobid = '%s', create_time=%ld %s",
            batch_str.id, batch_str.localhost, filename, start_time, file_size, pos, foffset, error, jobid, create_time, replay_file == 'R'?", invalid='R'":"");
        if (crs)
            sprintf(stmt_tb_jobs,
                "UPDATE batchjobs SET req_time = %ld, size = %s, pos=%d, errcode = %d WHERE filename='%s'",
                start_time, file_size, pos, error, filename);
        break;
    case BATCHLOG_QUEUED:
        sprintf(stmt,
            "UPDATE batchlog SET volnum = '%s', pvrid = %d, size = %s, pos=%d, offset=%s WHERE req_time = %ld AND user = '%s' AND host='%s' AND filename = '%s'",
            volnum, pvrid, file_size, pos, foffset, start_time, batch_str.id, batch_str.localhost, filename);
        if (crs)
            sprintf(stmt_tb_jobs,
                "UPDATE batchjobs SET volnum = '%s', size = %s, pos=%d WHERE req_time = %ld AND user = '%s' AND filename = '%s'",
                volnum, file_size, pos, start_time, batch_str.id, filename);
        break;
    case BATCHLOG_STAGING:
        sprintf(stmt,
            "UPDATE batchlog SET staging_time = %ld, volnum = '%s', pvrid = %d, size = %s  WHERE req_time = %ld AND user = '%s' AND host='%s' AND filename = '%s'",
            logtime, volnum, pvrid, file_size, start_time, batch_str.id, batch_str.localhost, filename);
        if (crs)
            sprintf(stmt_tb_jobs,
                "UPDATE batchjobs SET staging_time = %ld, volnum = '%s', size = %s, status=1 WHERE req_time = %ld AND user = '%s' AND filename = '%s'",
                logtime, volnum, file_size, start_time, batch_str.id, filename);
        break;
    case BATCHLOG_STAGED:
        sprintf(stmt,
            "UPDATE batchlog SET completed_time = %ld, size = %s, pur_lock = '%c' WHERE req_time = %ld AND user = '%s' AND host='%s' AND filename = '%s'",
            logtime, file_size, locked?'N':'Y', start_time, batch_str.id, batch_str.localhost, filename);
        if (crs)
            sprintf(stmt_tb_jobs,
                "UPDATE batchjobs SET completed_time = %ld, size = %s, status=2 WHERE req_time = %ld AND user = '%s' AND filename = '%s'",
                logtime, file_size, start_time, batch_str.id, filename);
        break;
    case BATCHLOG_PENDING:
        sprintf(stmt,
            "UPDATE batchlog SET pending = %ld WHERE user = '%s' AND host='%s' AND filename = '%s' AND jobid='%s'",
            logtime, batch_str.id, batch_str.localhost, filename, jobid);
        if (crs)
            sprintf(stmt_tb_jobs, "UPDATE batchjobs SET status=4 WHERE user='%s' AND filename='%s'", batch_str.id, filename);
        break;
    case BATCHLOG_COPYING:
        sprintf(stmt,
            "UPDATE batchlog SET copying = %ld WHERE user = '%s' AND host='%s' AND filename = '%s' AND jobid='%s'",
            logtime, batch_str.id, batch_str.localhost, filename, jobid);
        if (crs)
            sprintf(stmt_tb_jobs, "UPDATE batchjobs SET status=5 WHERE user='%s' AND filename='%s'", batch_str.id, filename);
        break;
    case BATCHLOG_COMPLETED:
        sprintf(stmt,
            "UPDATE batchlog SET copied = %ld, delivery = %d WHERE user = '%s' AND host='%s' AND filename = '%s' AND jobid='%s'",
            logtime, error, batch_str.id, batch_str.localhost, filename, jobid);
        if (crs)
            sprintf(stmt_tb_jobs, "UPDATE batchjobs SET status=7 WHERE user='%s' AND filename='%s'", batch_str.id, filename);
        break;
    case BATCHLOG_CACHED:
        sprintf(stmt,
            "INSERT INTO batchlog SET user = '%s', host='%s', filename = '%s', volnum = 'Disk', req_time = %ld, completed_time = %ld, jobid = '%s', create_time=%ld",
            batch_str.id, batch_str.localhost, filename, logtime, logtime, jobid, create_time);
        if (crs)
            sprintf(stmt_tb_jobs,
                "UPDATE batchjobs SET volnum = 'Disk', req_time = %ld, completed_time = %ld, status=2 WHERE filename='%s'",
                logtime, logtime, filename);
        break;
    case BATCHLOG_ERROR:
/*      BATCHLOG_ERROR - Error found before placing it into queue, no need to
        deduct the counters                                                   */
        sprintf(stmt,
            "INSERT INTO batchlog SET volnum = '%s', req_time = %ld, errcode = %d, errmsg = '%s', user = '%s', host='%s', filename = '%s', jobid = '%s'",
            volnum, logtime, error, desc?desc:(char *)strerror(-error), batch_str.id, batch_str.localhost, filename, jobid);
        if (crs)
            sprintf(stmt_tb_jobs,
                "UPDATE batchjobs SET volnum = '%s', req_time = %ld, errcode = %d, errmsg = '%s', status=6 WHERE filename='%s'",
                volnum, logtime, error, desc?desc:(char *)strerror(-error), filename);
        break;
    case BATCHLOG_FAILED:
        sprintf(stmt,
            "UPDATE batchlog SET completed_time = %ld, errcode = %d, errmsg = '%s' WHERE req_time = %ld AND user = '%s' AND host='%s' AND filename = '%s'",
            logtime, error, desc?desc:(char *)strerror(-error), start_time, batch_str.id, batch_str.localhost, filename);
        if (crs)
            sprintf(stmt_tb_jobs,
                "UPDATE batchjobs SET completed_time = %ld, errcode = %d, errmsg = '%s', status=6 WHERE req_time = %ld AND user = '%s' AND filename = '%s'",
                logtime, error, desc?desc:(char *)strerror(-error), start_time, batch_str.id, filename);
        break;
    case BATCHLOG_UNLOCK:
        if (error == 0)
            sprintf(stmt,
                "UPDATE batchlog SET pur_lock = 'N' WHERE user = '%s' AND host='%s' AND filename = '%s'",
                batch_str.id, batch_str.localhost, filename);
        else
            sprintf(stmt,
                "UPDATE batchlog SET errmsg = '%s' WHERE user = '%s' AND host='%s' AND filename = '%s'",
                desc, batch_str.id, batch_str.localhost, filename);
        break;
    case BATCHLOG_DROPPED:
        sprintf(stmt,
            "INSERT INTO batchlog SET user = '%s', host='%s', filename = '%s', req_time = %ld, errcode = %d, errmsg='%s'",
            batch_str.id,  batch_str.localhost, filename, start_time, error, desc);
        if (crs)
            sprintf(stmt_tb_jobs,
                "UPDATE batchjobs SET errcode = %d, errmsg = '%s', status=-1 WHERE user = '%s' AND filename = '%s'",
                error, desc?desc:(char *)strerror(-error), batch_str.id, filename);
        break;
    }
    /* printf("SQL: %s\n", stmt); */
    while ( status != 0 && retry < 5) {
        DB_LOCK();
        status = dbutils_exec_update(stmt);
        if (crs && stmt_tb_jobs[0] )
            status = dbutils_exec_update(stmt_tb_jobs);
        DB_UNLOCK();
        retry++;
        if (status != 0) {
            printf("SQL: \"%s\" update failed. status = %d, retry: %d\n", stmt, status, retry);
        }
    }
    if (!fsize)
        free(file_size);
}

/*  bu_unregist()
    This function will unregist (remove) the client from MySQL
*/
int bu_unregist()
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];
 
    sprintf(stmt,
        "DELETE FROM clients WHERE id = '%s' AND host = '%s' AND pid = %d", batch_str.id, batch_str.localhost, batch_str.pid);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    DB_UNLOCK();

    return sql_status;
}

/*  bu_reset_srv_msg()
    To reset the value in MySQL table: "clients", column: "command".
    After client (hpss_batch) received a command change, it will call this
    function to clear the command.
*/
int bu_reset_srv_msg()
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];

    pthread_mutex_lock(&batch_str.lock);
    batch_str.command = BATCH_CMD_OK;
    sprintf(stmt,
        "UPDATE clients SET command = %d WHERE id = '%s' AND host = '%s' AND pid = %d", batch_str.command, batch_str.id, batch_str.localhost, batch_str.pid);
    pthread_mutex_unlock(&batch_str.lock);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    DB_UNLOCK();
    if (!client_h)
        sql_status = P_FAIL;

    return sql_status;
}

int bu_update_copy_threads(int val)
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];
    time_t current_time;

    pthread_mutex_lock(&batch_str.lock);

    sprintf(stmt, "UPDATE clientconfig SET copy_thread = %d WHERE user='%s'", val, batch_str.id);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    DB_UNLOCK();
    if (!client_h)
        sql_status = P_FAIL;

    return sql_status;
}

int bu_update_resv_que_threads(int val)
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];
    time_t current_time;

    pthread_mutex_lock(&batch_str.lock);

    sprintf(stmt, "UPDATE clientconfig SET resv_que_thread = %d WHERE user='%s'", val, batch_str.id);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    DB_UNLOCK();
    if (!client_h)
        sql_status = P_FAIL;

    return sql_status;
}

int bu_update_max_que_threads(int val)
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];
    time_t current_time;

    pthread_mutex_lock(&batch_str.lock);

    sprintf(stmt, "UPDATE clientconfig SET max_que_threads = %d WHERE user='%s'", val, batch_str.id);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    DB_UNLOCK();
    if (!client_h)
        sql_status = P_FAIL;

    return sql_status;
}

/* bu_update_status()
   To update the current status of the client process (hpss_batch).
*/
int bu_update_status(int status)
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];
    time_t current_time;

    pthread_mutex_lock(&batch_str.lock);

    if (batch_str.status != status)
        batch_str.status = status;

    current_time = time((time_t *)NULL);

    sprintf(stmt,
        "UPDATE clients SET status = %d, f_queued = %d, f_staging = %d , lastping = %ld, f_pending = %d, f_copying = %d WHERE id = '%s' AND host = '%s' AND pid = %d", 
        batch_str.status, batch_str.files_queued, batch_str.files_staging, current_time, batch_str.files_pending, batch_str.files_copying, batch_str.id, batch_str.localhost, batch_str.pid);
    pthread_mutex_unlock(&batch_str.lock);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    DB_UNLOCK();
    if (!client_h)
        sql_status = P_FAIL;

    return sql_status;
}

/*
    bu_get_config()
    To get new configuration from database.
    upon receiving a command (greater than 0), it usually means there is a
    configuration change.
*/
int bu_get_config(int change_val)
{
    unsigned long debug_val;
    int q_val;
    switch (change_val) {
    case BATCH_CMD_GET_PVR_CONFIG:
        printf("Received event GET_PVR_CONFIG\n");
        if (bu_download_pvr_cfg() != -1)
            action_pvr_config_changed();
        bu_reset_srv_msg();
        break;
    case BATCH_CMD_GET_QUE_ALG:
        printf("Received event GET_QUE_ALG / GET_REQ_BY_TABLE_FLAG\n");
        q_val = bu_download_que_alg_cfg();
        if (q_val != -1) {
            printf("Downloaded the Queue Selection Algorithm (%d)\n", q_val);
            action_queue_algorithm_changed(q_val);
        }
        else {
            printf("No Change (%d)\n", q_val);
        }

        q_val = bu_download_crs_cfg();
        if (q_val != -1) {
            printf("\nDownloaded the Request by Table Flag (%d)\n", q_val);
            action_crs_changed(q_val);
        }
        bu_reset_srv_msg();
        break;
    case BATCH_CMD_GET_ERR_HANDLE:
        printf("Received event GET_ERR_HANDLE\n");
        bu_download_errhandler_cfg();
        bu_reset_srv_msg();
        break;
    case BATCH_CMD_GET_GEN_CONFIG:
        printf("Received event GET_GEN_CONFIG\n");
        bu_download_general_cfg();
        action_copy_threads_changed(batch_str.copy_thread);
        action_resv_que_threads_changed(batch_str.resv_que_thread);
        action_max_que_threads_changed(batch_str.max_que_thread);
    case BATCH_CMD_GET_DEBUG:
        printf("Received event GET_DEBUG\n");
        debug_val = bu_download_debug_cfg();
        action_debug_changed(debug_val);
        bu_reset_srv_msg();
        break;
    case BATCH_CMD_GET_CANCEL_REQ:
        printf("Received event CANCEL_REQ\n");
        bu_download_cancel_req();
        bu_reset_srv_msg();
        break;
    case BATCH_CMD_GET_CRS:
        printf("Received event GET_CRS\n");
        q_val = bu_download_crs_cfg();
        if (q_val != -1)
            action_crs_changed(q_val);
        bu_reset_srv_msg();
        break;
    }
    return 0;
}

/*
    bu_update_file_attr_cache()
    To update file attribute from MySQL Cahce.
*/
int bu_update_black_list(char *filename, u_signed64 size, char *volnum, signed32 pos, int code)
{
    char **row = NULL;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];
    int status = -1;
    unsigned32 file_size;
    int sql_err;

    sprintf(stmt,
        "UPDATE black_list, SET size = %ld, volnum='%s', position=%d, status=%d WHERE user='%s' AND filename = '%s'", size, volnum, pos, code, batch_str.id, filename);


    DB_LOCK();
    if((sql_err = mysql_real_query(&mysql_db, stmt, strlen(stmt))) == 0 ) {
        status = 0;
    }
    else { /* not in cache */
        sprintf(stmt,
            "INSERT INTO black_list SET user='%s', filename='%s', size = %ld, volnum='%s', position=%d, status=%d", batch_str.id, filename, size, volnum, pos, code);

        if((sql_err = mysql_real_query(&mysql_db, stmt, strlen(stmt))) == 0 )
            status = 0;
        else
            status = -1;
    }
    dbutils_free_result(client_h);
    DB_UNLOCK();
    return status;
}
/*
    bu_check_black_list()
    To search file attribute from MySQL Cahce.
*/
int bu_check_black_list(char *filename, u_signed64 *size, char *volnum, signed32 *pos)
{
    char **row = NULL;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];
    int status = -1;
    unsigned32 file_size;

    sprintf(stmt,
        "SELECT size, volnum, position, status FROM black_list WHERE filename = '%s'",
        filename);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    if (client_h) {
        if ((row = dbutils_fetch(client_h)) != NULL ) {
            if (row[0]) {
                file_size=atoll(row[0]);
                *size = cast64m(file_size);
            } else {
                *size=cast64m(0);
            }
            if (row[2]) {
                *pos = (signed32)atoi(row[2]);
            } else {
                *pos = 0;
            }
            if (row[1]) {
                strcpy(volnum, row[1]);
            } else {
                volnum[0]='\0';
            }
            if (row[3]) {
                status = atoi(row[3]);
            } else {
                status = 0;
            }
        }
    }
    dbutils_free_result(client_h);
    DB_UNLOCK();
    return status;
}

/*
    bu_download_pvr_cfg()
    To download new PVR configuration from MySQL.
*/
int bu_download_pvr_cfg()
{
    char **row = NULL;
    DBUTILS_RES *client_h;
    int i = 0, moredata = 0;
    char stmt[MAX_STMT_LEN];

    sprintf(stmt,
        "SELECT batchconfig.pvrid, pvrconfig.pvrname, batchconfig.drives, batchconfig.depth FROM batchconfig, pvrconfig WHERE batchconfig.user = '%s' AND batchconfig.pvrid = pvrconfig.pvrid ORDER by pvrconfig.pvrid",
        batch_str.id);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    if (client_h)
        moredata = 1;
    else {
        dbutils_free_result(client_h);
        DB_UNLOCK();
        return i;
    }

    printf("Downloading new PVR configuration\n");
    while (moredata) {
        row = dbutils_fetch(client_h);
        if (row == NULL) 
            moredata = 0;
        else
        {
            pvr_str.pvrcfg_str[i].pvrid = atoi(row[0]);
            strcpy(pvr_str.pvrcfg_str[i].pvr_name, row[1]);
            pvr_str.pvrcfg_str[i].queue = atoi(row[2]);
            pvr_str.pvrcfg_str[i].depth = atoi(row[3]);
            printf("    [%d] [%d|%s|%d|%d]\n", i, 
                    pvr_str.pvrcfg_str[i].pvrid,
                    pvr_str.pvrcfg_str[i].pvr_name,
                    pvr_str.pvrcfg_str[i].queue,
                    pvr_str.pvrcfg_str[i].depth);
            i++;
        }
    }
    pvr_str.pvr_num = i;
    dbutils_free_result(client_h);
    DB_UNLOCK();
    return i;
}

int bu_getRetryVal(int errcode)
{
    int found = 0, i = 0;
    int max_retry = 0;

    if (errcode == 0)
        return max_retry;

    pthread_mutex_lock(&err_handler_lock);
    max_retry = i = 0;
    while (found == 0 && (i < num_of_err_handler)) {
        if (errcode == err_handler[i].code) {
            max_retry = err_handler[i].retry;
            err_handler[i].count++;
            found = 1;
        }
        i++;
    }
    pthread_mutex_unlock(&err_handler_lock);
    return max_retry;
}

/*
    bu_download_errhandler_cfg()
    To download new Error Handler configuration from MySQL.
*/
int bu_download_errhandler_cfg()
{
    char **row = NULL;
    DBUTILS_RES *err_h;
    int i = -1, moredata = 0;
    char stmt[MAX_STMT_LEN];

    printf("Downloading Error Handler Configuration\n");

    sprintf(stmt,
      "SELECT user, errcode, retry FROM errhandler WHERE user = '%s' ORDER BY errcode", batch_str.id);

    DB_LOCK();
    err_h = dbutils_exec_query(stmt);
    if (err_h)
        moredata = 1;
    else {
        dbutils_free_result(err_h);
        DB_UNLOCK();
        return i;
    }

    row = dbutils_fetch(err_h);

    if (!row) {  /* Use default if not found   */
        printf("Profile not find, use Default Error Handler configuration\n");
        sprintf(stmt,
            "SELECT user, errcode, retry FROM errhandler WHERE user = 'default'");
        err_h = dbutils_exec_query(stmt);
        row = dbutils_fetch(err_h);
    }

    if (err_h) {
        pthread_mutex_lock(&err_handler_lock);
        printf("Downloading new Error Handler configuration\n");
        printf("  user   [Code ][Retry]\n");
        i = 0;
        while (row) {
            err_handler[i].code = atoi(row[1]);
            err_handler[i].retry = atoi(row[2]);
            printf("%-8s [%5d][%5d]\n", row[0], err_handler[i].code, err_handler[i].retry);
            i++;
            row = dbutils_fetch(err_h);
        }

        num_of_err_handler = i;
        pthread_mutex_unlock(&err_handler_lock);
    }
    else {
        printf("Unable to find Error Handler for user '%s'", batch_str.id);
    }

    dbutils_free_result(err_h);
    DB_UNLOCK();
    return i;
}

void bu_print_debug_level(unsigned long debug_val)
{
    if (debug_val & DEBUG_NONE)
        printf("Debug: OFF\n");
    if (debug_val & DEBUG_QLOG)
        printf("Debug: QLOG\n");
    if (debug_val & DEBUG_RLOG)
        printf("Debug: RLOG\n");
    if (debug_val & DEBUG_SQL)
        printf("Debug: SQL Statment\n");
    if (debug_val & DEBUG_SQLLOCK)
        printf("Debug: SQL Lock trace\n");
    if (debug_val & DEBUG_BATCHUTIL)
        printf("Debug: batch_util trace\n");
    if (debug_val & DEBUG_BATCHLOCK)
        printf("Debug: batch_util LOCK/UNLOCK trace\n");
    if (debug_val & DEBUG_QDUMP)
        printf("Debug: Dump Queue\n");
}

/*
    bu_download_que_alg_cfg()
    To download new queue algorithm info from MySQL
*/
int bu_download_que_alg_cfg()
{
    char **row = NULL;
    DBUTILS_RES *client_h;
    int q_val = -1;
    char stmt[MAX_STMT_LEN];

    sprintf(stmt, "SELECT que_alg FROM clientconfig WHERE user='%s'", batch_str.id);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    if (client_h) {
        row = dbutils_fetch(client_h);
        if ( row == NULL ) {
            sprintf(stmt, "SELECT que_alg FROM clientconfig WHERE user = 'default'");
            client_h = dbutils_exec_query(stmt);
            row = dbutils_fetch(client_h);
        }
        if (row) {
            printf("Downloading new Queue Select Algorithm Configuration\n");
            q_val = atoi(row[0]);
        }
    }

    dbutils_free_result(client_h);
    DB_UNLOCK();
    return q_val;
}

/*
    bu_download_crs_cfg()
    To download new queue algorithm info from MySQL
*/
int bu_download_crs_cfg()
{
    char **row = NULL;
    DBUTILS_RES *client_h;
    int q_val = -1;
    char stmt[MAX_STMT_LEN];

    sprintf(stmt, "SELECT crs FROM clientconfig WHERE user='%s'", batch_str.id);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    if (client_h) {
        row = dbutils_fetch(client_h);
        if ( row == NULL ) {
            sprintf(stmt, "SELECT crs FROM clientconfig WHERE user = 'default'");
            client_h = dbutils_exec_query(stmt);
            row = dbutils_fetch(client_h);
        }
        if (row) {
            printf("Downloading new Request Feed Flag \n");
            if (row[0])
                q_val = atoi(row[0]);

            if (!row[0] || q_val < 0) {
                q_val = 0;
                dbutils_free_result(client_h);
                printf("batchjobs table value is invalid, fixing it...\n");
                sprintf(stmt, "UPDATE clientconfig SET crs=0 WHERE user='%s'", batch_str.id);
                client_h = dbutils_exec_query(stmt);
            }
        }
    }

    dbutils_free_result(client_h);
    DB_UNLOCK();
    return q_val;
}

/*
    bu_download_debug_cfg()
    To download new debugging info from MySQL
*/
unsigned long bu_download_debug_cfg()
{
    char **row = NULL;
    DBUTILS_RES *client_h;
    unsigned long debug_val;
    char stmt[MAX_STMT_LEN];

    sprintf(stmt, "SELECT debug, staging FROM clientconfig WHERE user = '%s'",
        batch_str.id);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    if (client_h) {
        printf("Downloading new DEBUG and STAGING configuration\n");
        row = dbutils_fetch(client_h);
        if (row) {
            debug_val = atoll(row[0]);
            stage_opt = atoi(row[1]);
        }
        bu_print_debug_level(debug_val);
    }

    dbutils_free_result(client_h);
    DB_UNLOCK();
    return debug_val;
}

/*  bu_get_pvrname_by_volname()
    To query MySQL database, get the PVR number by volumne name.
    When processing a file retriving, we get volume name (tape name)
    from HPSS, but no PVR info.  We will then take the volname and make
    a query to MySQL table: "cartridges" and "pvrconfig", get matched 
    PVR Name.
*/
void bu_get_pvrname_by_volname(char *vol, char *pvrname)
{
    char **row = NULL;
    int pvrid = -1;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];

    sprintf(stmt,
        "SELECT PVR FROM cartridges WHERE cartridges.volnum = '%s'", vol);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);

    pvrname[0] = '\0';
    if (client_h) {
        row = dbutils_fetch(client_h);
        if (row != NULL) {
            strcpy(pvrname, row[0]);
        }
    }
    dbutils_free_result(client_h);
    DB_UNLOCK();
}

/*  bu_get_pvr_by_volname()
    To query MySQL database, get the PVR number by volumne name.
    When processing a file retriving, we get volume name (tape name)
    from HPSS, but no PVR info.  We will then take the volname and make
    a query to MySQL table: "cartridges" and "pvrconfig", get matched 
    PVR number.
*/
int bu_get_pvr_by_volname(char *vol, int *status)
{
    char **row = NULL;
    char pvrname[64];
    int pvrid = -1;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];

    sprintf(stmt,
        "SELECT pvrid, status FROM pvrconfig, cartridges WHERE cartridges.volnum = '%s' and cartridges.PVR = pvrconfig.pvrname", vol);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);

    if (client_h) {
        row = dbutils_fetch(client_h);
        if (row != NULL) {
            pvrid = atoi(row[0]);
            *status = atoi(row[1]);
        }
    }
    dbutils_free_result(client_h);

    /* If PVR not found ... then the MySQL table is wrong!  SHOW PROBLEM!! */
    if ( pvrid == -1 ) {
        printf("%s %d: Unable to identify PVR for cartridge %s\n", __FILE__, __LINE__, vol);

        sprintf(stmt, "SELECT PVR FROM cartridges WHERE volnum = '%s'", vol);
        client_h = dbutils_exec_query(stmt);
        if (client_h) {
            row = dbutils_fetch(client_h);
            if (row != NULL) {
                strcpy(pvrname, row[0]);
                printf("%s %d: According to cartridge table, VOL %s -> %s\n", __FILE__, __LINE__, vol, pvrname);
                dbutils_free_result(client_h);

                /* Now validate the PVR Name */
                sprintf(stmt, "SELECT pvrid FROM pvrconfig WHERE pvrname = '%s'", pvrname);
                client_h = dbutils_exec_query(stmt);
                if (client_h) {
                    row = dbutils_fetch(client_h);
                    if (row != NULL) 
                        printf("%s %d: According to pvrconfig table, PVR [%s] -> %s\n", __FILE__, __LINE__, pvrname, row[0]);
                    else
                        printf("%s %d: According to pvrconfig table, PVR [%s] is NOT a valid PVR\n", __FILE__, __LINE__, pvrname);
                }
                dbutils_free_result(client_h);
            }
            else {
                printf("%s %d: According to cartridge table, %s is NOT a valid VOL\n", __FILE__, __LINE__, vol);
                dbutils_free_result(client_h);
            }
        }
    }

    DB_UNLOCK();

    return pvrid;
}

/*  bu_check_srv_msg()
    hpss_batch checks the MySQL on a interval basis, see if there is any config
    change.
*/
int bu_check_srv_msg()
{
    char **row = NULL;
    int sql_status = BATCH_CMD_OK;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];

    pthread_mutex_lock(&batch_str.lock);
    sprintf(stmt,
        "SELECT command FROM clients WHERE id = '%s' AND host = '%s' AND pid = %d",
        batch_str.id, batch_str.localhost, batch_str.pid);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);

    if (client_h) {
        row = dbutils_fetch(client_h);
        if (row == NULL) {
            printf("%s %d: fatch failed\n", __FILE__, __LINE__);
            printf("SQL:%s\n", stmt);
        }
        else {
            if (row[0]) 
                batch_str.command = atoi(row[0]);
            else
                batch_str.command = 0;
            sql_status=batch_str.command;
        }
    }
    else {
        printf("%s %d: bu_check_srv_msg() failed\n", __FILE__, __LINE__);
    }
    pthread_mutex_unlock(&batch_str.lock);

    dbutils_free_result(client_h);
    DB_UNLOCK();
    return sql_status;
}

/*  bu_download_general_cfg()
    hpss_batch checks the MySQL on a interval basis, see if there is any config
    change.
*/
int bu_download_general_cfg()
{
    char **row = NULL;
    int sql_status = BATCH_CMD_OK;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];

    pthread_mutex_lock(&batch_str.lock);
    sprintf(stmt,
        "SELECT translog_life, purlock_life, copy_thread, resv_que_thread, max_que_threads FROM clientconfig WHERE user = '%s'", batch_str.id);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);

    if (client_h) {
        row = dbutils_fetch(client_h);
        if (row == NULL) {  /* No profile found, copy from default */
            sprintf(stmt,
        "SELECT translog_life, purlock_life, copy_thread, resv_que_thread, max_que_threads FROM clientconfig WHERE user = 'default'");
            dbutils_free_result(client_h);
            client_h = dbutils_exec_query(stmt);
            row = dbutils_fetch(client_h);
        }
    }

    if (row) {
        printf("Downloading New General Config Profile\n");
        if (row[0])
            batch_str.translog_life = atoi(row[0]);

        if (row[1])
            batch_str.purlock_life = atoi(row[1]);

        if (row[2])
            batch_str.copy_thread = atoi(row[2]);

        if (row[3])
            batch_str.resv_que_thread = atoi(row[3]);

        if (row[4])
            batch_str.max_que_thread = atoi(row[4]);

        printf("\ttranslog_life: [ %3d ]\n", batch_str.translog_life);
        printf("\tpurlock_life : [ %3d ]\n", batch_str.purlock_life);
        printf("\tcopy_thread  : [ %3d ]\n", batch_str.copy_thread);
        printf("\tresv_que_thr : [ %3d ]\n", batch_str.resv_que_thread);
        printf("\tmax_que_thr : [ %3d ]\n", batch_str.max_que_thread);
        sql_status = batch_str.command;
    }
    else {
        printf("%s %d: bu_download_general_cfg() failed\n", __FILE__, __LINE__);
    }
    pthread_mutex_unlock(&batch_str.lock);

    dbutils_free_result(client_h);
    DB_UNLOCK();
    return sql_status;
}

int bu_client_exist()
{
    char **row = NULL;
    int sql_status = P_FAIL;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];

    sprintf(stmt,
        "SELECT pid FROM clients WHERE id = '%s' AND host = '%s' AND pid = %d",
        batch_str.id, batch_str.localhost, batch_str.pid);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);

    if (client_h) {
        row = dbutils_fetch(client_h);
        if (row != NULL) {
            sql_status = P_SUCCESS;
        }
    }
    dbutils_free_result(client_h);
    DB_UNLOCK();

    return sql_status;
}

/*  bu_regist()
    to regist the client in MySQL.  This function is called only once when
    program is started.
*/
int bu_regist()
{
    char *id = client_str.user;
    char *host;
    int status = P_FAIL;
    int sql_err;
    char stmt[MAX_STMT_LEN];
    time_t current_time;

    host = (char *)getenv("HOSTNAME");

    if ( host ) {
        pthread_mutex_lock(&batch_str.lock);
        strcpy(batch_str.id, client_str.user);
        strcpy(batch_str.localhost, host);
        batch_str.pid = getpid();
        batch_str.status = BATCH_INIT;
        *(batch_str.msg) = '\0';
        batch_str.ques = 0;
        batch_str.rows = 0;
        batch_str.command = BATCH_CMD_OK;
        batch_str.translog_life = DEFAULT_TRANSLOG_LIFE;
        batch_str.purlock_life = DEFAULT_PURGELOCK_LIFE;
        current_time = time((time_t *)NULL);
        batch_str.last_purge = current_time;

        sprintf(stmt, "DELETE FROM clients WHERE id = '%s' AND host = '%s'", batch_str.id, batch_str.localhost);
        status = dbutils_exec_update(stmt);

        sprintf(stmt,
            "INSERT INTO clients SET id = '%s', host = '%s', pid = %d, status = %d, starttime = %ld, version = '%s', que_alg=%d, command = 0",
            batch_str.id, batch_str.localhost, batch_str.pid, batch_str.status, current_time, BATCH_VER, 0);

        if((sql_err = mysql_real_query(&mysql_db, stmt, strlen(stmt))) == 0 ) 
            status = P_SUCCESS;
        pthread_mutex_unlock(&batch_str.lock);
    }
    else {
        printf("Environment variable HOSTNAME not found, unable to regist.\n");
        exit(-1);
    }

    return status;
}

int bu_terminate()
{
    bu_unregist();
    dbutils_disconnect();
    return 0;
}

int bu_get_cmd()
{
    int status;
    pthread_mutex_lock(&batch_str.lock);
    status = batch_str.command;
    pthread_mutex_unlock(&batch_str.lock);

    return status;
}

void bu_files_queued_incr()
{
  pthread_mutex_lock(&(batch_str.files_queued_lock));
  batch_str.files_queued++;
  if (bu_lock_debug)
      printf("Q: f_queued is increased: %d\n", batch_str.files_queued);
  pthread_mutex_unlock(&(batch_str.files_queued_lock));
}

void bu_files_queued_decr()
{
  pthread_mutex_lock(&(batch_str.files_queued_lock));
  batch_str.files_queued--;
  if (bu_lock_debug)
      printf("Q: f_queued is decreased: %d\n", batch_str.files_queued);
  pthread_mutex_unlock(&(batch_str.files_queued_lock));
}

void bu_files_staging_incr()
{
  pthread_mutex_lock(&(batch_str.files_staging_lock));
  batch_str.files_staging++;
  if (bu_lock_debug)
      printf("Q: f_staging is increased: %d\n", batch_str.files_staging);
  pthread_mutex_unlock(&(batch_str.files_staging_lock));
}

void bu_files_staging_decr()
{
  pthread_mutex_lock(&(batch_str.files_staging_lock));
  batch_str.files_staging--;
  if (bu_lock_debug)
      printf("Q: f_staging is decreased: %d\n", batch_str.files_staging);
  pthread_mutex_unlock(&(batch_str.files_staging_lock));
}

void bu_files_pending_incr()
{
  batch_str.files_pending++;
}
void bu_files_pending_decr()
{
  batch_str.files_pending--;
}

void bu_files_copying_incr()
{
  batch_str.files_copying++;
}
void bu_files_copying_decr()
{
  batch_str.files_copying--;
}

void *bu_puller()
{
    int status, cmd;

    while (bu_get_cmd() != BATCH_CMD_KILL) {
        bu_update_status(batch_str.status); 
        cmd = bu_check_srv_msg();

        if (cmd != BATCH_CMD_OK) {
            status = bu_get_config(cmd);
        }

        if (bu_get_cmd() != BATCH_CMD_KILL)
            sleep(batch_str.pull_interval);
    }
    printf("Process exit command received, waiting for main process to complete current job\n");
    pthread_exit(NULL);
}

int bu_make_client(int interval)
{
    int status;
    status = bu_init();
    pthread_t pulling_thread;

    if (status == P_SUCCESS) {
        pthread_mutex_lock(&batch_str.lock);
        batch_str.pull_interval = interval;
        pthread_mutex_unlock(&batch_str.lock);
        pthread_create(&pulling_thread, NULL, bu_puller, (void *)NULL);
    }
    return status;
}

typedef struct purge_node
{
    char *filename;
    struct purge_node *next;
} purge_list;

/*
    bu_unlock_purge_locked_files()

    first get a list of files that has pur_lock indicated 'Y' and has the
    lock_life expired.

*/
int bu_unlock_purge_locked_files()
{
    char **row = NULL;
    DBUTILS_RES *client_h;
    int i = 0, rows = 0, moredata = 0;
    char stmt[MAX_STMT_LEN];
    time_t req_time, curtime = time(NULL);
    char prv_filename[MAXPATHLEN+1];
    purge_list *head, *cur_node, *tmp_node;
    int pur_lock_expired;

    pur_lock_expired = curtime - (ONE_HOUR * batch_str.purlock_life);

    head = (purge_list *)malloc(sizeof(purge_list));
    head->filename = NULL;
    head->next = NULL;
    cur_node = head;

    *(prv_filename) = '\0';

    if (bu_lock_debug)
        printf("Enter bu_unlock_purge_locked_files()\n");

    /* Unlock the large files first */
    sprintf(stmt,
/*        "SELECT filename, req_time FROM batchlog WHERE batchlog.user = '%s' AND AND host='%s' AND pur_lock = 'Y' AND (completed_time > 0 AND completed_time < %ld) ORDER BY filename",
*/
        "SELECT filename, req_time FROM batchlog WHERE batchlog.user = '%s' AND batchlog.host='%s' AND pur_lock = 'Y' AND (completed_time > 0 AND completed_time < %ld) ORDER BY size DESC",
        batch_str.id, batch_str.localhost, pur_lock_expired);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    if (client_h) {
        moredata = 1;
        if (bu_lock_debug)
            printf("Downloading Purge lock list.\n");
    }

    while (moredata) {
        row = dbutils_fetch(client_h);
        if (row == NULL) 
            moredata = 0;
        else
        {
            if (strcmp(prv_filename, row[0])) { /* Not a duplicate */
                cur_node->next = (purge_list *)malloc(sizeof(purge_list));
                cur_node = cur_node->next;

                cur_node->filename = (char *)strdup(row[0]);
                cur_node->next = NULL;
                if (bu_lock_debug)
                    printf("Adding file \"%s\" to unlock list\n", cur_node->filename);
                strcpy(prv_filename, row[0]); 
                rows++;
            }
        }
    }
    dbutils_free_result(client_h);
    DB_UNLOCK();

    /* Now process the list */
    cur_node = head;
    while (head->next != (purge_list *)NULL) {
        cur_node = head->next;

        if (bu_lock_debug)
            printf("Processing action_unlock_hpss_file(\"%s\")\n", cur_node->filename);
        action_unlock_hpss_file(cur_node->filename);

        free(cur_node->filename);
        head->next = cur_node->next;
        free(cur_node);
    }
    free(head);

    return i;
}

void bu_purge_trans_log()
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];
    long translog_expiration_time;
    time_t curtime = time(NULL);

/*
    Since this function is called by update_progress() thread, the default
    for this function to be called is Update_Interval.tv_sec. 
    However, in case of logic change, the minimun interval is set to 1 minute
    for this function to be called.
*/
    if ((curtime - batch_str.last_purge) < ONE_MINUTE ) {
        return;
    }

    batch_str.last_purge = curtime;
    translog_expiration_time = curtime - (ONE_HOUR * batch_str.translog_life);
 
    sprintf(stmt,
        "DELETE FROM batchlog WHERE user = '%s' AND host='%s' AND req_time < %d AND (pur_lock = 'N' OR (pur_lock is NULL AND errcode > 0))", batch_str.id, batch_str.localhost, translog_expiration_time);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    DB_UNLOCK();
}

int bu_check_lsm_status(char *vol)
{
    char **row = NULL;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];
    int lsm_stat = 0;

    pthread_mutex_lock(&batch_str.lock);
    sprintf(stmt,
        "SELECT volnum, status, lsm FROM cartridges WHERE volnum = '%s' and lsm in (select lsm from lsm_status where status = 1)", vol);

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);

    if (client_h) {
        row = dbutils_fetch(client_h);
        if (row != NULL) {
            printf("%s %d: LSM %s is offline\n", __FILE__, __LINE__, row[2]);
            lsm_stat = 1;
        }
    }
    else {
        printf("%s %d: bu_check_lsm_status() failed\n", __FILE__, __LINE__);
        lsm_stat = -1;
    }
    pthread_mutex_unlock(&batch_str.lock);

    dbutils_free_result(client_h);
    DB_UNLOCK();
    return lsm_stat;
}

/*
    bu_download_cancel_req()
    To search file attribute from MySQL Cahce.
*/
int bu_download_cancel_req()
{
    char **row = NULL;
    DBUTILS_RES *client_h;
    char stmt[MAX_STMT_LEN];
    char action;
    unsigned32 file_size;
    char volnum[8], jobid[512], filename[1024];
    int status, pvrid;

    sprintf(stmt, "SELECT pvrid, jobid, volnum, filename, action FROM cancel_req");

    DB_LOCK();
    client_h = dbutils_exec_query(stmt);
    if (client_h) {
        while ((row = dbutils_fetch(client_h)) != NULL ) {
            pvrid = atoi(row[0]);
            strcpy(jobid, row[1]);  /* Not really supported */
            strcpy(volnum, row[2]);
            strcpy(filename, row[3]);
            action = *row[4];

            switch (action) {
                case 'Q': /** Cancel queue */
                        action_cancel_req_queue(pvrid, volnum);
                        break;
                case 'F': /** Cancel file */
                        action_cancel_req_file(pvrid, volnum, filename);
                        break;
            }
        }
    }
    dbutils_free_result(client_h);
    DB_UNLOCK();
    return status;
}
