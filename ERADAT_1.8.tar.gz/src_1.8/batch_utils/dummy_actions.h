char replay_file = ' ';
int stage_opt;
int action_unlock_hpss_file(char *filename) {}
void action_debug_changed(unsigned long val) {}
void action_pvr_config_changed() {}
void action_general_config_changed() {}
void action_queue_algorithm_changed(int qval) {}
void action_copy_threads_changed(int val) {}
void action_resv_que_threads_changed(int val) {}
