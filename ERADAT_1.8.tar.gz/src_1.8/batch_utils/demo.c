#include <stdio.h>
#include "pthread.h"
#include "batch_utils.h"

int num_queues = 2;
int num_requests = 5;
char replay_file = ' ';
int stage_opt;

void action_copy_threads_changed(int val)
{
}

int action_unlock_hpss_file(char *filename)
{
}

void action_debug_changed(unsigned long val)
{
}

void action_queue_algorithm_changed(int val)
{
}

void action_resv_que_threads_changed(int val)
{
}

void action_pvr_config_changed()
{
    num_queues = batch_str.ques;
    num_requests = batch_str.rows;
    printf("Dimansion is changed: %d x %d\n", num_queues, num_requests);
}

main()
{
    int status;

    printf("demo\n");

    dbutils_set_debug(1); 
    status = bu_make_client(DEFAULT_UPDATE_INTERVAL);
    sleep(1);

    switch (status) {
    case P_SUCCESS: fprintf(stdout, "pftplog initialized\n"); break;
    case P_FAIL: fprintf(stdout, "pftplog initializ fail\n"); break;
    case P_FEATURE_DISABLED: fprintf(stdout, "pftplog is disabled\n"); break;
    }
    if (status == P_FAIL)
        return (1);

    fprintf(stdout, "processing hard\n");
    while (batch_str.command != BATCH_CMD_KILL) {
        sleep(5);
    }
    bu_terminate();
    fprintf(stdout, "Terminated\n");
}

