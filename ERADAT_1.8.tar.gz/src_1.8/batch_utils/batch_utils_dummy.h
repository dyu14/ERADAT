#ifndef BATCH_UTIL_DUMMY_H
#define BATCH_UTIL_DUMMY_H
extern char replay_file;
#endif
