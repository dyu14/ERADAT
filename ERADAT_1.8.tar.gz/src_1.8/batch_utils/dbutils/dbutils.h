#ifndef _DBUTILS_H
#define _DBUTILS_H

#include "mysql.h" /* Headers for MySQL usage */
#include "errmsg.h" /* MySQL ErrCode */
#include <time.h>

#define DB_LOCK()	dbutils_lock(__FILE__, __LINE__);
#define DB_UNLOCK()	dbutils_unlock(__FILE__, __LINE__);

#define P_SUCCESS 0
#define P_FAIL    1
#define P_FEATURE_DISABLED    2

#define DBUTILS_RES MYSQL_RES
#define DBUTILS_ROW MYSQL_ROW

#define DBUTILS_XFERLOG "xferlog"

#define MAX_STMT_LEN 1024
#define MAX_HOST_LEN 256

/* static MYSQL mysql_db; */
MYSQL mysql_db;

typedef struct st_xferlog_fields {
  time_t timestamp;
  double duration;
  char   client[MAX_HOST_LEN]; /* We need to strip off all strings after dot */
  short  func_id;
  char   *username;
  unsigned long   size;
} XFERLOG_FIELDS;

typedef struct st_dbutils_fields {
  char host[64];
  char user[64];
  char pw[64];
  char db[64];
  char stmt[MAX_STMT_LEN];
  XFERLOG_FIELDS xferlog;
  time_t last_attempt;
  int  reconnect_int;
  int  log_enabled;
} DBCLIENT_FIELDS;

DBCLIENT_FIELDS client_str;

extern int debug_lock;
int dbutils_enable();
int dbutils_disable();
int dbutils_status();

char *dbutils_getlasterror();
int pftpmsg_termininate();
int dbutils_set_mem_debug(int ) ;
int dbutils_set_debug(int ) ;
int dbutils_connect();
int dbutils_disconnect();
int dbutils_get_func_id(char *);
int dbutils_insert_xferlog();
DBUTILS_RES *dbutils_exec_query(char *);
int dbutils_exec_update(char *);
void dbutils_close(DBUTILS_RES *);
void dbutils_free_result(DBUTILS_RES *);
void dbutils_lock(char *, int);
void dbutils_unlock(char *, int);
DBUTILS_ROW dbutils_fetch(DBUTILS_RES *);

#endif
