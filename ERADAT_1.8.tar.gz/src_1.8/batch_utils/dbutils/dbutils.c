/*
  dbutils.c

                               Modification Log
  ---------------------------------------------------------------------------
  Date       Name  Description
  ---------- ----- ----------------------------------------------------------
  02/01/2006 dyu   Initial program.
  ---------------------------------------------------------------------------

  INTRODUCTION
  ------------
  dbutils is the lower level API that provides the connectivity to MySQL.  All
  MySQL API is called from this level.

  NOTE
  ----
  The initial version is to support MySQL 5.0 and above.

*/

#include <dbutils.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "mysqld_error.h"
#include "errmsg.h"

/** Global variables. **/
int debug = 0;
int debug_lock = 0;

static pthread_mutex_t dblock;

#define DBUTILS_CFG_PATH_DEFAULT "/opt/hpss/bin/pftplog.cfg"
#define MAX_CFG_LINE_LEN 128

/** Functions **/
int dbutils_set_debug(int value) 
{
    debug = value;
}

int dbutils_enable() 
{
    int status = -1;
    if (client_str.log_enabled != -1 ) /* -1 = invalid cfg, cannot be enabled */
        status = client_str.log_enabled = 1;

    return status;
}

int dbutils_disable() 
{
    int status = -1;
    if (client_str.log_enabled != -1 ) /* -1 = invalid cfg, cannot be disabled */
        status = client_str.log_enabled = 0;

    return status;
}

int dbutils_status() 
{
    return (client_str.log_enabled);
}

/* 
    dbutils_get_cfg() - Get MySQL parameters from configuration file.

    The default configuration file is located under /opt/hpss/bin/pftplog.cfg.
    This path can be overided by environment DBUTILS_CFG_PATH.
*/
void dbutils_get_cfg()
{
    char dbutils_cfg_path_default[] = DBUTILS_CFG_PATH_DEFAULT;
    char *dbutils_cfg_path = NULL;
    FILE *cfg_path;
    char buf[MAX_CFG_LINE_LEN+1];
    char *ch, *host, *user, *pw, *db, *reconnect_interval, *dblog;

    /* Determine the path of the config file, use default if not specified */
    dbutils_cfg_path = (char *)getenv("DBUTILS_CFG_PATH");;
    if (!dbutils_cfg_path) {
        /* Try DB_CFG_PATH if DBUTILS_CFG_PATH is not defined */
        dbutils_cfg_path = (char *)getenv("DB_CFG_PATH");;
        if (!dbutils_cfg_path) 
            dbutils_cfg_path = dbutils_cfg_path_default;
    }

    /* Parsing Configuration file */
    if ((cfg_path = fopen(dbutils_cfg_path, "r")) != NULL) {
        while (fgets(buf, MAX_CFG_LINE_LEN, cfg_path) != NULL) {
            if (ch = (char *)strchr(buf, '#')) *ch = '\0';
            if (ch = (char *)strchr(buf, '\n')) *ch = '\0';

            if (!memcmp(buf, "DB_HOST", 7)) {
                host = (char *)strchr (buf,'|'); 
                if (host) strcpy(client_str.host, host+1);
            }
            else if (!memcmp(buf, "DB_USER", 7)) {
                user = (char *)strchr (buf,'|'); 
                if (user) strcpy(client_str.user, user+1);
            }
            else if (!memcmp(buf, "DB_PASSWD", 9)) {
                pw = (char *)strchr (buf,'|'); 
                if (pw) strcpy(client_str.pw, pw+1);
            }
            else if (!memcmp(buf, "DB_DATABASE", 11)) {
                db = (char *)strchr (buf,'|'); 
                if (db) strcpy(client_str.db, db+1);
            }
            else if (!memcmp(buf, "DB_RECONNECT_INTERVAL", 21)) {
                reconnect_interval = (char *)strchr (buf,'|'); 
                if (reconnect_interval) client_str.reconnect_int = atoi(reconnect_interval+1);
            }
            else if (!memcmp(buf, "DB_LOG", 6)) {
                dblog = (char *)strchr (buf,'|'); 
                if (dblog) client_str.log_enabled = atoi(dblog+1);
            }
        }
        fclose(cfg_path);
    }
    else {
        /* If unable to open config file, then disable the pftp log feature */
        client_str.log_enabled = -1;
    }
}

/* 
   validate_cfg() - Validating the configuration structure.  If any of the 
   required parameter is not set, then the pftplog feature will be disabled. 
*/
void validate_cfg()
{
    if (client_str.log_enabled == 1) { 
        if (!strlen(client_str.host)) client_str.log_enabled = -1;
        if (!strlen(client_str.user)) client_str.log_enabled = -1;
        if (!strlen(client_str.pw)) client_str.log_enabled = -1;
        if (!strlen(client_str.db)) client_str.log_enabled = -1;
        if (!client_str.reconnect_int) client_str.log_enabled = -1;
    }
}

/*
    dbutils_init() - Initialize the dbutils logic.

    1. initialize all variables.
    2. read parameters from cfg file.
    3. get environment variables; if found, overide the parameters in cfg file.
    4. make sure all required data in structure are defined.
*/
void dbutils_init()
{
    char *host, *user, *pw, *db, *reconnect_interval;

    *client_str.host = '\0';
    *client_str.user = '\0';
    *client_str.pw = '\0';
    *client_str.db = '\0';
    reconnect_interval = 0;

    dbutils_get_cfg(); /* get configuration parameter from cfg file */

    /* The environment variable can overide the parameters defined in
       configuration file */
    host = (char *)getenv("DB_HOST");
    user = (char *)getenv("DB_USER");
    pw = (char *)getenv("DB_PASSWD");
    db = (char *)getenv("DB_DATABASE");
    reconnect_interval = (char *)getenv("DB_RECONNECT_INTERVAL");

    if (host) strcpy(client_str.host, host);
    if (user) strcpy(client_str.user, user);
    if (pw) strcpy(client_str.pw, pw);
    if (db) strcpy(client_str.db, db);
    if (reconnect_interval) client_str.reconnect_int = atoi(reconnect_interval);

    /* Now, briefly validate the parameters... */
    validate_cfg();

    if (debug) {
        int i;
        fprintf(stdout, "MySQL Info (Client lib version: %s)\n", MYSQL_SERVER_VERSION);
        fprintf(stdout, "    Server  : [%s]\n", client_str.host);
        fprintf(stdout, "    User    : [%s]\n", client_str.user);

        /* Password will be replaced by "*" */
        fprintf(stdout, "    Passwd  : [");
        for (i = 0; i < strlen(client_str.pw); i++) fprintf(stdout, "*");
        fprintf(stdout, "]\n");

        fprintf(stdout, "    Database: [%s]\n", client_str.db);
        switch (client_str.log_enabled) {
            case -1: fprintf(stdout, "    pftplog : [Invalid CFG]\n"); break;
            case  0: fprintf(stdout, "    pftplog : [Disabled]\n"); break;
            case  1: fprintf(stdout, "    pftplog : [Enabled]\n"); break;
        }
        fprintf(stdout, "\n");
    }
}

/*
    dbutils_real_connect() - Make SQL connection and evaluate the connection
                            status.  If permenent error occures, disable the
                            feature.  
*/
int dbutils_real_connect() 
{
    int status = P_SUCCESS;
    my_bool reconnect = 1;

    client_str.last_attempt = time(NULL);

    if (client_str.log_enabled != 1) {
        status = P_FEATURE_DISABLED;
    }
    else {
        mysql_options(&mysql_db, MYSQL_OPT_RECONNECT, &reconnect);
        if(!mysql_real_connect(&mysql_db, client_str.host, client_str.user, 
                               client_str.pw, client_str.db, 0, NULL, 0)) { 
            mysql_options(&mysql_db, MYSQL_OPT_RECONNECT, &reconnect);
            int err_no;
            err_no = mysql_errno(&mysql_db);
            status = P_FAIL;

            /* The following errors are permanent error; disable the feature
               completely, so it will not be wasting time in reconnect */
            if (err_no == ER_ACCESS_DENIED_ERROR ||
                err_no == CR_UNKNOWN_HOST ||
                err_no == ER_BAD_DB_ERROR) {
                 client_str.log_enabled = -1;
            }
        }
    }
    return status;
}

int dbutils_connect() 
{
  dbutils_init();

  pthread_mutex_init(&dblock, NULL);
  mysql_init(&mysql_db);

  return (dbutils_real_connect());
}

int dbutils_reconnect()
{
    int status = P_SUCCESS;
    time_t now = time(NULL);

    /* Connection is usually expansive, reject the connection request if
       last connection attemp is less than the reconnect interval */

    if ( (now - client_str.last_attempt) > client_str.reconnect_int) {
        status = dbutils_real_connect();

        if (debug) {
            if (status == P_SUCCESS) 
                printf("%s %d Connection resumed\n", __FILE__, __LINE__);
            else
                printf("%s %d Connection unsuccess, will retry again later.\n",
                         __FILE__, __LINE__);
        }
    }
    return status;
}

/* 
  dbutils_insert_xferlog() - This is the function that INSERTs the message into 
                            table xferlog.

  Table Definition:
+------------+--------------+------+-----+---------+-------+
| Field      | Type         | Null | Key | Default | Extra |
+------------+--------------+------+-----+---------+-------+
| time_stamp | mediumtext   | NO   |     |         |       |
| duration   | double       | YES  |     | NULL    |       |
| client     | varchar(255) | YES  |     | NULL    |       |
| func_id    | tinyint(4)   | YES  |     | NULL    |       |
| username   | varchar(32)  | YES  |     | NULL    |       |
| size       | bigint(20)   | YES  |     | NULL    |       |
+------------+--------------+------+-----+---------+-------+
*/
int dbutils_insert_xferlog()
{
    int status = P_SUCCESS;
    int sql_err;
    char stmt[MAX_STMT_LEN];

    if (client_str.log_enabled != 1) 
        return P_FEATURE_DISABLED;

    sprintf(stmt, 
            "INSERT INTO xferlog VALUES (%ld, %f, '%s', %d, '%s', %u)",
                client_str.xferlog.timestamp,
                client_str.xferlog.duration,
                client_str.xferlog.client,
                client_str.xferlog.func_id,
                client_str.xferlog.username,
                client_str.xferlog.size
           );

    if (debug) printf("%s %d QUERY: %s\n", __FILE__, __LINE__, stmt);

    if((sql_err = mysql_real_query(&mysql_db, stmt, strlen(stmt))) != 0 ) { 

        if (debug) printf("%s %d INSERT FAILED: %s\n", __FILE__, __LINE__, mysql_error(&mysql_db));

        if (sql_err == CR_SERVER_LOST || sql_err == CR_SERVER_GONE_ERROR ) 
            dbutils_reconnect();  /* Request to Reconnect */

        status = P_FAIL;
    }

    return(status);
}

int dbutils_disconnect() 
{
    if (client_str.log_enabled != 1) 
        return P_FEATURE_DISABLED;

    if (debug) 
        printf("%s %d Discounnecting\n", __FILE__, __LINE__);

    mysql_close(&mysql_db);

    return 0;
}

char *dbutils_getlasterror()
{
    return (char *) mysql_error(&mysql_db);
}

int dbutils_exec_update(char *query)
{
    int res = 0;

    if (client_str.log_enabled != 1) 
        return 0;

    if (debug) {
        printf("%s %d Calling mysql_real_query()\n", __FILE__, __LINE__);
        printf("%s %d QUERY: %s\n", __FILE__, __LINE__, query);
    }

    res = mysql_real_query(&mysql_db, query, strlen(query));

    return res;
}

DBUTILS_RES *dbutils_exec_query(char *query)
{
    DBUTILS_RES *res = NULL;
    int retry = 1, status;

    if (client_str.log_enabled != 1) 
        return NULL;

    if (debug) {
        printf("%s %d Calling mysql_real_query()\n", __FILE__, __LINE__);
        printf("%s %d QUERY: %s\n", __FILE__, __LINE__, query);
    }

    while (retry > 0 && retry < 5) {
        status = mysql_real_query(&mysql_db, query, strlen(query));
        if (status) {
            printf("SQL Error: %d %s\n", status, mysql_error(&mysql_db));
            dbutils_real_connect();
            retry++;
        }
        else {
            res = mysql_store_result(&mysql_db);
            retry = 0;
        }
    }

    return res;
}

void dbutils_free_result(DBUTILS_RES *res)
{
    if (debug)
        printf("%s %d Calling mysql_free_result()\n", __FILE__, __LINE__);

    mysql_free_result(res);
}

void dbutils_close(DBUTILS_RES *res)
{
    if (client_str.log_enabled != 1) 
        return;

    dbutils_free_result(res);

    if (debug)
        printf("%s %d Calling mysql_close()\n", __FILE__, __LINE__);

    mysql_close(&mysql_db);
}

void dbutils_lock(char *filename, int lineno)
{
    if (debug_lock)
        printf("L: %s %d: attemp to lock dblock\n", filename, lineno);

    pthread_mutex_lock(&dblock);

    if (debug_lock)
        printf("L: %s %d: dblock lock success\n", filename, lineno);
}

void dbutils_unlock(char *filename, int lineno)
{
    if (debug_lock)
        printf("L: %s %d: attemp to unlock dblock\n", filename, lineno);

    pthread_mutex_unlock(&dblock);

    if (debug_lock)
        printf("L: %s %d: dblock unlock success\n", filename, lineno);
}

DBUTILS_ROW dbutils_fetch(DBUTILS_RES *res)
{
    DBUTILS_ROW row;

    if (client_str.log_enabled != 1) 
        return NULL;

    if (debug)
        printf("%s %d Calling mysql_fetch_row()\n", __FILE__, __LINE__);

    row = mysql_fetch_row(res);

    return row; 
}
