/* cuapi.h - Client Utility API
 */
#ifndef __CLIENTUTIL_H__
#define __CLIENTUTIL_H__

#include "dbutils.h"
#include "u_signed64.h"

#define BATCH_VER "1.8"

#define MAX_USER_LEN 64
#define MAX_MSG_LEN 255
#define DEC64_LEN 20

#define DEFAULT_UPDATE_INTERVAL 3
#define DEFAULT_MAX_NUM_QUEUES  2
#define DEFAULT_QUEUE_DEPTH     5

#define BATCH_INIT     0
#define BATCH_IDEL     1
#define BATCH_BUSY     2

#define BATCH_CMD_OK             0
#define BATCH_CMD_GET_PVR_CONFIG 1
#define BATCH_CMD_GET_DEBUG      2
#define BATCH_CMD_GET_QUE_ALG    3
#define BATCH_CMD_GET_ERR_HANDLE 4
#define BATCH_CMD_GET_GEN_CONFIG 5
#define BATCH_CMD_GET_CANCEL_REQ 6
#define BATCH_CMD_GET_CRS        7
#define BATCH_CMD_KILL        -1
#define BATCH_CMD_SHUTDOWN    -2

#define BATCHLOG_REQUEST 100
#define BATCHLOG_QUEUED  101
#define BATCHLOG_STAGING 102
#define BATCHLOG_STAGED  103
#define BATCHLOG_CACHED  104
#define BATCHLOG_FAILED  105
#define BATCHLOG_ERROR   106
#define BATCHLOG_UNLOCK  107
#define BATCHLOG_PENDING 108
#define BATCHLOG_COPYING 109
#define BATCHLOG_COMPLETED 110
#define BATCHLOG_DROPPED 111

#define DEBUG_NONE 	0x00
#define DEBUG_QLOG 	0x01
#define DEBUG_RLOG 	0x02
#define DEBUG_SQL  	0x04
#define DEBUG_SQLLOCK   0x08
#define DEBUG_BATCHUTIL 0x10 /* 16 */
#define DEBUG_BATCHLOCK 0x20 /* 32 */
#define DEBUG_QLOCK     0x40 /* 64 */
#define DEBUG_QDUMP     0x80 /* 128 */

#define MAX_PVR_NUM           32
#define ONE_MINUTE            60
#define ONE_HOUR              60*ONE_MINUTE
#define DEFAULT_TRANSLOG_LIFE 168  /* 7 days */
#define DEFAULT_PURGELOCK_LIFE 0  /*  0 hours */

typedef struct st_log {
    long start_time; 
    char *filename; 
    char *volnum; 
    int pvrid; 
    int error; 
    char *desc; 
    char *fsize; 
    int locked; 
    char *jobid; 
    int pos; 
    char *foffset;
    long create_time;
} BU_LOG;

typedef struct st_pvr_cfg {
  char pvr_name[20];
  int  pvrid;
  int  queue;
  int  depth;
} PVRCFG_FIELDS;

typedef struct st_pvr {
  int pvr_num;
  PVRCFG_FIELDS pvrcfg_str[MAX_PVR_NUM];
} PVR_FIELDS;

PVR_FIELDS pvr_str;

typedef struct err_handler
{
  int           code;            /* Error code                          */
  int           retry;
  int		count;
} err_handler_t;

#define MAX_ERR_HANDLER 10
err_handler_t err_handler[MAX_ERR_HANDLER];
int num_of_err_handler;
pthread_mutex_t err_handler_lock;

extern int bu_lock_debug;

typedef struct st_batch_client {
  pthread_mutex_t lock;
  char id[MAX_USER_LEN];
  char localhost[MAX_HOST_LEN];
  int pid;
  int status;
  char msg[MAX_MSG_LEN];
  time_t last_attempt;
  int ques;
  int rows;
  int command;
  int pollpime;
  int pull_interval;

  int files_queued;
  pthread_mutex_t files_queued_lock;
  int files_staging;
  pthread_mutex_t files_staging_lock;
  int translog_life;
  int purlock_life;
  int copy_thread;
  int resv_que_thread;
  int max_que_thread;
  int files_pending;
  int files_copying;
  int files_delivered;
  time_t last_purge;
} BATCHCLIENT_FIELDS;

BATCHCLIENT_FIELDS batch_str;

void *bu_puller();

int bu_init();
int bu_regist();
int bu_unregist();
int bu_update_status(int status);
int bu_client_exist();
int bu_terminate();
int bu_get_config();
int bu_update_config(int queues, int rows);
void action_pvr_config_changed();
void action_general_config_changed();
void action_debug_changed(unsigned long);
void action_queue_algorithm_changed(int);
void action_crs_changed(int);
void action_copy_threads_changed(int);
void action_resv_que_threads_changed(int);
void action_max_que_threads_changed(int);
int bu_update_resv_que_threads(int);
int bu_update_max_que_threads(int);
int bu_update_copy_threads(int);
int bu_download_pvr_cfg();
int bu_get_pvr_by_volname(char *vol, int *status);
void bu_get_pvrname_by_volname(char *vol, char *pvrname);
/* void bu_log(int action, long start_time, char *filename, char *volnum, int pvrid, int error, char *desc, unsigned long size, int locked, char *jobid); */
void bu_log(int action, long start_time, char *filename, char *volnum, int pvrid, int error, char *desc, char *fsize, int locked, char *jobid, int pos, char *foffset, long create_time);

int bu_get_cmd();
void bu_files_queued_incr();
void bu_files_queued_decr();
void bu_files_staging_incr();
void bu_files_staging_decr();
void bu_update_debug_val(unsigned long);
void bu_purge_trans_log();
void bu_cancel_old_requests();
void bu_mark_replay_requests();
int bu_unlock_purge_locked_files();
unsigned long bu_download_debug_cfg();
int bu_getRetryVal(int);
int bu_check_lsm_status(char *);
int bu_check_black_list(char *, u_signed64 *, char *, signed32 *);

#endif
