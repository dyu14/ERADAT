#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include <pwd.h>
#include <signal.h>
#include <sys/stat.h>

#include "u_signed64.h"
#include "hpss_api.h"
#include "hpss_queue.h"
#include "common.h"
#include "batch.h"
#include "thread_utils.h"
#include "batch_utils.h"
#include "batch_utils_dummy.h"
#include "dbutils.h"
#include "ns_Constants.h"
#include "hpss_get_attr.h"

int registed_client = 0;
int R_Log = FALSE;

#define GIGABYTE    (1024*1024*1024)
#define MEGABYTE    (1024*1024)
#define KILOBYTE    (1024)

void print_permission(unsigned32 Perm)
{
   if ( Perm & HPSS_PERM_READ ) printf("r"); else printf("-");
   if ( Perm & HPSS_PERM_WRITE ) printf("w"); else printf("-");
   if ( Perm & HPSS_PERM_EXEC ) printf("x"); else printf("-");
}

int local_dbutils_get_MediaType(char *volnum, char *mediatype)
{
    int status=0;
    char stmt[MAX_STMT_LEN];
    DBUTILS_RES *client_h, *client_2_h;
    char **row = NULL;

    sprintf(stmt, "SELECT type FROM cartridges WHERE volnum='%s';", volnum);
    client_h = dbutils_exec_query(stmt);
    if (client_h) {
        row = dbutils_fetch(client_h);
        if (row) {
            if (strcmp(row[0], "1") == 0) { strcpy(mediatype, "9940"); }
            else if (strcmp(row[0], "2") == 0) { strcpy(mediatype, "9940B"); }
            else if (strcmp(row[0], "3") == 0) { strcpy(mediatype, "LTO-3"); }
            else if (strcmp(row[0], "4") == 0) { strcpy(mediatype, "LTO-4"); }
            else if (strcmp(row[0], "5") == 0) { strcpy(mediatype, "LTO-5"); }
            else if (strcmp(row[0], "6") == 0) { strcpy(mediatype, "LTO-6"); }
            else if (strcmp(row[0], "7") == 0) { strcpy(mediatype, "LTO-7"); }
            else if (strcmp(row[0], "8") == 0) { strcpy(mediatype, "LTO-8"); }
            else if (strcmp(row[0], "10") == 0) { strcpy(mediatype, "T10K-D"); }
            else if (strcmp(row[0], "11") == 0) { strcpy(mediatype, "T10K-E"); }
            else strcpy(mediatype, "UNKNOWN");
        }
        else {
            strcpy(mediatype, "DB Error: NULL");
        }
        dbutils_free_result(client_h);
    }
    else {
        strcpy(mediatype, "DB Error: Connection failure");
        status=-1;
    }

    return status;
}


int local_dbutils_mkcl()
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h, *client_2_h;
    char **row = NULL;
    char stmt[MAX_STMT_LEN];
    int status = -1, delay = 0;
    time_t now;
    char *peer;

    now = time((time_t) NULL);

    peer = (char *)getenv("PEER_HOST");
    if ( peer == NULL )
        gethostname(localhost, 128);
    else
        strcpy(localhost, peer);

    batch_str.command = BATCH_CMD_OK;

    while (status <= 0 ) {
        sprintf(stmt, "SELECT threshold - count, delay FROM get_attr_ctrl");
        client_h = dbutils_exec_query(stmt);
        if (client_h) {
            row = dbutils_fetch(client_h);
            if (row) {
                status = atoi(row[0]);
                delay = atoi(row[1]);
            }
            dbutils_free_result(client_h);
        }
        if (status > 0) {
            sprintf(stmt, "UPDATE get_attr_ctrl SET count = count + 1 ");
            client_h = dbutils_exec_query(stmt);
            registed_client = 1;
        }
        else {
            sleep(1);
        }
    }
    sleep(delay);
}

void local_dbutils_unreg()
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char **row = NULL;
    char stmt[MAX_STMT_LEN];
    int status = -1;

    if (registed_client) {
        batch_str.command = BATCH_CMD_OK;
        sprintf(stmt, "UPDATE get_attr_ctrl SET count = count - 1 ");
        client_h = dbutils_exec_query(stmt);
        if (client_h)
            dbutils_free_result(client_h);
        registed_client = 0; /* in case if 2nd signal arrives... */

    }
}

int hpss_login()
{
  int rc, status;
  char auth_type[16]="unix";
  hpss_authn_mech_t mech_type = hpss_authn_mech_krb5;
  api_config_t      api_config;
  char ktpath[HPSS_MAX_PATH_NAME];
  char *hpss_home;

  hpss_home = (char *)getenv("HPSS_HOME");
  if ( ! hpss_home ) {
      printf("Environment variable HPSS_HOME is not set\n");
      exit(1);
  }

  status = local_dbutils_connect();
  if (status != 0) {
      printf("%s registration fail, please check your environment variables\n", progname);
      exit(1);
  }

  rc = hpss_AuthnMechTypeFromString(auth_type, &mech_type);
  if(rc != 0) {
    dtprintf(HERE, "ERROR: hpss_AuthnMechTypeFromString() failed: %d\n", rc);
    dtprintf(HERE, "invalid authentication type %s\n",auth_type);
    exit(rc);
  }

  rc = hpss_GetConfiguration(&api_config);
  if(rc != 0) {
    dtprintf(HERE, "ERROR: hpss_GetConfiguration() failed: %d\n", rc);
    local_dbutils_unreg();
    exit( rc );
  }

  api_config.AuthnMech = mech_type;
  api_config.Flags |= API_USE_CONFIG;

  rc = hpss_SetConfiguration(&api_config);
  if(rc != 0) {
    dtprintf(HERE, "ERROR: hpss_SetConfiguration() failed: %d\n", rc);
    local_dbutils_unreg();
    exit( rc );
  }

  sprintf(ktpath, "%s/config/keytabs/%s.unix.keytab", hpss_home, imp_user);
  printf("Loading %s\n", ktpath);
  rc = hpss_SetLoginCred(imp_user,
                         mech_type,
                         hpss_rpc_cred_client,
                         hpss_rpc_auth_type_keytab,
                         ktpath);
  if (rc != 0)
  {
    dtprintf(HERE, "ERROR: hpss_SetLoginCred() failed: %d\n", rc);
    local_dbutils_unreg();
    exit(1);
  }


}

int show_file_attr(fstruct_t *hpss_fs)
{
   int status;
   if (hpss_fs->filename) {
       status = get_file_attr(hpss_fs);
       if (status == 0 || hpss_fs->ftype == 'd') {
             if (hpss_fs->chkbadtape) {
                 if (chk_tape_stat(hpss_fs->volnum[0]) == 1) {
                   /* printf("%s %.0f ENOENT\n", hpss_fs->volnum[0], hpss_fs->size); */
                   status = -ENOENT;
                 }
             }
             if (hpss_fs->ftype == 'd') {
                 status = -EISDIR;
             }
             if (hpss_fs->feature == 1) {  /* statx */
               printf("%c ", hpss_fs->ftype);
               print_permission(hpss_fs->User_Perms);
               print_permission(hpss_fs->Group_Perms);
               print_permission(hpss_fs->Other_Perms);
               printf(" %lu %lu ", hpss_fs->uid, hpss_fs->gid);
               printf("%lu ", hpss_fs->atime);
               printf("%lu ", hpss_fs->ctime);
               printf("%lu ", hpss_fs->mtime);
               printf("%.0f\n", hpss_fs->size);
             }
             else { /* tapeid */
                   printf("%s\n", hpss_fs->volnum[0]);
             }
       }
       else {
           printf("ERROR: %d\n", status);
       }
   }
   return status;
}

void u_signed64_to_a(u_signed64 data, char *s)
{
  register int i;                       /* loop counter */
  u_signed64 tmp64;                     /* holder for input data */
  unsigned32 bytes;
/*  char s[DEC64_LEN]; */
  int first;
  double float_value;
  unsigned32 int_value;
  unsigned32 remainder;

  /*
   * Fill the output string with spaces, and copy the input data for
   * manipulation.
   */

    memset(s, ' ', DEC64_LEN);
    tmp64 = data;

    /*
     * Divide by 10 repeatedly, converting remainders to decimal digits,
     * until the 64-bit number is gone.
     */

    for (i = DEC64_LEN-2; i >= 0; i--) {
      s[i] = 0x30 | low32m(mod64m(tmp64, 10));
      tmp64 = div64m(tmp64 , 10);
      if (eqz64m(tmp64))
        break;
    }
    s[DEC64_LEN-1] = '\0';
  
    /* Get rid of leading spaces and zeros
     */
    for (i=0; i < DEC64_LEN; i++)
      if (s[i] != ' ' && s[i] != 0) {
        first = i;
        break;
      }

    if (first) {
      for (i=first; i < DEC64_LEN; i++)
        s[i-first] = s[i];
    }
}

int get_file_attr(fstruct_t *fs)
{
  int              rc;
  int              retry_cnt;
  int              i;
  int              j;
  int              foundVol=0;
  hpss_xfileattr_t file_attr;
  unsigned32       flags;
  char             uuid_str[64];
  u_signed64       Length;
  unsigned32       File_Type;
  unsigned32       Composite_Perms;

  retry_cnt = -1;
  flags     = API_GET_STATS_FOR_ALL_LEVELS;
  unsigned32 storagelevel = 0;

retry:
  retry_cnt++;

  if (debug) printf("DEBUG:%s|%d|Calling hpss_FileGetXAttributes()\n", __FILE__, __LINE__);
  rc = hpss_FileGetXAttributes(fs->filename,flags,storagelevel,&file_attr);
  if (debug) printf("DEBUG:%s|%d|rc=%d\n", __FILE__, __LINE__, rc);

  if (rc < 0)
  {
    if (rc != -ENOENT && retry_cnt < MAX_RETRY)
    {
      fprintf(stderr,"hpss_FileGetXAttributes: %d, retry(%d)..\n", rc, retry_cnt);
      sleep(RETRY_PERIOD);
      goto retry;
    }
    return(rc);
  }

  fs->size = 0;
  fs->storagelevel=-1;

  if (debug) printf("DEBUG:%s|%d|loop...\n", __FILE__, __LINE__);
  for (i=0; i<HPSS_MAX_STORAGE_LEVELS; i++)
  {
    if (debug) printf("DEBUG:%s|%d|i=%d\n", __FILE__, __LINE__, i);


    fs->ftype = ' ';
    if (file_attr.Attrs.Type == NS_OBJECT_TYPE_FILE || 
        file_attr.Attrs.Type == NS_OBJECT_TYPE_DIRECTORY) {
      switch (file_attr.Attrs.Type) {
      case NS_OBJECT_TYPE_FILE: fs->ftype = 'f'; break;
      case NS_OBJECT_TYPE_DIRECTORY: fs->ftype = 'd'; break;
      default: fs->ftype = ' ';
      } 
      fs->User_Perms = file_attr.Attrs.UserPerms - 1;
      fs->Group_Perms = file_attr.Attrs.GroupPerms;
      fs->Other_Perms = file_attr.Attrs.OtherPerms;
      fs->atime = (file_attr.Attrs.TimeLastRead > file_attr.Attrs.TimeLastWritten?file_attr.Attrs.TimeLastRead:file_attr.Attrs.TimeLastWritten);
      fs->ctime = file_attr.Attrs.TimeCreated;
      fs->mtime = file_attr.Attrs.TimeModified;
      fs->uid = file_attr.Attrs.UID;
      fs->gid = file_attr.Attrs.GID;
      fs->cos_id = file_attr.Attrs.COSId;
      if (debug) printf("DEBUG:%s|%d|File is a %c, fs->User_Perms: %d, COS: %d\n", __FILE__, __LINE__, fs->ftype, fs->User_Perms, fs->cos_id);
    }
    if (file_attr.SCAttrib[i].Flags & BFS_BFATTRS_DATAEXISTS_AT_LEVEL) {
      Length = file_attr.SCAttrib[i].BytesAtLevel;
      if (fs->storagelevel == -1)
          fs->storagelevel=i;
      fs->size = u64todouble(Length);
      strcpy(fs->size_str, u64tostr(Length));

      for (j=0; j<file_attr.SCAttrib[i].NumberOfVVs; j++)
      {
        if (debug) printf("DEBUG:%s|%d|j=%d\n", __FILE__, __LINE__, j);

        if ( file_attr.SCAttrib[i].VVAttrib[j].PVList != NULL) {
          memcpy(fs->volnum[foundVol],
                 file_attr.SCAttrib[i].VVAttrib[j].PVList[0].List.List_val[0].Name,
                 VOL_NAME_LEN);
          fs->volnum[foundVol][VOL_NAME_LEN] = '\0';
          foundVol++;

          free(file_attr.SCAttrib[i].VVAttrib[j].PVList[0].List.List_val);
          free(file_attr.SCAttrib[i].VVAttrib[j].PVList);
        }
      }
      fs->volnum[foundVol][0] = '\0';
    }
  }

  if (debug) printf("DEBUG:%s|%d\n", __FILE__, __LINE__);
  return(0);
}

int local_dbutils_connect() 
{
  local_dbutils_init();

  mysql_init(&mysql_db);

  return (dbutils_real_connect());
}

int local_dbutils_init()
{
    char *host, *user, *pw, *db;
    host = (char *)getenv("DB_HOST");
    user = (char *)getenv("DB_USER");
    pw = (char *)getenv("DB_PW");
    db = (char *)getenv("DB_DATABASE");

    if (!host || !user || !pw || !db) {
        printf("Misssing required environment virable\n");
        printf("DB_HOST=%s\n", host);
        printf("DB_USER=%s\n", user);
        printf("DB_PW=%s\n", pw);
        printf("DB_DATABASE=%s\n", db);
        return (-1);
    }
    strcpy(client_str.host, host);
    strcpy(client_str.user, user);
    strcpy(client_str.pw, pw);
    strcpy(client_str.db, db);
    client_str.reconnect_int = 60;
    client_str.log_enabled = 1;
}

int chk_tape_stat(char *volnum)
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h;
    char **row = NULL;
    char stmt[MAX_STMT_LEN];
    int status = 0;

    batch_str.command = BATCH_CMD_OK;
    sprintf(stmt, "SELECT status FROM cartridges WHERE volnum = '%s'", volnum);

    client_h = dbutils_exec_query(stmt);
    if (client_h) {
        row = dbutils_fetch(client_h);
        if (row) {
            status = atoi(row[0]);
        }
        dbutils_free_result(client_h);
    }
    else
        status = -1;

    return status;
}

int log_access(char *username, char *hostname, char *version)
{
    int sql_status = P_SUCCESS;
    DBUTILS_RES *client_h, *client_2_h;
    char **row = NULL;
    char stmt[MAX_STMT_LEN];
    int status = 0;
    time_t now;

    now = time((time_t) NULL);

    batch_str.command = BATCH_CMD_OK;
    sprintf(stmt, "SELECT count FROM get_attr_clients WHERE user='%s' AND host='%s'", username, hostname);
    client_h = dbutils_exec_query(stmt);
    if (client_h) {
        row = dbutils_fetch(client_h);
        if (row) {
            sprintf(stmt, "UPDATE get_attr_clients SET count=count+1, hits = hits + 1, last_access = %ld, version='%s' WHERE user = '%s' AND host = '%s'", now, HPSS_GET_ATTR_VERSION, username, hostname);
            client_2_h = dbutils_exec_query(stmt);
            dbutils_free_result(client_2_h);
        }
        else {
            sprintf(stmt, "INSERT INTO get_attr_clients SET user = '%s', host = '%s', count = 1, hits = 1, init_access = %ld, last_access = %ld, version='%s'", username, hostname, now, now, HPSS_GET_ATTR_VERSION);
            client_2_h = dbutils_exec_query(stmt);
            dbutils_free_result(client_2_h);
        }
        dbutils_free_result(client_h);
    }

}

