#ifndef _THREAD_UTILS_H_
#define _THREAD_UTILS_H_

#include <stdio.h>
#include "hpss_api.h"

#define HERE  __FILE__,__LINE__
#define ROOT  0
#define DMASK 0644
typedef hpss_uuid_t uuid_t;

#ifdef MAXTHREADS
#undef MAXTHREADS
#endif

#if _AIX
#define MAXTHREADS 1024
#else
#define MAXTHREADS 900
#endif

#define SUGTHREADS 32
#define SUG_STAGING_THRS 256
#define SUG_READING_THRS 32

/* Thread stack size */
#define MIN_STACK_SIZE_PER_THREAD 34952
#define STACK_REDUCE_RATIO 10

void   init_utils();
double double_time();
void   tprint(char *, ...);
void   dtprint(char *, int, char *, ...);
void   uuidtoa(uuid_t, char *);
void   init_lock(pthread_mutex_t *);
void   lock(pthread_mutex_t *);
void   unlock(pthread_mutex_t *);
void   thread_ctrl();
boolean_t   spawn_thread(pthread_t *, void (*)(), void *, char *);
boolean_t   spawn_thread_managed(pthread_t *, void (*)(), void *, char *);
void   kill_thread(char *);
int    get_maxthreads();
int    set_maxthreads(int);
int   set_reserved_copy_threads(int);
int   set_reserved_max_mdl_threads(int);
int   set_reserved_que_threads(int);
int   set_reserved_staging_threads(int);
int   update_que_job_threads();
int   update_max_que_job_threads();
void show_thread_alloc();

#endif /* _THREAD_UTILS_H_ */
