#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include <pwd.h>
#include <sys/stat.h>

#include "u_signed64.h"
#include "hpss_api.h"
#include "hpss_queue.h"
#include "common.h"
#include "batch.h"
#include "thread_utils.h"
#include "batch_utils.h"

/*   Global Variables    */                                                                    
extern int hpss_GetStorageLevel_Etc( char    *Filename,
                                     hpssoid_t  *BitFile_Id,
                                     u_signed64 *Length,
                                     hpssoid_t  *VVID,
                                     signed32   *Position,
                                     unsigned32 *File_Type, 
                                     unsigned32 *Composite_Perms, 
                                     signed32   *Storage_Level,
                                     cos_t   *Cos_Id,
                                     char   *Vol_Name 
                                     );

config_t Config;     /* Master configuration                         */

int R_Log = FALSE;   /* Flag for local logging */


#define MAX_VOL_NAME_LEN 15  /* actual length 12 */

void usage(char *progname)
{
    printf("Syntax error: INVALID ARGUMENTS\n");
    printf("    %s <fullpath filename>\n", progname);
}

void main (int argc, char *argv[])
{
  /* Must initialize the utils functions. Used to protect logging in the */
  /* threaded environment. Read in the configuration file.               */
  int     rc;
  int status;
  char *filename;
  char volnum[MAX_VOL_NAME_LEN];

  if ( argc == 1 ) {
      usage(argv[0]);
      exit(1);
  }
  filename = (char *)strdup(argv[1]);

  if ((rc = hpss_SetAuthType(API_AUTH_LOGIN_NONE)) < 0)
  {
    dtprintf(HERE, "ERROR: hpss_SetAuthType() failed: %d\n", rc);
    exit(1);
   }

  /* ROOT=0, uid of dce user "root" */

  if ((rc = hpss_LoadThreadState(ROOT,DMASK,0)) < 0)
  {
    dtprintf(HERE, "ERROR: hpss_LoadThreadState() failed: %d\n", rc);
    exit(1);
   }

   if (filename) {
       status = get_tape_id(filename, volnum);
       printf("%s\n", volnum);
       free(filename);
   }
   exit(status);
}

int get_tape_id(char *filename, char *volnum)
{
    hpssoid_t      bitfile_id;
    u_signed64     length;
    hpssoid_t      vvid;
    signed32       rel_position;
    unsigned32     file_type;
    unsigned32     all_perms;
    signed32       storage_level;
    cos_t         cosid;
    int status;

    status = hpss_GetStorageLevel_Etc(filename,   
                                      &bitfile_id,
                                      &length,
                                      &vvid,
                                      &rel_position,
                                      &file_type,
                                      &all_perms,
                                      &storage_level,
                                      &cosid,
                                      volnum);

    return status;
}
