/* 11/13/2002 Razvan: Modified for non-DCE mode: Changed boolean to boolean_t */

#ifndef _BATCH_H_
#define _BATCH_H_

#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include <dirent.h>
#include "u_signed64.h"
#include "hpss_api.h"
#include "common.h"

/* Configurable Values */

#define MAX_TRIES       5                  /* Number of retries                          */
#define MAX_JOBTIME     (3600*24)          /* Warning threshold for job                  */
#define MAX_COPIES      256                /* Max number of copy threads                 */
#define MAX_STATS_JOBS  20                 /* Max number of jobs held in stats structure */
#define NUM_QUEUES      2                  /* Number of active queues                    */
#define NUM_REQUESTS    9                  /* Number of active requests                  */
#define POLL_TIME       2                  /* Queue polling time                         */
#define BUFSIZE         (1*1024*1024)      /* Size of buffers during copy                */
 
#define INPUT_INTERVAL  {60,0}             /* 1 minute  */
/* 022803 Grace */
#define WORK_INTERVAL   {1,0}              /* 1 sec, dont use the second value since sleep is being used */
                                           /* to replace pthread_delay_np. Sleep only takes seconds      */
#define UPDATE_INTERVAL {300,0}            /* 5 minutes */        
 
/* Non-configurable Values */

#define NEW      0    /* Files start here                         */
#define QUEUED   1    /* File put into queue mechanism            */
#define STAGED   2    /* File is now on HPSS disk                 */
#define RETRY    3    /* Stage failed? try again                  */
#define PENDING  4    /* File is about to be copied to user space */
#define COPYING  5    /* File is being copied to user space       */
#define FAILED   6    /* Something didnt work                     */
#define COPIED   7    /* Complete, file copied to user space      */

#define NOWORK_INTERVAL {30,0}  /* 30 secs */
/* Structure for request information */

typedef struct request
{
  char      *hpss_file_name;             /* Name of HPSS file              */
  char      *destination_file_name;      /* Name of user space file        */
  int        state;                      /* State of file                  */
  int        tries;                      /* Number of retries              */
  int        error_code;                 /* Error, if any                  */
  int        exp_minute;		 /* Delete request after this time */
  time_t     exp_time;		 	 /* Expiration time		   */
  struct job  *job_ptr;                  /* Pointer back to job definition */
  int        priority;
} request_t;

/* Structure for job information */

typedef struct job
{
  char         job_id[_D_NAME_MAX];       /* Id of batch job                    */
  time_t       start_time;                /* Start time for job                 */
  boolean_t    warned;                    /* Admin warned flag                  */
  int          num_requests;              /* Number of requests in job          */
  int          num_processed;             /* Number completed                   */
  int          num_failed;                /* Number of requests that failed     */
  u_signed64   bytes_moved;               /* # of bytes moved                   */
  request_t   *request_list;              /* Pointer to list of files requested */
  char         notify_email[EMAIL_LEN+1]; /* Who to notify when job completed   */
  char         local_id_str[USER_LEN+1];  /* Id of local user                   */
  int          local_uid;
  int          local_gid;
  char         hpss_id_str[USER_LEN+1];   /* Id of hpss user                    */
  int          hpss_uid;
  int          hpss_gid;
  char         output_file[MAXPATHLEN+1]; /* Output file                        */
  struct job  *prev;                      /* Previous job in list               */
  struct job  *next;                      /* Next job in list                   */
} job_t;

/* Structure for job queue */

typedef struct job_queue
{
  pthread_mutex_t    lock;                /* Lock on queue                */
  int                num_jobs;            /* Number of jobs               */
  job_t             *head;                /* Head of job list             */
  job_t             *tail;                /* Tail of job list             */
} job_queue_t;

extern config_t  Config;                 /* Holder of all config info */

/* Declaration of local functions */

void       replay_working();
void       move_bad_file(char *, char *);
job_t     *process_file(char *, char *, boolean_t);
job_t     *create_job(char *, int);
void       insert_job(job_t *);
void       remove_job(job_t *);
void       delete_job(job_t *);
void       update_progress();
void       get_new_work();
void       update_working_file(job_t *);
void       finalize_working_file(job_t *);
void       do_work();
void       complete_job(job_t *);
void       stage_function(request_t *, int);
void       do_copy(request_t *);
boolean_t  check_file_access(char *, int, int);
void       queue_job(job_t *);
void       PurgeLockMonitor();

#endif /* _BATCH_H_ */
