#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include <pwd.h>
#include <sys/stat.h>

#include "u_signed64.h"
#include "hpss_api.h"
#include "hpss_queue.h"
#include "common.h"
#include "batch.h"
#include "thread_utils.h"
#include "batch_utils.h"

int stage_opt;

/*   Global Variables    */                                                                    

config_t         Config;                    /* Master configuration                         */
int              R_Log = FALSE;             /* Flag for local logging                       */
extern int bu_lock_debug;
void cfg_init();

char replay_file = ' ';

void main (int argc, char *argv[])
{
  /* Must initialize the utils functions. Used to protect logging in the */
  /* threaded environment. Read in the configuration file.               */
  int     rc;
  int status;
  char ktpath[HPSS_MAX_PATH_NAME];
  char auth_type[16]="unix";
  hpss_authn_mech_t mech_type = hpss_authn_mech_krb5;
  api_config_t      api_config;
  char	  *hpss_home;

  printf("\n");
  printf("This program will unlock all purge-locked files locked by Batch system.\n\n");

  init_utils();
  read_config();
  check_config();

  if ( (status = dbutils_connect()) != P_SUCCESS ) {
      printf("Unable to connect to MySQL\n");
      exit;
  }
  cfg_init();
 
  rc = hpss_AuthnMechTypeFromString(auth_type, &mech_type);
  if(rc != 0) {
    dtprintf(HERE, "ERROR: hpss_AuthnMechTypeFromString() failed: %d\n", rc);
    dtprintf(HERE, "invalid authentication type %s\n",auth_type);
    exit(rc);
  }

  rc = hpss_GetConfiguration(&api_config);
  if(rc != 0) {
    dtprintf(HERE, "ERROR: hpss_GetConfiguration() failed: %d\n", rc);
    bu_terminate();
    exit( rc );
  }

  api_config.AuthnMech = mech_type;
  api_config.Flags |= API_USE_CONFIG;

  rc = hpss_SetConfiguration(&api_config);
  if(rc != 0) {
    dtprintf(HERE, "ERROR: hpss_SetConfiguration() failed: %d\n", rc);
    bu_terminate();
    exit( rc );
  }

  hpss_home=(char *)getenv("HPSS_HOME");
  sprintf(ktpath, "%s/config/keytabs/%s.unix.keytab", hpss_home, client_str.user);
  printf("Loading keytab: %s\n", ktpath);

  rc = hpss_SetLoginCred(client_str.user,
                         mech_type,
                         hpss_rpc_cred_client,
                         hpss_rpc_auth_type_keytab,
                         ktpath);
  if (rc != 0)
  {
    dtprintf(HERE, "ERROR: hpss_SetLoginCred() failed: %d\n", rc);
    bu_terminate();
    exit(1);
  }
   sleep(1);

   bu_lock_debug = 1;
   printf("Pricessing Unlocking...\n");
   bu_unlock_purge_locked_files();
 
  return;
}

void cfg_init()
{
    time_t current_time;

        strcpy(batch_str.id, client_str.user);
        strcpy(batch_str.localhost, (char *)getenv("HOSTNAME"));
        batch_str.pid = getpid();
        batch_str.status = BATCH_INIT;
        *(batch_str.msg) = '\0';
        batch_str.ques = 0;
        batch_str.rows = 0;
        batch_str.command = BATCH_CMD_OK;
        batch_str.translog_life = DEFAULT_TRANSLOG_LIFE;
        batch_str.purlock_life = DEFAULT_PURGELOCK_LIFE;
        current_time = time((time_t *)NULL);
        batch_str.last_purge = current_time;
}
