#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include "hpss_api.h"
#include "common.h"
#include "batch.h"
#include "thread_utils.h"

#define THR_QUE_JOB 1
#define THR_STAGE   2
 
/* inModule("thread_utils.c"); */   /* 11/13/2002 Razvan: Removed for non-DCE
                                        mode. Not sure what it does.       */
 
pthread_mutex_t    Tprint_Lock;     /* Normal timed print                  */
pthread_mutex_t    DTprint_Lock;    /* Debug (File+Line) timed print       */
pthread_mutex_t    spawn_Lock;      /* lock for spawning a new thread.     */
pthread_mutex_t    q_spawn_Lock;    /* lock for spawning a new thread.     */
pthread_mutex_t    s_spawn_Lock;    /* lock for spawning a new thread.     */
pthread_mutex_t    thread_ct_lock;  /* Thread_Cnt lock                     */
pthread_mutex_t    q_thread_ct_lock;/* Thread_Cnt lock                     */
pthread_mutex_t    s_thread_ct_lock;/* Thread_Cnt lock                     */
int                Thread_Cnt = 0;  /* Debug info, keep a count of threads */
int                Q_Thread_Cnt = 0;/* Debug info, keep a count of threads */
int                S_Thread_Cnt = 0;/* Debug info, keep a count of threads */
extern int         R_Log, Q_Log;    /* Debug flags                         */
extern config_t    Config;          /* Master Configuration                */

int reserved_copy_threads = 0;
int reserved_que_threads = 0;
int reserved_max_mdl_threads = 0;   /* max meta-data lookup threads        */
int reserved_staging_threads = SUG_STAGING_THRS;

pthread_mutex_t mutex;  /* mutex id */
pthread_attr_t attr;
size_t stacksize;

int get_maxthreads()
{
    return reserved_que_threads;
}

int set_reserved_copy_threads(int val)
{
    if (val > MAX_COPIES) {
        val = MAX_COPIES;
        if (R_Log || Q_Log)
            printf("Requested Max number of COPY threads is too large, adjusted to %d\n", val);
    }

    if (val < 0) {
        val = 0;
        if (R_Log || Q_Log)
            printf("Requested Max number of COPY threads is not reasonable, adjusted to %d (Please adjust the parameter wisely!)\n", val);
    }

    if (R_Log || Q_Log)
        printf("Reserved number of COPY threads: %d\n", val);
    reserved_copy_threads = val;
    return val;
}


int set_reserved_max_mdl_threads(int val)
{
    int max_allowed_threads = MAXTHREADS - SUGTHREADS - reserved_copy_threads;

    if (val > max_allowed_threads ) {
        val = max_allowed_threads;
        if (R_Log || Q_Log)
            printf("Requested Max number of QUEUE JOB Limit threads is too large, adjusted to %d\n", val);
    }

    if (val < 0) {
        val = SUGTHREADS;
        if (R_Log || Q_Log)
            printf("Requested Max number of QUEUE JOB threads is reasonable, adjusted to minimun %d (Please adjust the parameter wisely!)\n", val);
    }

    if (R_Log || Q_Log)
        printf("Reserved number of QUEUE JOB Limit threads: %d\n", val);
    reserved_que_threads = val;
    return val;
}

int set_reserved_que_threads(int val)
{

    if (val > reserved_max_mdl_threads ) {
        val = reserved_max_mdl_threads;
        if (R_Log || Q_Log)
            printf("Requested Max number of QUEUE JOB threads is too large, adjusted to %d\n", val);
    }

    if (val < 0) {
        val = reserved_max_mdl_threads;
        if (R_Log || Q_Log)
            printf("Requested Max number of QUEUE JOB threads is reasonable, adjusted to minimun %d (Please adjust the parameter wisely!)\n", val);
    }

    if (R_Log || Q_Log)
        printf("Reserved number of QUEUE JOB threads: %d\n", val);
    reserved_que_threads = val;
    return val;
}

int set_max_que_threads(int val)
{
    int max_allowed_threads = MAXTHREADS - SUGTHREADS - reserved_copy_threads;

    if (val > max_allowed_threads ) {
        val = max_allowed_threads;
        if (R_Log || Q_Log)
            printf("Requested Max number of QUEUE JOB threads is too large, adjusted to %d\n", val);
    }

    if (val < 0) {
        val = SUGTHREADS;
        if (R_Log || Q_Log)
            printf("Requested Max number of QUEUE JOB threads is reasonable, adjusted to minimun %d (Please adjust the parameter wisely!)\n", val);
    }

    if (R_Log || Q_Log)
        printf("Reserved MAX number of QUEUE JOB threads: %d\n", val);
    reserved_max_mdl_threads = val;
    return val;
}

int set_reserved_staging_threads(int val)
{
    /* max_allowed_threads = 300 - min_queue_job_thrs - reserved_copy_threads */
    int max_allowed_threads = MAXTHREADS - SUGTHREADS - reserved_copy_threads;

    if (val > max_allowed_threads) {
        val = max_allowed_threads;
        if (R_Log || Q_Log)
            printf("Reserved number of threads for staging is too large, adjusted to %d\n", val);
    }
    else
        if (R_Log || Q_Log)
            printf("Reserved number of STAGING threads: %d\n", val);

    if (val < 0) {
        val = 0;
        if (R_Log || Q_Log)
            printf("Requested Max number of STAGING threads is not reasonable, adjusted to minimun %d (Please adjust the parameter wisely!)\n", val);
    }

    reserved_staging_threads = val;
    return val;
}

int set_max_staging_threads(int val)
{
    int max_allowed_threads = MAXTHREADS - SUGTHREADS - reserved_copy_threads;

    if (val > max_allowed_threads) {
        val = max_allowed_threads;
        if (R_Log || Q_Log)
            printf("Max number of threads for staging is too large, adjusted to %d\n", val);
    }
    else
        if (R_Log || Q_Log)
            printf("Max number of STAGING threads: %d\n", val);

    if (val < 0) {
        val = 0;
        if (R_Log || Q_Log)
            printf("Requested Max number of STAGING threads is not reasonable, adjusted to minimun %d (Please adjust the parameter wisely!)\n", val);
    }

    reserved_staging_threads = val;
    return val;
}

int update_que_job_threads()
{
    int max_allowed_threads = MAXTHREADS - reserved_copy_threads - reserved_staging_threads;

    if (R_Log || Q_Log)
        printf("Suggesting Min number of QUEUE JOB threads adjustment: %d\n", reserved_max_mdl_threads);

    if (max_allowed_threads < SUGTHREADS) {  /* Reserving min of 32 threads */
        int shortage = SUGTHREADS - max_allowed_threads;
        reserved_que_threads = SUGTHREADS;
        if (R_Log || Q_Log)
            printf("Reserved number of QUEUE JOB threads is adjusted to: %d\n", reserved_que_threads);
        if (R_Log || Q_Log)
            printf("Attempt to reduce %d threads from STAGING\n", shortage);
        set_reserved_staging_threads(reserved_staging_threads - shortage);
    }
    else {
        if (reserved_que_threads == reserved_max_mdl_threads ) {
                printf("Number of job threads: No change.\n");
        } 
        else {
            reserved_que_threads = reserved_max_mdl_threads;  /* Use all the rest */
            if (R_Log || Q_Log)
                printf("Min number of job threads is adjusted to: %d\n", reserved_que_threads);
        }
    } 

    return reserved_que_threads;
}

 
int update_max_que_job_threads()
{
    int max_allowed_threads = MAXTHREADS - reserved_copy_threads - reserved_staging_threads;

    if (R_Log || Q_Log)
        printf("Suggesting Max number of QUEUE JOB threads adjustment: %d\n", max_allowed_threads);

    if (max_allowed_threads < SUGTHREADS) {  /* Reserving min of 32 threads */
        int shortage = SUGTHREADS - max_allowed_threads;
        reserved_max_mdl_threads = SUGTHREADS;
        if (R_Log || Q_Log)
            printf("Reserved number of QUEUE JOB threads is adjusted to: %d\n", reserved_max_mdl_threads);
        if (R_Log || Q_Log)
            printf("Attempt to reduce %d threads from STAGING\n", shortage);
        set_max_staging_threads(reserved_staging_threads - shortage);
    }
    else {
         if (reserved_max_mdl_threads == max_allowed_threads ) {
            printf("Max number of job threads: No change.\n");
         }
         else {
            reserved_max_mdl_threads = max_allowed_threads;  /* Use all the rest */
            if (R_Log || Q_Log)
                printf("Max number of job threads is adjusted to: %d\n", reserved_max_mdl_threads);
         }
    } 

    return reserved_max_mdl_threads;
}

void show_thread_alloc()
{
    if (R_Log || Q_Log) {
        printf("\nThread Allocation Map\n");
        printf("       Copy: [ %d ]\n", reserved_copy_threads);
        printf("    Staging: [ %d ]\n", reserved_staging_threads);
        printf("    Que Job: [ %d ]\n", reserved_que_threads);
        printf("Max Que Job: [ %d ]\n", reserved_max_mdl_threads);
        printf("      Total: [ %d ]\n\n", reserved_que_threads + reserved_staging_threads + reserved_copy_threads);

    }
}

/*================================================================*/
/*     init_utils() : Initialize locking on the print locks.      */
/*================================================================*/

void init_utils()
{
  char *maxthreads_str;

  pthread_attr_getstacksize(&attr, &stacksize);
  stacksize = stacksize / STACK_REDUCE_RATIO;

  if ( stacksize < MIN_STACK_SIZE_PER_THREAD )
      stacksize = MIN_STACK_SIZE_PER_THREAD;

  pthread_attr_setstacksize(&attr, stacksize);
  pthread_attr_getstacksize(&attr, &stacksize);
  printf("New stacksize: %d\n", stacksize);


  /*-- make sure Tprint_Lock is terminated and removed --- */
  if (pthread_mutex_init(&Tprint_Lock,pthread_mutexattr_default) != 0)
  {
    printf("%s:%d ERROR: pthread_mutex_init() failed: %d\n", HERE, errno);
    exit(-1);
  }

  /*-- make sure DTprint_Lock is terminated and removed --*/
  if (pthread_mutex_init(&DTprint_Lock,pthread_mutexattr_default) != 0)
  {
    printf("%s:%d ERROR: pthread_mutex_init() failed: %d\n", HERE, errno);  
    exit(-1);
  }
 
  /*-- make sure spawn_Lock is terminated and removed --*/
  if (pthread_mutex_init(&spawn_Lock,pthread_mutexattr_default) != 0)
  {
    printf("%s:%d ERROR: pthread_mutex_init() failed: %d\n", HERE, errno);  
    exit(-1);
  }
 
  /*-- make sure q_spawn_Lock is terminated and removed --*/
  if (pthread_mutex_init(&q_spawn_Lock,pthread_mutexattr_default) != 0)
  {
    printf("%s:%d ERROR: pthread_mutex_init() failed: %d\n", HERE, errno);  
    exit(-1);
  }
 
  /*-- make sure s_spawn_Lock is terminated and removed --*/
  if (pthread_mutex_init(&s_spawn_Lock,pthread_mutexattr_default) != 0)
  {
    printf("%s:%d ERROR: pthread_mutex_init() failed: %d\n", HERE, errno);  
    exit(-1);
  }
 
  /*-- make sure thread_ct_lock is terminated and removed --*/
  if (pthread_mutex_init(&thread_ct_lock,pthread_mutexattr_default) != 0)
  {
    printf("%s:%d ERROR: pthread_mutex_init() failed: %d\n", HERE, errno);  
    exit(-1);
  }

  /*-- make sure q_thread_ct_lock is terminated and removed --*/
  if (pthread_mutex_init(&q_thread_ct_lock,pthread_mutexattr_default) != 0)
  {
    printf("%s:%d ERROR: pthread_mutex_init() failed: %d\n", HERE, errno);  
    exit(-1);
  }

  /*-- make sure s_thread_ct_lock is terminated and removed --*/
  if (pthread_mutex_init(&s_thread_ct_lock,pthread_mutexattr_default) != 0)
  {
    printf("%s:%d ERROR: pthread_mutex_init() failed: %d\n", HERE, errno);  
    exit(-1);
  }

  if ((maxthreads_str = getenv("MAX_THREADS")) != NULL) 
  {
      if (R_Log || Q_Log)
          printf("MAX_THREADS: %s\n", maxthreads_str);
      reserved_que_threads = atoi(maxthreads_str);
  }

  init_Master_Lock();

  if (R_Log || Q_Log)
      printf("Initial max number of threads: %d\n", reserved_que_threads);

  return;
}
 
/*==========================================================================*/
/* double_time(): Return the current time in seconds + fractions thereof    */
/*                                                                          */
/* Return Values: Time in floating point format.                            */
/*==========================================================================*/

double double_time()
{
  struct timeval tv;

  gettimeofday(&tv,NULL);
  return((double)(tv.tv_sec) + (double)(tv.tv_usec)/1000000.0);
}

/*==========================================================================*/
/* tprintf() : Print the current date and time along with the normal format */
/*                                                                          */
/* Arguments:                                                               */
/*    char  *format                                                         */
/*    ...                                                                   */
/*                                                                          */
/* Externals:                                                               */
/*    pthread_mutex_t   Tprint_Lock                                         */
/*==========================================================================*/

int tprintf(char *format,         /* In - Format to use when printing */
            ...)                  /* In - Potluck, just like printf   */
{
  va_list     ap;
  struct tm   ltime;
  time_t      current_time;

  lock(&Tprint_Lock);
  va_start(ap,format);
 
  current_time = time((time_t *)NULL);
  localtime_r(&current_time,&ltime);
  printf("%02d/%02d/%04d-%02d:%02d:%02d ", ltime.tm_mon+1, ltime.tm_mday,
         ltime.tm_year+1900, ltime.tm_hour, ltime.tm_min, ltime.tm_sec);
  vprintf(format,ap);
  va_end(ap);
  fflush(stdout);
  unlock(&Tprint_Lock);
  
  return(0);
}

/*========================================================================*/
/*  dtprintf() : Print the current date and time. First two arguments are */
/*               the name of the file and line number. Rest of format is  */
/*               then processed.                                          */
/*                                                                        */
/*  Arguments:                                                            */
/*     char     *file   : In - Name of file called from                   */
/*     int       line   : In - Line number where called                   */
/*     char     *format : In - Format to use when printing                */
/*     ...              : In - Potluck, just like printf                  */
/*                                                                        */
/*  Externals:                                                            */
/*     pthread_mutex_t   DTprint_Lock                                     */
/*========================================================================*/

int dtprintf(char *file, int line, char *format, ...)
{
  va_list      ap;
  struct tm    ltime;
  time_t       current_time;

  lock(&DTprint_Lock);
  va_start(ap,format);

  current_time = time((time_t *) NULL);
  localtime_r (&current_time,&ltime);
 
  printf("%02d/%02d/%04d-%02d:%02d:%02d \"%s:%d\" ", ltime.tm_mon+1,
         ltime.tm_mday, ltime.tm_year+1900, ltime.tm_hour,
         ltime.tm_min, ltime.tm_sec, file, line);
 
  vprintf(format,ap);

  va_end(ap);
  fflush(stdout);
  unlock(&DTprint_Lock);

  return(0);
}
 
/*=============================================================*/
/* uuidtoa(): Turn on hpss object id into a printable string.  */
/*                                                             */
/* Arguments:                                                  */
/*    uuid_t    Object_Id                                      */
/*    char     *Out_Str                                        */
/*=============================================================*/

void uuidtoa(uuid_t  Object_Id,     /* In - Object Id to convert    */
             char   *Out_Str)       /* Out- String to place results */
{
  sprintf(Out_Str, "%08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x",
                    Object_Id.time_low,
                    Object_Id.time_mid,
                    Object_Id.time_hi_and_version,
                    Object_Id.clock_seq_hi_and_reserved,
                    Object_Id.clock_seq_low,
                    Object_Id.node[0],
                    Object_Id.node[1],
                    Object_Id.node[2],
                    Object_Id.node[3],
                    Object_Id.node[4],
                    Object_Id.node[5]);
  return;
}

/*============================================================================*/
/* init_lock() : This function is a wrapper for 'pthread_mutex_init'. We exit */
/*               if this routine fails for any reason. Probably little point  */
/*               continuing if something this basic fails.                    */
/*                                                                            */
/* Arguments:                                                                 */
/*    pthread_mutex_t  *Lock                                                  */
/*============================================================================*/

void init_lock(pthread_mutex_t *Lock)     /* In - Pointer to the lock */
{
  if (pthread_mutex_init(Lock,pthread_mutexattr_default) != 0)
  {
    dtprintf(HERE, "ERROR: pthread_mutex_init() failed: %d\n", errno);
    exit(-1);
  }
  return;
}
 
/*=======================================================================*/
/* lock() : This function is a wrapper for 'pthread_mutex_lock'. We exit */
/*          if this routine fails for any reason. Probably little point  */
/*          continuing if something this basic fails.                    */
/*                                                                       */
/* Arguments:                                                            */
/*    pthread_mutex_t  *Lock                                             */
/*=======================================================================*/

void lock(pthread_mutex_t *Lock)  /* In - Pointer to the lock */
{
  int err;
  if ( (err = pthread_mutex_lock(Lock)) != 0)
  {
    dtprintf(HERE, "ERROR: pthread_mutex_lock() failed: %d\n", err);
    exit(-1);
  }

  return;
}
 
/*=======================================================================*/
/* unlock() : This function is a wrapper for 'pthread_mutex_unlock'. We  */
/*            exit if this routine fails for any reason. Probably little */
/*            point in continuing if something this simply fails.        */
/*                                                                       */
/* Arguments:                                                            */
/*      pthread_mutex_t  *Lock                                           */
/*=======================================================================*/

void unlock(pthread_mutex_t *Lock)            /* In - Pointer to the lock */
{
  if (pthread_mutex_unlock(Lock) != 0)
  {
    dtprintf(HERE, "ERROR: pthread_mutex_unlock() failed: %d\n",errno);
    exit(-1);
  }

  return;
}

/*=======================================================================*/
/* trylock() : This function is a wrapper for 'pthread_mutex_trylock'.   */
/*                                                                       */
/* Arguments:                                                            */
/*      pthread_mutex_t  *Lock                                           */
/*=======================================================================*/
int trylock(pthread_mutex_t *Lock)           /* In - Pointer to the lock */
{
  return(pthread_mutex_trylock(Lock));
}

/*==============================================================================*/
/* thread_ct_incr(): This function will increase the thread counter.            */
/*==============================================================================*/
void thread_ct_incr(int thr_type)
{
    lock(&thread_ct_lock);
    Thread_Cnt++;
    unlock(&thread_ct_lock);

    if (thr_type == THR_QUE_JOB) {
//       printf("Locking q_thread_ct_lock\n");
       lock(&q_thread_ct_lock);
//       printf("Increasing Q_Thread_Cnt: %d\n", Q_Thread_Cnt);
       Q_Thread_Cnt++;
//       printf("Q_Thread_Cnt increaded: %d, unlock q_thread_ct_lock\n", Q_Thread_Cnt);
       unlock(&q_thread_ct_lock);
    }

    if (thr_type == THR_STAGE) {
       lock(&s_thread_ct_lock);
       S_Thread_Cnt++;
       unlock(&s_thread_ct_lock);
    }
}

/*==============================================================================*/
/* thread_ct_decr(): This function will reduce the thread counter, and unlock   */
/*                   the thread control lock if necessary.                      */
/*==============================================================================*/
void thread_ct_decr(int thr_type)
{
    lock(&thread_ct_lock);
    Thread_Cnt--;
    unlock(&thread_ct_lock);

    if (trylock(&spawn_Lock)) {
/*        printf("Unlocking Total Number of thread lock [Thread_Cnt:%d]\n", Thread_Cnt); */
        unlock(&spawn_Lock);
/*        printf("Total Number of thread lock (spawn_Lock) unlocked\n"); */
    }

    if (thr_type == THR_QUE_JOB) {
/*       printf("This is a Que_thread\n"); */
       lock(&q_thread_ct_lock);
/*       printf("Decreasing Q_Thread_Cnt %d\n", Q_Thread_Cnt); */
       Q_Thread_Cnt--;
       unlock(&q_thread_ct_lock);

       if (trylock(&q_spawn_Lock)) {
/*           printf("Unlocking q_spawn_Lock\n"); */
           unlock(&q_spawn_Lock);
       }
/*       printf("Q_Thread_Cnt reduced:[%d]\n", Q_Thread_Cnt);  */
    }

    if (thr_type == THR_STAGE) {
       lock(&s_thread_ct_lock);
/*       printf("Decreasing S_Thread_Cnt [%d]\n", S_Thread_Cnt); */
       S_Thread_Cnt--;
       unlock(&s_thread_ct_lock);

       if (trylock(&s_spawn_Lock)) {
/*           printf("Unlocking s_spawn_Lock\n"); */
           unlock(&s_spawn_Lock);
       }
/*       printf("S_Thread_Cnt reduced:[%d]\n", S_Thread_Cnt); */
    }
}

/*==============================================================================*/
/* thread_ctrl() : This function is keeps tracking the number of threads        */
/*                 spawned by the current process, and wait when the number of  */
/*                 thraeds is reached the max number of threads, until the      */
/*                 thraed count reduced to below the limit.                     */
/*                 This function is highly recommended for spawning any non-    */
/*                 critical threads.  A non-critical thread means the function  */
/*                 can be blocked and wait until the resource become available. */
/*                                                                              */
/* Arguments:                                                                   */
/*    (none)                                                                    */
/*                                                                              */
/*==============================================================================*/

void thread_ctrl(int thr_type) 
{
    /* Check the total number of real threads spwaned first... */
    lock(&thread_ct_lock);
    if (Thread_Cnt >= MAXTHREADS) {
        unlock(&thread_ct_lock);

        if (R_Log || Q_Log)
            tprintf("** thread_ctrl: Max number of total threads reached [%d/%d], freezing thread spawn\n", Thread_Cnt, MAXTHREADS);

        lock(&spawn_Lock);

        if (R_Log || Q_Log)
            tprintf("** thread_ctrl: Thread count reduced [%d/%d], unfreeze thread spawn.\n", Thread_Cnt, MAXTHREADS);
    }
    else
        unlock(&thread_ct_lock);

    /* Check the number of threads spwaned for Queue Job quota... */
    if (thr_type == THR_QUE_JOB) {
        if (Q_Thread_Cnt >= reserved_max_mdl_threads) {
            unlock(&q_thread_ct_lock);

            if (R_Log || Q_Log)
                tprintf("* thread_ctrl: Max number of QUEUE JOB threads reached [%d/%d], freezing thread spawn\n", Q_Thread_Cnt, reserved_max_mdl_threads);

            lock(&q_spawn_Lock);

            if (R_Log || Q_Log)
                tprintf("* thread_ctrl: QUEUE JOB Thread count reduced [%d/%d], unfreeze thread spawn.\n", Q_Thread_Cnt, reserved_max_mdl_threads);
        }
    }

    /* Check the number of threads spwaned for Staging quota... */
    if (thr_type == THR_STAGE) {
        if (S_Thread_Cnt >= reserved_staging_threads) {
            unlock(&s_thread_ct_lock);

            if (R_Log || Q_Log)
                tprintf("* thread_ctrl: Max number of STAGE threads reached [%d/%d], freezing thread spawn\n", S_Thread_Cnt, reserved_staging_threads);

            lock(&s_spawn_Lock);

            if (R_Log || Q_Log)
                tprintf("* thread_ctrl: STAGE Thread count reduced [%d/%d], unfreeze thread spawn.\n", S_Thread_Cnt, reserved_staging_threads);
        }
    }

}

/*==============================================================================*/
/* spawn_thread_managed() : This function is a wrapper for spawn_thread() with  */
/*                          managing number of threads.                         */
/*                          The function to spawn will be suspended when the max*/
/*                          number of threads is reached until the thread count */
/*                          is reduced to below limit.                          */
/*                          This function is used for non-critical function that*/
/*                          can be wait.                                        */
/*==============================================================================*/
boolean_t spawn_thread_managed ( pthread_t   *Tid,                /* In - Thread Id           */
                            void       (*Function)(void *),  /* In - Function to spawn   */
                            void        *Arg,                /* In - Argument for func.  */
                            char        *Func_Name)          /* In - Function name.      */
{
        int thr_type = 0;

        if (!strcmp(Func_Name, "queue_job")) 
            thr_type = THR_QUE_JOB;

        if (!strcmp(Func_Name, "Queue_Worker")) 
            thr_type = THR_STAGE;

        thread_ctrl(thr_type);
        return(spawn_thread(Tid,Function,Arg,Func_Name));
}


/*==============================================================================*/
/* spawn_thread() : This function is a wrapper for 'pthread_create'. We exit if */
/*                  this routine fails for any reason. Probably little point in */
/*                  continuing if something this basic fails.                   */
/*                                                                              */
/* Arguments:                                                                   */
/*    pthread_t     *Tid                                                        */
/*    void         (*Function)(void *)                                          */
/*    void          *Arg                                                        */
/*    char          *Func_Name                                                  */
/*                                                                              */
/*==============================================================================*/

/*------------------------------------------------------------------------------*/
/* 11/13/2002 Razvan: Modifications for non-DCE mode:                           */
/*                      pthread_create: removed cast of Arg and recast Function */
/*                                      to fit Posix interface.                 */
/*                      pthread_attr_delete replaced with pthread_attr_destroy. */
/*                      pthread_detach: dereferenced Tid to fit Posix interface.*/
/* 03/08/2006 DYU: Put pthread_detach() back for fixing the "Out of memory" prob*/
/*                 Also replaced the Thread_Cnt++ with thread_ct_incr().        */
/*------------------------------------------------------------------------------*/

boolean_t spawn_thread( pthread_t   *Tid,                /* In - Thread Id           */
                   void       (*Function)(void *),  /* In - Function to spawn   */
                   void        *Arg,                /* In - Argument for func.  */
                   char        *Func_Name)          /* In - Function name.      */
{
  pthread_attr_t pthread_attributes;
  int status;
  int thr_type = 0;

/*  if (pthread_create(Tid, pthread_attr_default, */
  if (pthread_create(Tid, &attr,
                    (void*(*)()) Function,
                     Arg) != 0)
  {
    dtprintf(HERE, "spawn_thread: pthread_create(%s) failed: %d [%s]\n",Func_Name,strerror(status), errno,strerror(errno));
    /* Try destroying / however, this may fail as well so, be informative to users */
    pthread_attr_destroy(&pthread_attributes);
    return FALSE;
  } 

/*--------------------------------------------------------------------------------*/
/* 11/14/2002 Razvan: I don't know what's wrong with phtread_detach - it returns  */
/*                      code 1 all the time. I took it out until I find the time  */
/*                      to figure it out.                                         */
/*                    Watch carefuly for zombie threads or leaking in general!    */
/*--------------------------------------------------------------------------------*/

/* if (errno=pthread_detach(*Tid) != 0)                                           */
/*   dtprintf(HERE, "FAIL: pthread_detach() in %s failed: %d\n",Func_Name,errno); */

/*--------------------------------------------------------------------------------*/
/* 03/08/2006 dyu: phtread_detach() is required for releasing memory resource.    */
/*                 Without phtread_detach(), the process will run out of stack    */
/*                 after spawning 300 threads.  pthread_create() will be failed   */
/*                 with return code ENOMEM.                                       */
/*                 We also need to control the number of non-critical threads     */
/*                 such as queue_job().  We allow critical threads to spawn w/o   */
/*                 restriction, but for non-critical threads, please use          */
/*                 spawn_thread_managed(); it calls thread_ctrl() and which */
/*                 will block the process when max number of threads is reached   */
/*                 until the thread count reduced to below the limit.             */
/*--------------------------------------------------------------------------------*/
  status = pthread_detach(*Tid);
  if (status != 0)
  {
    status = pthread_detach(*Tid);
    /* Sometimes we may need to do it again... */
    if (status != 0)
        dtprintf(HERE, "HERE: pthread_detach(%s) failed: %s\n", Func_Name,strerror(status));
  }

  if (!strcmp(Func_Name, "queue_job"))
      thr_type = THR_QUE_JOB;

  if (!strcmp(Func_Name, "Queue_Worker"))
      thr_type = THR_STAGE;

  thread_ct_incr(thr_type);

  if (R_Log || Q_Log)
  {
    char msg1[256], msg2[64];
    sprintf(msg1, "spawn_thread: \"%s\": ++Thread(%x) Cnt %d ",Func_Name,*Tid,Thread_Cnt);
    switch (thr_type) {
    case THR_QUE_JOB: sprintf(msg2, "Q[%d / %d]", Q_Thread_Cnt, reserved_que_threads);
                      break;
    case THR_STAGE: sprintf(msg2,"S[%d / %d]", S_Thread_Cnt, reserved_staging_threads);
                      break;
    default: msg2[0]='\0';
             break;
    }
    tprintf("%s %s\n", msg1, msg2);
  }

  /* pthread_attr_destroy(&attr); */
  return TRUE;
}

/*===============================================================================*/
/* kill_thread(): This function is a wrapper for 'pthread_exit'. Makes it easier */
/*                to keep track of our thread counts if we have this wrapper.    */
/*                                                                               */
/* Arguments:                                                                    */
/*    char   *Func_Name                                                          */
/*===============================================================================*/
void kill_thread (char *Func_Name)   /* In - Function name */
{
  int thr_type = 0;
  int rtn=0;

  void *      ThreadStatus;

  if (!strcmp(Func_Name, "queue_job"))
      thr_type = THR_QUE_JOB;

  if (!strcmp(Func_Name, "Queue_Worker"))
      thr_type = THR_STAGE;

  thread_ct_decr(thr_type);

  if (R_Log || Q_Log)
  {
    tprintf("kill_thread: \"%s\": --Thread(%x) Cnt %d ", Func_Name, pthread_self(), Thread_Cnt);
    switch (thr_type) {
    case THR_QUE_JOB: printf("Q[%d / %d]\n", Q_Thread_Cnt, reserved_que_threads);
                      break;
    case THR_STAGE: printf("S[%d / %d]\n", S_Thread_Cnt, reserved_staging_threads);
                      break;
    default: printf("\n");
    }
  }

  rtn = hpss_ThreadCleanUp();  /* HPSS 7.1 always return 0, no need to check */

  pthread_exit(NULL);
}
 
/*================================================================================*/
/* get_hpss_uid_gid(): This function gets the uid and gid for the given hpss user */
/*                                                                                */
/* Arguments:                                                                     */
/*     char  *userName                                                            */
/*     int   *uid                                                                 */
/*     int   *gid                                                                 */
/*                                                                                */
/* Assumptions:                                                                   */
/*     hpss_SetLoginContext() must have already been called.                      */
/*================================================================================*/

/*------------------------------------------------------------------------------*/
/* 11/13/2002 Razvan: Modifications for non-DCE mode:                           */
/*                      No registry lookup since we don't have DCE.             */
/*                                                                              */
/*------------------------------------------------------------------------------*/

/* static sec_rgy_handle_t rgy_context;                                                              */
/*                                                                                                   */
/* int get_hpss_uid_gid(char *userName, int *uid, int *gid)                                          */
/* {                                                                                                 */
/*   sec_rgy_cursor_t             item_cursor;                                                       */
/*   sec_rgy_unix_sid_t           unix_sid;                                                          */
/*   error_status_t               dce_status;                                                        */
/*   sec_rgy_handle_t             dce_handle;                                                        */
/*   static sec_rgy_login_name_t  dce_login_name;                                                    */
/*   sec_rgy_login_name_t         tmp_login_name;                                                    */
/*   static sec_rgy_acct_user_t   user_part;                                                         */
/*   static sec_rgy_acct_admin_t  admin_part;                                                        */
/*                                                                                                   */
/*   sec_rgy_site_open("/.:", &dce_handle, &dce_status);                                             */
/*   if ( dce_status != error_status_ok )                                                            */
/*   {                                                                                               */
/*     dtprintf(HERE,"thread_utils: get_hpss_uid_gid: FAIL: sec_rgy_site_open %d\n", dce_status);    */
/*     *uid = *gid = -1;                                                                             */
/*     return(dce_status);                                                                           */
/*   }                                                                                               */
/*   strncpy((char *) (tmp_login_name.pname), userName, sizeof(tmp_login_name.pname));               */
/*                                                                                                   */
/*   (void) memset(tmp_login_name.gname, 0, sizeof(tmp_login_name.gname));                           */
/*   (void) memset(tmp_login_name.oname, 0, sizeof(tmp_login_name.oname));                           */
/*                                                                                                   */
/*   sec_rgy_acct_lookup(dce_handle,&tmp_login_name,&item_cursor,&dce_login_name,                    */
/*                                  0,&unix_sid,0,&user_part,&admin_part,&dce_status);               */
/*   if ( dce_status != error_status_ok )                                                            */
/*   {                                                                                               */
/*     dtprintf(HERE,"thread_utils: get_hpss_uid_gid: FAIL: sec_rgy_acct_lookup %d\n", dce_status);  */
/*     *uid = *gid = -1;                                                                             */
/*     return(dce_status);                                                                           */
/*   }                                                                                               */
/*   sec_rgy_cursor_reset(&item_cursor);                                                             */
/*                                                                                                   */
/*   *uid = (int) unix_sid.person;                                                                   */
/*   *gid = (int) unix_sid.group;                                                                    */
/*                                                                                                   */
/*   sec_rgy_site_close(dce_handle, &dce_status);                                                    */
/*   if ( dce_status != error_status_ok )                                                            */
/*   {                                                                                               */
/*     dtprintf(HERE,"thread_utils: get_hpss_uid_gid: FAIL: sec_rgy_site_close %d\n", dce_status);   */
/*     return(dce_status);                                                                           */
/*   }                                                                                               */
/*                                                                                                   */
/*   return(error_status_ok);                                                                        */
/*                                                                                                   */
/* }                                                                                                 */

/*===========================================================================*/
/* warn(): Alert the administrator that something bad has happened and needs */
/*         investigation.                                                    */
/*                                                                           */
/* Arguments:                                                                */
/*    char   *format                                                         */
/*    ...                                                                    */
/*===========================================================================*/

void warn( char  *format,   /* In - Format of message to print out */
           ...)             /* In - Variable arguments passed      */
{
  va_list       ap;
  struct tm     ltime;
  time_t        current_time;
  char          time_str[36], msg[1024], cmd[2048];

  /* Get the time */

  current_time = time((time_t *)NULL);
  localtime_r(&current_time, &ltime);
  sprintf(time_str, "%02d/%02d/%04d-%02d:%02d:%02d",
                    ltime.tm_mon+1,
                    ltime.tm_mday,
                    ltime.tm_year+1900,
                    ltime.tm_hour,
                    ltime.tm_min,
                    ltime.tm_sec);

  /* Place the calling message into a string */
 
  va_start(ap,format);
  vsprintf(msg,format,ap);
  va_end(ap);

  /* Use the system to execute the mailing of the message. */

  sprintf(cmd, "echo \"%s %s\" | mail -s \"Queue Server Alert\" %s",
                time_str, msg, Config.admin_email);
/*  system(cmd); */

  return;
}

/*======================================================================*/
/* notify(): Alert the submitter that the job has finished (or failed)  */
/*                                                                      */
/* Arguments:                                                           */
/*    char   *email                                                     */
/*    char   *format                                                    */
/*    ...                                                               */
/*======================================================================*/

void notify(char *email,    /* In - email address of submitter      */
            char *format,   /* In - Format of message to print out  */
            ...)            /* In - Variable arguments passed       */
{
  va_list     ap;
  struct tm   ltime;
  time_t      current_time;
  char        time_str[36];
  char        msg[1024];
  char        cmd[2048];

  /* Get current time */
  current_time = time((time_t *)NULL);
  localtime_r(&current_time, &ltime);
  sprintf(time_str, "%02d/%02d/%04d-%02d:%02d:%02d\n",
                    ltime.tm_mon+1,
                    ltime.tm_mday,
                    ltime.tm_year+1900,
                    ltime.tm_hour,
                    ltime.tm_min,
                    ltime.tm_sec);

  /* Place calling message into a string */

  va_start(ap,format);
  vsprintf(msg,format,ap);
  va_end(ap);

  /* Now build and send the message to the submitter */

  sprintf(cmd, "echo \"%s%s\" | mail -s \"Queue Server Notification\" %s",
                time_str, msg, email);
/*  system(cmd);  */
  return;
}

/*=========================================================================*/
/*  read_config() : Read the configuration files into the config structure */
/*                                                                         */
/*  Externals:                                                             */
/*      config_t        Config                                             */
/*      int             errno                                              */
/*=========================================================================*/
 
void read_config()
{
  FILE    *config_fp;
  char    *config_file;
  int      rc;

  config_file = getenv("HPSS_BATCH_CONFIG");
  
  if (config_file == (char *)NULL)
  {
    config_file = DEFAULT_CONFIG_PATH;
  }

  if ((config_fp = fopen(config_file,"r")) == (FILE *)NULL)
  {
    dtprintf(HERE, "ERROR: fopen(%s) failed: %d\n", config_file, errno);
    exit(1);
  }
/*
  printf ("Config.admin_email   = %s\n", Config.admin_email);
  printf ("Config.principal     = %s\n", Config.principal);
  printf ("Config.keytab        = %s\n", Config.keytab);
  printf ("Config.offline_table = %s\n", Config.offline_table);
  printf ("Config.input_dir     = %s\n", Config.input_dir);
  printf ("Config.working_dir   = %s\n", Config.working_dir);
  printf ("Config.output_dir    = %s\n", Config.output_dir);
  printf ("Config.bad_dir       = %s\n", Config.bad_dir);
*/
  /* all blanks */

  rc  = fscanf(config_fp, "%s", Config.admin_email);
  /* Now, rc = 1, Config.admin_email   = gtsai@bnl.gov                                              */                    
  rc += fscanf(config_fp, "%s", Config.principal);
  /* Now, rc = 2, Config.principal     = hpss_ftp                                                   */

  rc += fscanf(config_fp, "%s", Config.keytab);
  /* Now, rc = 3, Config.keytab        = /krb5/hpss.keytabs                                         */                                                                     
  rc += fscanf(config_fp, "%s", Config.offline_table);
  /* Now, rc = 4, Config.offline_table = /home/grace/Batch/batch.pthreads/config/offline_table */

  rc += fscanf(config_fp, "%s", Config.input_dir);
  /* Now, rc = 5, Config.input_dir     = /home/grace/Batch/batch.pthreads/input                */

  rc += fscanf(config_fp, "%s", Config.working_dir);
  /* Now, rc = 6, Config.working_dir   = /home/grace/Batch/batch.pthreads/working              */

  rc += fscanf(config_fp, "%s", Config.output_dir);
  /* Now, rc = 7, Config.output_dir    = /home/grace/Batch/batch.pthreads/output               */

  rc += fscanf(config_fp, "%s", Config.bad_dir);
  /* Now, rc = 8, Config.bad_dir       = /home/grace/Batch/batch.pthreads/bad                  */

  rc += fscanf(config_fp, "%s", Config.transfer_script);

  if (rc != 9)
  {
    dtprintf(HERE, "ERROR: Bad configuration format \n");
    exit(1);
  }

  fclose(config_fp);
  return;
}

/*========================================================================*/
/* check_config() : Check accessability of the configurations directories */
/*                                                                        */
/* Externals:                                                             */
/*   config_t  Config                                                     */
/*========================================================================*/

void check_config()
{
  if (access(Config.input_dir,   R_OK | W_OK | X_OK) ||
      access(Config.working_dir, R_OK | W_OK | X_OK) ||
      access(Config.output_dir,  R_OK | W_OK | X_OK) ||
      access(Config.bad_dir,     R_OK | W_OK | X_OK))
  {
    dtprintf(HERE, "ERROR: Invalid permissions on directories\n");
    exit(1);
  }
  
  return;
}
