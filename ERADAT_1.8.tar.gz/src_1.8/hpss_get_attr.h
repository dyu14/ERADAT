#ifndef HPSS_GET_ATTR__H
#define HPSS_GET_ATTR__H

#include "hpssget.h"

#define HPSS_PERM_READ  32
#define HPSS_PERM_WRITE 64
#define HPSS_PERM_EXEC  128

#define MAX_VOL_NAME_LEN 15  /* actual length 12 */
#define VOL_NAME_LEN  6

#define MAX_RETRY    5
#define RETRY_PERIOD 1
#define DEF_CORE_SERVER "hpsscore.rcf.bnl.gov"

/*   Global Variables    */ 
extern int registed_client;
extern int R_Log;
extern int debug;

typedef struct fstruct
{
  char *filename;             /* Name of HPSS file              */
  unsigned32 User_Perms;
  unsigned32 Group_Perms;
  unsigned32 Other_Perms;
  char ftype;
  unsigned32 uid;
  unsigned32 gid;
  timestamp_sec_t atime;
  timestamp_sec_t ctime;
  timestamp_sec_t mtime;
//  unsigned long size;
  double size;
  char size_str[DEC64_LEN+1];
  char volnum[5][MAX_VOL_NAME_LEN];
  int chkbadtape;
  int feature;
  int storagelevel;
  cos_t cos_id;
} fstruct_t;

extern int hpss_GetStorageLevel_Etc( char    *Filename,
                                     hpssoid_t  *BitFile_Id,
                                     u_signed64 *Length,
                                     hpssoid_t  *VVID,
                                     signed32   *Position,
                                     unsigned32 *File_Type, 
                                     unsigned32 *Composite_Perms, 
                                     signed32   *Storage_Level,
                                     cos_t   *Cos_Id,
                                     char   *Vol_Name
                                     );

config_t Config;     /* Master configuration                         */
char localhost[128];
char *progname;
char imp_user[64];

int local_dbutils_connect();
int  local_dbutils_init();
int chk_tape_stat(char *tapid);
void print_timestamp_sec (timestamp_sec_t data);
void local_dbutils_unreg();

int show_file_attr(fstruct_t *hpss_fs);
int hpss_login();
void local_dbutils_unreg();

#endif
