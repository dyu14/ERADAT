#ifndef  _COMMON_H_
#define  _COMMON_H_

#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>


typedef int boolean_t;
 
/* 11/13/2002 Razvan: non-DCE mode: Not sure where these attributes were supposed
                                   to be defined.                                 */
#define pthread_mutexattr_default  NULL
#define pthread_attr_default       NULL

#define _D_NAME_MAX 255         /* Razvan: add dir name max number of char def */

#define DEFAULT_CONFIG_PATH   "/home/latest/Batch/config/config_file"
#define EMAIL_LEN             256     /* Length of an email id+host */
#define USER_LEN              32      /* Length of user id          */
 
typedef struct config
{
  char  admin_email[EMAIL_LEN+1];         /* Email for admin      */
  char  principal[USER_LEN+1];            /* Name for server      */
  char  keytab[MAXPATHLEN];               /* Path to keytab file  */
  char  offline_table[MAXPATHLEN];        /* Offline table file   */
  char  input_dir[MAXPATHLEN];            /* Input dir jobs       */
  char  working_dir[MAXPATHLEN];          /* Working dir for jobs */
  char  bad_dir[MAXPATHLEN];              /* Where bad files go   */
  char  output_dir[MAXPATHLEN];           /* Output dir for jobs  */
  char  transfer_script[MAXPATHLEN];      /* External data transfer script  */
} config_t;
 
#endif    /* _COMMON_H_ */
