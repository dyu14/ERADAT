#include  <stdio.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <errno.h>
#include  <string.h>
#include  <sys/param.h>
#include  <time.h>
#include  <pwd.h>
#include  <userpw.h>

#include  <dce/sec_login.h>
#include  "nothread_utils.h"

/* Pre-declare all functions in this file */

void   usage();
void   main(int, char **);
char  *get_local_user();
char  *get_hpss_user();
char  *get_email();

/*==============================================================*/
/* usage() : Show user what arguments to use with this program  */
/*==============================================================*/

void usage()
{
  printf("Usage: submit <file-list> <output-file>\n");
  exit(1);
}
 
/*===========================================================================*/
/* main() : Entry point for this program. Process user inputs and initialize */
/*          the data structures used to control jobs. Kick off some threads  */
/*          to process incoming jobs and then keep statistics of activity.   */
/*                                                                           */
/* Arguments:                                                                */
/*     int    argc    - Number of arguments                                  */
/*     char  *argv[]  - Array  of arguments                                  */
/*                                                                           */
/* Externals:                                                                */
/*     int    errno - System error values                                    */
/*                                                                           */
/* Assumptions:                                                              */
/*     init_utils() must be called before using the "tprintf" function.      */
/*===========================================================================*/

void main( int argc, char *argv[])
{
  int          c;
  int          rc;
  int          i;
  char        *local_username;
  char        *hpss_username;
  char        *email_addr;
  char        *request_file;
  char        *output_file;
  extern int   opterr, optind;
  extern char *optarg;
 
  local_username = hpss_username = email_addr = (char *)NULL;

  /* Go process the user arguments */

  while ((c = getopt(argc, argv, "H:E:h")) != EOF)
  {
    switch (c)
    {
      case 'h':
        usage();
        break;
      default:
        printf("Unknown option \"%c\"...\n\n", c);
        usage();
    }
  }

  if (optind != (argc - 2)) usage();
  request_file = argv[optind];
  output_file  = argv[optind+1];       
 
  /* Read in the configuration file */
  submit_read_config();
 
  /* Now check identity and authentication */
  local_username = get_local_user();
  hpss_username  = get_hpss_user();
  email_addr     = get_email();

  /* Build and ship the list */
  submit_file(local_username,hpss_username,email_addr,request_file,output_file);
  printf("Successfully submitted job(%s)\n",request_file);
  return;
}
 
/*======================================================================*/
/* get_local_user() : Get the local user name.                          */
/*======================================================================*/

char * get_local_user()
{
  struct passwd   *pwd;
  struct userpw   *user_pw;
  char            *username;
  char            *password;
  char             user[USER_LEN+3];
  char            *ptr;
  char            *xpasswd;
  char            *salt;

  printf("Please enter your local user name: ");
  fflush(stdout);

  if (fgets(user,sizeof(user),stdin) == (char *)NULL)
  {
    fprintf(stderr,"Sorry, bad input\n");
    exit(1);
  }

  ptr = strchr(user,'\n');
/*
printf("submit: get_local_user: after fgets, user = %s\n", user);
*/
 
  if (ptr)
    *ptr = '\0';

  password = getpass("Password: ");
/*
printf("submit: get_local_user: after getpass,  password = %s\n", password);
*/

  if (password == (char *)NULL)
  {
    fprintf(stderr, "Sorry, NULL passwd\n");
    exit(1);
  }

  pwd = getpwnam(user);
/*
printf("submit: get_local_user: after getpwname, pwd = %s\n", pwd);
*/

  if (pwd == (struct passwd *)NULL)
  {
    fprintf(stderr, "Unable to find user(%s) in security database\n", user);
    exit(1);
  }

  username = (char *)malloc(strlen(pwd->pw_name)+1);
/*
printf("submit: get_local_user: after malloc, username = %s\n", username);
*/

  if (username == (char *)NULL)
  {
    fprintf(stderr,"Malloc failed with: %d\n",errno);
    exit(1);
  }

  strcpy(username,pwd->pw_name);
/*
printf("submit: get_local_user: after strcpy, username = %s\n", username);
*/

  user_pw = getuserpw(username);
/*
printf("submit: get_local_user: after getuserpw, user_pw = %s\n", user_pw);
*/

  if (user_pw == (struct userpw *)NULL)
  {
    fprintf(stderr,"Unable to get password for user(%s)\n",username);
    exit(1);
  }
 
  salt = user_pw->upw_passwd;
  xpasswd = crypt(password,salt);

  if (strcmp(xpasswd, user_pw->upw_passwd))
  {
    fprintf(stderr,"Authentication denied for user(%s)\n",username);
    exit(1);
  }

  if (strcmp(user_pw->upw_name, username))
  {
    fprintf(stderr,"Strange,username dont match. Contact system administrator\n");
    exit(1);
  }

  return(username);
}

/*================================================================================*/
/* get_hpss_user() : Get & check the HPSS user name.                              */
/*================================================================================*/

char * get_hpss_user()
{
  char                     *username;
  char                     *password;
  char                      principal[MAXPATHLEN+3];
  char                     *ptr;
 
  sec_login_handle_t        login_context;
  sec_login_handle_t        init_context;
  sec_passwd_str_t          dce_password;
  sec_passwd_rec_t          dce_password_rec;
  sec_login_passwd_t        pw_entry;
  sec_login_auth_src_t      auth_src;

  error_status_t            status;
  boolean32                 reset_password;
  struct passwd            *pw_ptr;
 
  printf("Please enter HPSS user/DCE principal name: ");
  fflush(stdout);

  if (fgets(principal,sizeof(principal),stdin) == (char *)NULL)
  {
    fprintf(stderr,"Sorry, bad input\n");
    exit(1);
  }
 
  ptr = strchr(principal,'\n');

  if (ptr)
    *ptr = '\0';

  password = getpass("Password: ");

  if (password == (char *)NULL)
  {
    fprintf(stderr,"Sorry, NULL passwd\n");
    exit(1);
  }

  sec_login_init_first(&status);

  if (status != error_status_ok)
  {
    fprintf(stderr,"Setup first failed: %s\n", dce_msg_get(status));
    exit(1);
  }
 
  sec_login_setup_identity((unsigned_char_p_t) principal,
                           sec_login_no_flags,
                           &login_context,
                           &status);

  if (status != error_status_ok)
  {
    fprintf(stderr,"Unable to identify user(%s) with DCE: %s\n", principal, dce_msg_get(status));
    exit(1);
  }

  strncpy((char *)dce_password,(char *)password,sec_passwd_str_max_len);
  dce_password[sec_passwd_str_max_len] = '\0';
 
  dce_password_rec.version_number         = sec_passwd_c_version_none;
  dce_password_rec.pepper                 = NULL;
  dce_password_rec.key.key_type           = sec_passwd_plain;
  dce_password_rec.key.tagged_union.plain = &(dce_password[0]);
 
  if (sec_login_validate_identity(login_context,
                                  &dce_password_rec,
                                  &reset_password,
                                  &auth_src,
                                  &status)
     )
  {
    if (!sec_login_certify_identity(login_context,&status))
    {
      fprintf(stderr,"Apparently talked to an unknown security server, better check with DCE administrator: %s\n",
                     dce_msg_get(status));
      sec_login_purge_context(&login_context,&status);
      exit(1);
    }

    sec_login_set_context(login_context, &status);
    sec_login_get_pwent(login_context, &pw_entry, &status);
    pw_ptr   = (struct passwd *)pw_entry;
    username = (char *)malloc(strlen(pw_ptr->pw_name)+1);

    if (username == (char *)NULL)
    {
      fprintf(stderr, "Malloc failed with: %d\n", errno);
      exit(1);
    }

    strcpy(username, pw_ptr->pw_name);
  }
  else
  {
    fprintf(stderr, "Unable to validate identity for user(%s): %s\n",principal,dce_msg_get(status));
    sec_login_purge_context(&login_context, &status);
    exit(1);
  }

  sec_login_purge_context(&login_context, &status);
  return(username);
}

/*====================================================================*/
/* get_email(): Get the user's email address                          */
/*====================================================================*/

char * get_email()
{ 
  char *email;
  char *ptr;
  char  input[EMAIL_LEN + 3];

  printf("Please enter your email address: ");
  fflush(stdout);

  if (fgets(input, sizeof(input), stdin) == (char *)NULL)
  {
    fprintf(stderr, "Sorry, must have email address\n");
    exit(1);
  }

  ptr = strchr(input, '\n');

  if (ptr)
    *ptr = '\0';

  if (strlen(input) > EMAIL_LEN)
  {
    fprintf(stderr, "Sorry, email must be less than %d bytes long\n",EMAIL_LEN);
    exit(1);
  }

  email = (char *)malloc(strlen(input)+1);

  if (email == (char *)NULL)
  {
    fprintf(stderr, "Malloc failed with: %d\n", errno);
    exit(1);
  }

  strcpy(email, input);
  return(email);
}

