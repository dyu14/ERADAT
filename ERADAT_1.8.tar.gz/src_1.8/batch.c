#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <sys/param.h>
#include <time.h>
#include <pwd.h>
#include <sys/stat.h>

#include "u_signed64.h"
#include "hpss_api.h"
#include "hpss_queue.h"
#include "common.h"
#include "batch.h"
#include "thread_utils.h"
#include "batch_utils.h"
#include "hpss_batch_error.h"

/*   Global Variables    */                                                                    

int exit_status;
job_queue_t      Job_Master;                /* Master of the job queues                     */
config_t         Config;                    /* Master configuration                         */
pthread_mutex_t  Copies_Lock;               /* Protects Copies_In_Progress                  */
int              Copies_In_Progress = 0;    /* Keep # of copy_file threads                  */
pthread_mutex_t  Update_Lock;               /* Protects updating working output directories */
pthread_mutex_t  Buffer_Lock;               /* Protects transfer buffer                     */
boolean_t        Buffer_Usage[MAX_COPIES];  /* Flags for used storage                       */
char            *Buffer[MAX_COPIES];        /* Array of buffer areas                        */
int              R_Log = FALSE;             /* Flag for local logging                       */
struct timespec  Input_Interval  = INPUT_INTERVAL;
struct timespec  Work_Interval   = WORK_INTERVAL;
struct timespec  NoWork_Interval = NOWORK_INTERVAL;
struct timespec  Update_Interval = UPDATE_INTERVAL;
#define MAX_OPT_TOKENS 2

int stage_opt = 0;

char replay_file = 'R';

void init_debug_val();

/*******************************************************************/
/*                         usage()                                 */
/*******************************************************************/

void usage()
{
  printf("Usage: hpss_batch [ -r -q ]\n");
  exit(1);
}

int batch_make_client(int interval)
{ 
    int status;
    pthread_t tid;
    
    status = bu_init();
    if (status == P_SUCCESS) {
        init_debug_val();
        batch_str.pull_interval = interval;
        spawn_thread(&tid, bu_puller, NULL, "bu_puller");
    } 
    return status;
}    


/**************************************************************************************/
/* main()                                                                             */
/*                                                                                    */
/* Purpose:                                                                           */
/*   Entry point for this program. Process user inputs and initialize the data        */
/*   structures used to control jobs. Kick off some threads to process incoming jobs  */
/*   and then keep statistics of activity.                                            */
/*                                                                                    */
/* Arguments:                                                                         */
/*    int    argc   - Number of arguments                                             */
/*    char  *argv[] - Array of arguments                                              */
/*                                                                                    */
/* Global variables:                                                                  */
/*    int    errno  - System error values                                             */
/*    int    Q_Log  - Flag for queue logging                                          */
/*    int    R_Log  - Flag for request logging                                        */
/**************************************************************************************/
 
int main (int argc, char *argv[])
{
  int     c;
  int     i;
  int     num_queues;
  int     num_requests;
  int     poll_time;
  int     rc;
  char ktpath[HPSS_MAX_PATH_NAME];
  char auth_type[16]="unix";
  hpss_authn_mech_t mech_type = hpss_authn_mech_krb5;
  api_config_t      api_config;
  char	  *hpss_home;
  char    *imp_key;
  char    *imp_user;
 
  pthread_t     throwaway_tid;
  extern int    opterr;
  extern int    optind;
  extern char  *optarg;

  hpss_home = (char *)getenv("HPSS_HOME");
  if ( ! hpss_home ) {
      printf("Environment variable HPSS_HOME is not set\n");
      exit(1);
  }

  num_queues   = NUM_QUEUES;
  num_requests = NUM_REQUESTS;
  poll_time    = POLL_TIME;

  /* Must initialize the utils functions. Used to protect logging in the */
  /* threaded environment. Read in the configuration file.               */

  init_utils();
  read_config();
  check_config();
 
  batch_make_client(DEFAULT_UPDATE_INTERVAL);

  rc = hpss_AuthnMechTypeFromString(auth_type, &mech_type);
  if(rc != 0) {
    dtprintf(HERE, "ERROR: hpss_AuthnMechTypeFromString() failed: %d\n", rc);
    dtprintf(HERE, "invalid authentication type %s\n",auth_type);
    exit(rc);
  }

  rc = hpss_GetConfiguration(&api_config);
  if(rc != 0) {
    dtprintf(HERE, "ERROR: hpss_GetConfiguration() failed: %d\n", rc);
    bu_terminate();
    exit( rc );
  }

  api_config.AuthnMech = mech_type;
  api_config.Flags |= API_USE_CONFIG;

  rc = hpss_SetConfiguration(&api_config);
  if(rc != 0) {
    dtprintf(HERE, "ERROR: hpss_SetConfiguration() failed: %d\n", rc);
    bu_terminate();
    exit( rc );
  }

  imp_key = (char *)getenv("HPSS_KEYTAB");
  if ( imp_key ) {
      printf("Using Environment Variable: HPSS_KEYTAB: %s\n", imp_key);
      strcpy(ktpath, imp_key);
  } else {
      sprintf(ktpath, "%s/config/keytabs/%s.unix.keytab", hpss_home, client_str.user);
      printf("HPSS_KEYTAB Not found, using default keytab: %s\n", ktpath);
  }
  imp_user = client_str.user;

  printf("User: %s\n", client_str.user);
  printf("Impersonating %s\n", client_str.user);
  printf("Loading keytab: %s\n", ktpath);

  rc = hpss_SetLoginCred(client_str.user,
                         mech_type,
                         hpss_rpc_cred_client,
                         hpss_rpc_auth_type_keytab,
                         ktpath);
  if (rc != 0)
  {
    dtprintf(HERE, "ERROR: hpss_SetLoginCred() failed: %d\n", rc);
    bu_terminate();
    exit(1);
  }
   sleep(1);
 
  /* Initialize the queuing code. The default window can be overridden */

  /* hpss_QueueInit is in hpss_queue.c          */

  if ((rc = hpss_QueueInit(poll_time)) < 0)
  {
    dtprintf(HERE,"ERROR: hpss_QueueInit() failed: %d\n", rc);
    exit(1);
  }
 
  /* Setup locks used to protect the job queue data structure and other */
  /* critical pieces of code.                                           */

  init_lock(&Copies_Lock);
  init_lock(&Update_Lock);
  init_lock(&Job_Master.lock);
  
  Job_Master.num_jobs = 0;

  Job_Master.head = (job_t *)NULL;
  Job_Master.tail = (job_t *)NULL;

  /* Initialize our buffer pool. Helps keep down on hammering malloc. */
  
  init_lock(&Buffer_Lock);

  for (i=0; i<MAX_COPIES; i++)
  {
    Buffer_Usage[i] = FALSE;

    if ((Buffer[i] = (char *)malloc(BUFSIZE)) == (char *)NULL)
    {
      dtprintf(HERE,"ERROR: Unable to allocate memory for buffers[%d], %d bites, error = %d\n", i, BUFSIZE, errno);
      exit(1);
    }
  }
 
  /* Go load up any jobs left over from the previous run. Then create a thread to */
  /* look at the input directory and update the working jobs.                     */

  tprintf("Cancelling previous incompleted requests\n");
  bu_cancel_old_requests();

  tprintf("Requeueing previous incompleted requests\n");

  replay_working();

  replay_file = '\0';
  tprintf("Ready\n");

  if ( spawn_thread(&throwaway_tid, get_new_work,    NULL, "get_new_work") &&
       spawn_thread(&throwaway_tid, update_progress, NULL, "update_progress") &&
       spawn_thread(&throwaway_tid, PurgeLockMonitor, NULL, "PurgeLockMonitor"))  {
 
  /* The big loop is in do_work. For now there is no graceful shutdown so we never */
  /* exit out of do_work()                                                         */
   
      do_work();
   }


   if (R_Log || Q_Log) tprintf("Waiting for file transfer to be completed (do_copy)\n");

   if (R_Log || Q_Log)
       tprintf("R:\tShutdown completed\n");

   if (exit_status == -1) {
       exit(0);
   } else {
       exit(1);
   }
}
 
/*=================================================================================*/
/* replay_working() : Go look at the working directory for any jobs left from the  */
/*                    last time we ran this utility.                               */
/*                                                                                 */
/* Externals:                                                                      */
/*     config_t   Config                                                           */
/*                                                                                 */
/* Assumptions:                                                                    */
/*     The working directory and files within are valid                            */
/*=================================================================================*/

void replay_working()
{
  DIR            *dir_ptr;
  struct dirent  *entry;
  char            filename[MAXPATHLEN];
  job_t          *job_ptr;
  pthread_t       tid;
  
  /* Open the working directory */
  if ((dir_ptr = opendir(Config.working_dir)) == (DIR *)NULL)
  {
    dtprintf(HERE,"ERROR: cannot open working directory: %d\n", errno);
    exit(1);
  }
 
  /* Start reading entries. Skip anything with a leading ".", this includes */
  /* ".", "..", and anything else we or the user puts in that is hidden.    */

  while ((entry = readdir(dir_ptr)) != (struct dirent *)NULL)
  {
    if (entry->d_name[0] == '.')
      continue;

    /* Test to see if our file is good or not. Test 1 is access, test 2 is */
    /* its contents.                                                       */

    sprintf(filename, "%s/%s", Config.working_dir, entry->d_name);

    if (access(filename, R_OK | W_OK))
    {
      tprintf("batch: replay_working: WARNING: Access invalid to (%s), skipping\n", filename);
      move_bad_file(filename, entry->d_name);
    }
    else
    {
      job_ptr = process_file(filename,entry->d_name,FALSE);

      if (job_ptr)
      {
        insert_job(job_ptr);
         if ( ! spawn_thread_managed(&tid,queue_job,job_ptr,"queue_job") ){
            remove_job(job_ptr);
         }
      }
      else
      {
        move_bad_file(filename,entry->d_name);
      }
    }
  }

  closedir(dir_ptr);
  return;
}
 
/*==================================================================================*/
/* move_bad_file(): Something is wrong with this file. Move it from the input or    */
/*                  working directory to the bad dir. Then notify the administrator */
/*                                                                                  */
/* Arguments:                                                                       */
/*     char    *from_name                                                           */
/*     char    *partial_name                                                        */
/*                                                                                  */
/* Externals:                                                                       */
/*     config_t  Config                                                             */
/*                                                                                  */
/* Assumptions:                                                                     */
/*     The names is null terminated.                                                */
/*==================================================================================*/

void move_bad_file( char *from_name,     /* In - Name of file to move   */
                    char *partial_name)  /* In - Last segment of name   */
{
  char  to_name[MAXPATHLEN];

  sprintf(to_name,"%s/%s",Config.bad_dir,partial_name);
  rename(from_name,to_name);
  warn("WARNING: Problem with file format or access: %s\n", from_name);
  return;
}

/*================================================================================*/
/* process_file() : Read the contents of the given file. This can read both new   */
/*                  and existing working files. The information is loaded into a  */
/*                  job request list.                                             */
/*                                                                                */
/* Arguments:                                                                     */
/*     char       *filename                                                       */
/*     char       *job_id                                                         */
/*     boolean_t   new                                                            */
/*                                                                                */
/* Externals:                                                                     */
/*     int         R_Log                                                          */
/*                                                                                */
/* Return Values:                                                                 */
/*     Pointer to job structure is good, otherwise NULL is returned.              */
/*                                                                                */
/* Assumptions:                                                                   */
/*     The name is null terminated                                                */
/*================================================================================*/

job_t * process_file(char        *filename,   /* In - Name of job file    */
                     char        *job_id,     /* In - Numeric of the job  */
                     boolean_t    new)        /* In - TRUE if file is new */
{
  FILE           *fp_input;
  int             i,j;
  int             line_cnt;
  int             rc;
  char            hpss_file_name[MAXPATHLEN];
  char            destination_file_name[MAXPATHLEN];
  char            buffer[4096];
  char            email[EMAIL_LEN+1];
  char            output_file[MAXPATHLEN+1];
  char            local_id_str[USER_LEN+1];
  char            hpss_id_str[USER_LEN+1];
  int             local_uid;
  int             local_gid;
  int             hpss_uid;
  int             hpss_gid;
  job_t          *job_ptr;
  request_t      *req_ptr;
  struct passwd   pwd;
  struct passwd  *pwd_ptr;
  char            tmp_str[MAX_OPT_TOKENS][256];
  char            pri_str[10];
 
  /* Open up the file. This should always work since we already tested for */
  /* access. If it fails then something is really wrong and we exit.       */

  if (R_Log)
    tprintf("R: Starting to process file(%s)\n",filename);

  if ((fp_input = fopen(filename,"r")) == (FILE *)NULL)
  {
    dtprintf(HERE,"ERROR: fopen(%s) failed: %d\n", filename, errno);
    exit(1);
  }

  /* Figure out how many requests are in the file. Must remember that the */
  /* first line is the email address, etc... of the requester.            */

  line_cnt = -1;

  while (fgets(buffer,sizeof(buffer),fp_input))
    line_cnt++;

  clearerr(fp_input);
  rewind(fp_input);
 
  /* Now load up the email address, hpss user name, and local user name of */
  /* the submitter.                                                        */

  if ((fscanf(fp_input, "%s %s %s %s", email, hpss_id_str, local_id_str, output_file) != 4)
      ||
      (line_cnt < 1)
     )
  {
    tprintf("ERROR: Job file (%s) is invalid, skipping\n", filename);
    fclose(fp_input);
    return((job_t *)NULL);
  }
 
  /* Initialize our job request list. Failures are handled within. */
 
  if (getpwnam_r(local_id_str,&pwd,buffer,sizeof(buffer),&pwd_ptr) < 0)
  {
    tprintf("ERROR: User(%s) could not be looked up: error = %d\n", local_id_str, errno);
    fclose(fp_input);
    return((job_t *)NULL);
  }

  job_ptr = create_job(job_id,line_cnt);
  job_ptr->warned = FALSE;

  strcpy(job_ptr->notify_email, email);
  strcpy(job_ptr->local_id_str, local_id_str);
  strcpy(job_ptr->hpss_id_str,  hpss_id_str);
  strcpy(job_ptr->output_file,  output_file);
 
  job_ptr->local_uid = pwd.pw_uid;
  job_ptr->local_gid = pwd.pw_gid;

  job_ptr->hpss_uid  = 0;
  job_ptr->hpss_gid  = 0; 

  /* Loop for each request line. */
 
  fgets(buffer,sizeof(buffer),fp_input); /* Let it skip the EOL */
  for (i=0; i<line_cnt; i++)
  {
    req_ptr = &(job_ptr->request_list[i]);

    /* New file, format is just two columns. The first is the HPSS name, */
    /* the second is that of the local file.                             */

    memset(buffer, ' ', sizeof(buffer));
    for (j = 0; j < MAX_OPT_TOKENS; j++) {
        tmp_str[j][0] = '\0';
    }

    if (new)
    {
      if (fgets(buffer,sizeof(buffer),fp_input))
          rc = sscanf(buffer, "%s %s %s %s", hpss_file_name, destination_file_name, tmp_str[0], tmp_str[1]);
      req_ptr->state      = NEW;
      req_ptr->tries      = 0;
      req_ptr->error_code = 0;
    }
    else
    {
      /* Existing file, format is same as above except we have state information */
      /* so we dont hvae to completely start over.                               */
      if (fgets(buffer,sizeof(buffer),fp_input))
          rc = sscanf(buffer, "%s %s %d %d %d %s %s",
                            hpss_file_name,
                            destination_file_name,
                            &req_ptr->state,
                            &req_ptr->tries,
                            &req_ptr->error_code,
                            tmp_str[0],
                            tmp_str[1]);

      /* If the state of the file is anyting other than copied completely or   */
      /* total failure, then just restart everything over again. Files already */
      /* staged will get copied off farely quickly anyway.                     */
 
      if ((req_ptr->state == COPIED || req_ptr->state == FAILED))
      {
        if (req_ptr->state == FAILED)
          job_ptr->num_failed++;

        job_ptr->num_processed++;
      }
      else
      {
        req_ptr->state = NEW;
      }
    }

    req_ptr->hpss_file_name        = strdup(hpss_file_name);
    req_ptr->destination_file_name = strdup(destination_file_name);
    req_ptr->priority = PRIORITY_LOW;
    req_ptr->exp_minute        = 0;
    req_ptr->exp_time          = 0;

    pri_str[0]='\0';
    for (j = 0; j < MAX_OPT_TOKENS; j++) {
        if (strlen(tmp_str[j]) && (*tmp_str[j] == 'T') ) {
            dtprintf(HERE,"Filename: %s, found TIMEDOUT token:%s\n", req_ptr->hpss_file_name, tmp_str[j]);
            req_ptr->exp_minute = atoi(tmp_str[j]+1);
            req_ptr->exp_time          = 0;
        }

        if (strlen(tmp_str[j]) && (tmp_str[j][0] == 'P') ) {
            dtprintf(HERE,"Filename: %s, found PRIORITY token:%s\n", req_ptr->hpss_file_name, tmp_str[j]);
            if (toupper(tmp_str[j][1]) == 'H') {
                req_ptr->priority = PRIORITY_HIGH;
                strcpy(pri_str, tmp_str[j]+1);
            }
        }
    }
    dtprintf(HERE,"Filename: %s, exp_minute:%d, exp_time=%ld, priority=%s, rc=%d\n", req_ptr->hpss_file_name, req_ptr->exp_minute, req_ptr->exp_time, pri_str, rc);
 
    if ((req_ptr->hpss_file_name        == (char *)NULL)  ||
        (req_ptr->destination_file_name == (char *)NULL)
       )
    {
      dtprintf(HERE,"Error: Out of memory: %d\n",errno);
      exit(1);
    }
 
    req_ptr->job_ptr = job_ptr;

    /* Try to make sure the format is sane. If not, we throw this file out. */
   
    if ((new && (rc != 2 && rc != 3)) || (!new && (rc != 5 && rc != 6)))
    {
      dtprintf(HERE,"Job(%s) failed, format error on line %d\n", job_id, i+1);
      notify(job_ptr->notify_email, "Job(%s) failed, format error on line %d\n", job_id, i+1);
      /* notify("gtsai@bnl.gov","Job(%s) failed, format error on line %d\n", job_id, i+1); */
      fclose(fp_input);
      delete_job(job_ptr);
      return((job_t *)NULL);
    } 
  }
 
  fclose(fp_input);
  
  if (R_Log)
    tprintf("R: Job(%s) Started\n", job_id);
   
  return(job_ptr);
}

/*================================================================*/
/* create_job() : This function initializes a job request list.   */
/*                                                                */
/* Arguments:                                                     */
/*    char    *job_id                                             */
/*    int      line_cnt                                           */
/*                                                                */
/* Return Values:                                                 */
/*    Pointer to job structure.                                   */
/*================================================================*/

job_t * create_job(char   *job_id,    /* In - Job id number           */
                   int     line_cnt)  /* In - Number of request lines */
{
  job_t  *new_job;

  /* Allocate space for job structure. We bomb if the memory isnt */
  /* available.                                                   */

  new_job = (job_t *)malloc(sizeof(job_t));

  if (new_job == (job_t *)NULL)
  {
    dtprintf(HERE,"ERROR: Unable to create job, malloc failed: %d\n",errno);
    exit(1);
  }

  /* Fill in the blank. */
  
  strcpy(new_job->job_id,job_id);
  new_job->start_time    = time((time_t *)NULL);
  new_job->num_requests  = line_cnt;
  new_job->num_processed = 0;
  new_job->num_failed    = 0;
  new_job->bytes_moved   = cast64m(0);

  /* Need more memory for the request list itself. */

  new_job->request_list = (request_t *)malloc(sizeof(request_t) * line_cnt);

  if (new_job->request_list == (request_t *)NULL)
  {
    dtprintf(HERE,"ERROR: Unable to create job, malloc failed: %d\n",errno);
    exit(1);
  }

  return(new_job);
}
 
/*================================================================*/
/* insert_job() : This function inserts a job into the job queue. */
/*                                                                */
/* Arguments:                                                     */
/*    job_t    *job_ptr                                           */
/*                                                                */
/* Externals:                                                     */
/*    job_queue_t  Job_Master                                     */
/*================================================================*/

void insert_job (job_t *job_ptr)
{
  /* Critical code, place the new job in the queue of jobs. */
  /* New job is always placed at end of the list.           */

  lock(&Job_Master.lock);
  job_ptr->next = (job_t *)NULL;
  job_ptr->prev = Job_Master.tail;

  if (Job_Master.num_jobs == 0)
    Job_Master.head = job_ptr;
  else
    Job_Master.tail->next = job_ptr;

  Job_Master.tail = job_ptr;
  Job_Master.num_jobs++;
  unlock(&Job_Master.lock); 

  return;
}
 
/*====================================================================*/
/* remove_job() : This function takes a job out of the job queue.     */
/*                                                                    */
/* Arguments:                                                         */
/*    job_t  *job_ptr                                                 */
/*                                                                    */
/* Externals:                                                         */
/*    job_queue_t  Job_Master                                         */
/*====================================================================*/

void remove_job(job_t *job_ptr)
{
  lock(&Job_Master.lock);

  if (job_ptr->next)
    job_ptr->next->prev = job_ptr->prev;
  else
    Job_Master.tail = job_ptr->prev;

  if (job_ptr->prev)
    job_ptr->prev->next = job_ptr->next;
  else
    Job_Master.head = job_ptr->next;

  Job_Master.num_jobs--;
  unlock(&Job_Master.lock);
  return;
}
 
/*==================================================================*/
/* delete_job() : This function frees up space allocated for a job. */
/*                                                                  */
/* Arguments:                                                       */
/*     job_t  *job_ptr                                              */
/*==================================================================*/

void delete_job(job_t *job_ptr)
{
  int   i;

  if (R_Log)
    tprintf("R: Freeing Resources for Job(%s) %d\n",
            job_ptr->job_id,
            job_ptr->num_requests);

  for (i=0; i<job_ptr->num_requests; i++)
  {
    if (job_ptr->request_list[i].hpss_file_name)
      free(job_ptr->request_list[i].hpss_file_name);

    if (job_ptr->request_list[i].destination_file_name)
      free(job_ptr->request_list[i].destination_file_name);
  }

  if (job_ptr->request_list)
    free(job_ptr->request_list);

  free(job_ptr);
  return;
}

/*====================================================================================*/
/* update_progress() : This function is in its own thread. It wakes up to call the    */
/*                     function that updates the record of the current working jobs   */
/*                     in the filesystem. Kindof a primative transaction log.         */
/*                                                                                    */
/* Externals:                                                                         */
/*     job_queue_t         Job_Master                                                 */
/*     pthread_mutex_t     Update_Interval                                            */
/*====================================================================================*/
 
void update_progress()
{
  job_t   *job_ptr;

  /* Loop forever looking at the job queue to write to the working directory. */
  while (TRUE)
  {
/*  082206 dyu moved bu_unlock_purge_locked_files() to a separated thread.
    bu_unlock_purge_locked_files();  */
    bu_purge_trans_log();  /* Will purge the old transaction log if needed */

    lock(&Update_Lock);
    lock(&Job_Master.lock);
 
    job_ptr = Job_Master.head;
 
    while (job_ptr)
    {
      update_working_file(job_ptr);
      job_ptr = job_ptr->next;
    }

    unlock(&Update_Lock);
    unlock(&Job_Master.lock);

    if (bu_get_cmd() > BATCH_CMD_KILL)
        sleep(Update_Interval.tv_sec);
    else
        break;
  }

  if (R_Log || Q_Log) tprintf("update_progress\n");
  /* Never get here */
  kill_thread("update_progress");
}

void PurgeLockMonitor()
{
    while (1) {
	bu_unlock_purge_locked_files();
        if (bu_get_cmd() > BATCH_CMD_KILL)
            sleep(batch_str.purlock_life * ONE_HOUR);
        else
            break;
        sleep(60);
    }
    if (R_Log || Q_Log) tprintf("PurgeLockMonitor stopped\n");
    kill_thread("PurgeLockMonitor");
}

/*=======================================================================================*/
/* get_new_work() : This function is in its own thread. It wakes up to look at the input */
/*                  directory for more batch jobs to process.                            */
/*                                                                                       */
/* Externals:                                                                            */
/*     job_queue_t       Job_Master                                                      */
/*     struct timespec   Input_Interval                                                  */
/*=======================================================================================*/

void get_new_work()
{
  DIR            *dir_ptr;
  struct dirent  *entry;
  char            filename[MAXPATHLEN];
  job_t          *job_ptr;
  pthread_t       tid;

  while (TRUE)
  {
    /* Open up the input directory. Should never fail since we already tested access to it. */

    dir_ptr = opendir(Config.input_dir);

    if (dir_ptr == (DIR *)NULL)
    {
      dtprintf(HERE,"ERROR: Cannot open input directory: %d\n",errno);
      exit(1);
    } 
 
    /* Now read entries until exhausted. We ignore anything with a leading '.', that  */
    /* includes '.', and '..' plus anything else we or the user puts in with a leading*/
    /* '.'.                                                                           */

    while ((entry = readdir(dir_ptr)) != (struct dirent *)NULL)
    {
      if (entry->d_name[0] == '.')
        continue;

      /* Build complete path name for file */
      sprintf(filename,"%s/%s",Config.input_dir,entry->d_name);
/*
printf("batch: get_new_work: filename = %s\n", filename);
*/

      /* Test to see if the file is accessable. */

      if (access(filename,R_OK | W_OK))
      {
        tprintf("batch: get_new_work: WARNING: Access invalid to (%s), skipping\n", filename);
        move_bad_file(filename,entry->d_name);
      }
      else
      {
        /* Now try to load the file's contents into a job-request list. If this works, */
        /* then move it to the working directory and activate it.                      */

/*
printf("batch: get_new_work: before process_file\n");
*/
        job_ptr = process_file(filename,entry->d_name,TRUE);
 
        if (job_ptr)
        {
          insert_job(job_ptr);
          lock(&Update_Lock);
          update_working_file(job_ptr);
          unlock(&Update_Lock);
          unlink(filename);
           if ( ! spawn_thread_managed(&tid,queue_job,job_ptr,"queue_job") ){
              /* JL 2005/12 - We need to get out of this one                          */
              exit(-1);
           }
        }
        else
        {
          move_bad_file(filename,entry->d_name);
        }
      }
    }
 
    closedir(dir_ptr);
    if (bu_get_cmd() > BATCH_CMD_KILL)
        sleep(Input_Interval.tv_sec);
    else
        break;
  }
  if (R_Log || Q_Log) tprintf("Stop get_new_work\n");
  kill_thread("get_new_work");
  /* Never Exit */
}

/*========================================================================================*/
/* update_working_file() : The function does the work of updating the working copy of the */
/*                         job.                                                           */
/*                                                                                        */
/* Arguments:                                                                             */
/*     job_t   *job_ptr                                                                   */
/*                                                                                        */
/* Externals:                                                                             */
/*     config_t          Config                                                           */
/*     pthread_mutex_t   Update_Lock                                                      */
/*========================================================================================*/

void update_working_file(job_t *job_ptr)  /* In - Pointer to job-request list */
{
  int         i;
  FILE       *fp_file;
  request_t  *req_ptr;
  char        tmp_name[MAXPATHLEN];
  char        filename[MAXPATHLEN];
  char        exp_str[16];
  char        pri_str[16];

  /* Build the tmp and real name of the file */
  sprintf(tmp_name, "%s/.%s", Config.working_dir, job_ptr->job_id);
  sprintf(filename, "%s/%s",  Config.working_dir, job_ptr->job_id);
 
  if ((fp_file = fopen(tmp_name,"w")) == (FILE *)NULL)
  {
    dtprintf(HERE,"ERROR: fopen(%s) failed: %d\n",tmp_name,errno);
    exit(1);
  }

  /* Now start writing the information to the tmp file. */
 
  fprintf(fp_file, "%s %s %s %s\n", 
                   job_ptr->notify_email,
                   job_ptr->hpss_id_str,
                   job_ptr->local_id_str,
                   job_ptr->output_file);

  for (i=0; i<job_ptr->num_requests; i++)
  {
    req_ptr = &(job_ptr->request_list[i]);

    if (req_ptr->exp_minute > 0) {
        sprintf(exp_str, " T%d", req_ptr->exp_minute);
    }
    else
        exp_str[0] = '\0';

    if (req_ptr->priority > 0) {
        switch (req_ptr->priority) {
        case PRIORITY_MEDIUM:
            sprintf(pri_str, " PM");
            break;
        case PRIORITY_HIGH:
            sprintf(pri_str, " PH");
            break;
        }
    }
    else
        pri_str[0] = '\0';


    fprintf(fp_file, "%s %s %d %d %d%s%s\n",
                     req_ptr->hpss_file_name,
                     req_ptr->destination_file_name,
                     req_ptr->state,
                     req_ptr->tries,
                     req_ptr->error_code,
                     exp_str,
                     pri_str);
  }
 
  fclose(fp_file);

  /* Finally, replace the old working copy with the new one */
  
  if (rename(tmp_name,filename) < 0)
  {
    dtprintf(HERE,"ERROR: rename(%s,%s) failed: %d\n", tmp_name,filename,errno);
    exit(1);
  }

  return;
}

/*=======================================================================================*/
/* finalize_working_file() : The function writes out the final disposition of the job    */
/*                           list. The file is placed in the output directory for the    */
/*                           submitter to pick up.                                       */
/*                                                                                       */ 
/* Arguments:                                                                            */
/*     job_t   *job_ptr                                                                  */
/*                                                                                       */
/* Externals:                                                                            */
/*     config_t          Config                                                          */
/*     pthread_mutex_t   Update_Lock                                                     */
/*                                                                                       */
/* Assumptions:                                                                          */
/*    Output directory is writable, should already be checked.                           */
/*=======================================================================================*/

void finalize_working_file(job_t *job_ptr)    /* In - Pointer to job-request list */
{
  int         i;
  FILE       *fp_file;
  request_t  *req_ptr;
  char        tmp_name[MAXPATHLEN];
  char        filename[MAXPATHLEN];
  char        old_name[MAXPATHLEN];
  char        state_str[16];
  char        buffer[4096];
 
  /* Create references to the original file, tmp file, and final output file. */

  sprintf(old_name,"%s/%s", Config.working_dir,job_ptr->job_id);
  sprintf(tmp_name,"%s/.%s",Config.working_dir,job_ptr->job_id);
  sprintf(filename,"%s/%s", Config.output_dir, job_ptr->job_id);
 
  /* Open up the tmp filename */

  if ((fp_file = fopen(tmp_name,"w")) == (FILE *)NULL)
  {
    dtprintf(HERE,"ERROR:fopen(%s) failed: %d\n", tmp_name, errno);
    exit(1);
  }

  /* File the new file with the status of each file transaction */

  fprintf(fp_file, "%s %s %s %s\n",
                   job_ptr->notify_email,
                   job_ptr->hpss_id_str,
                   job_ptr->local_id_str,
                   job_ptr->output_file);

  for (i=0; i<job_ptr->num_requests; i++)
  {
    req_ptr = &(job_ptr->request_list[i]);

    if (req_ptr->state == COPIED)
      strcpy(state_str, "COMPLETE");
    else
    if (req_ptr->state == FAILED)
      strcpy(state_str, "FAILED");
    else
      sprintf(state_str, "UNKNOWN(%d)", req_ptr->state);
 
    fprintf(fp_file, "%s %s %s %d %d\n",
                     req_ptr->hpss_file_name,
                     req_ptr->destination_file_name,
                     state_str,
                     req_ptr->tries,
                     req_ptr->error_code);
  }
 
  fclose(fp_file);

  /* Now rename the tmp name to the final output name. */

  if (rename(tmp_name,filename) < 0)
  {
    dtprintf(HERE,"ERROR: rename(%s,%s) failed: %d\n", tmp_name, filename, errno);
    exit(1);
  }

  /* Clean up the working directory so no reference exists of the job during a restart. */

  unlink(old_name);

  /* Now try to move the output file tothe user's path. If it fails (because of bad */
  /* protection, whatever) the file remains in the output directory and the HPSS    */
  /* admin can retrieve it.                                                         */

  if (check_file_access(job_ptr->output_file,job_ptr->local_uid,job_ptr->local_gid) == FALSE)
  {
    dtprintf(HERE,"WARNING: Unable to move file(%s -> %s to user area\n",
                  filename,
                  job_ptr->output_file);
  }
  else
  {
    sprintf(buffer,"/bin/mv %s %s", filename, job_ptr->output_file);
    system(buffer);

    if (chown(job_ptr->output_file,job_ptr->local_uid,job_ptr->local_gid) < 0)
    {
      dtprintf(HERE, "ERROR: chown(%s) failed: %d\n",
                     job_ptr->output_file, errno);
    }
  }

  return;
}

/*=======================================================================================*/
/* do_work() : Heart of the request processing. The function wakes up to check the       */
/*             status of its jobs and starts the processing steps for each request based */
/*             upon its current state.                                                   */
/*                                                                                       */
/* Externals:                                                                            */
/*     job_queue_t         Job_Master                                                    */
/*     struct timespec     Work_Interval                                                 */
/*     int                 errno                                                         */
/*     int                 R_Log                                                         */
/*                                                                                       */
/* Assumptions:                                                                          */
/*     Must only have one copy of this function running. This routine is not protected   */
/*     from multiple times.                                                              */
/*=======================================================================================*/

void do_work()
{
  pthread_t    tid;
  request_t   *request_ptr;
  job_t       *job_ptr;
  job_t       *next_job;
  int          requests;
  int          rc;
  time_t       now;

  /* We loop forever looking for active jobs and submit copy requests when the file */
  /* has been staged.                                                               */

  while ((exit_status = bu_get_cmd()) > BATCH_CMD_KILL)
  {
    /* Go to sleep if nothing much is going on */

    if (Job_Master.num_jobs == 0)
    {
      if (R_Log)
        tprintf("R: No Active Jobs\n");

//      bu_update_status(BATCH_IDEL);
      sleep(NoWork_Interval.tv_sec);
      continue;
    }

    if (R_Log)
      tprintf("R: Number of Active Jobs %d\n", Job_Master.num_jobs);

    /* Actually start rolling through the jobs */
    
    job_ptr = Job_Master.head;

    while (job_ptr)
    {
      // bu_update_status(BATCH_BUSY);
      if (R_Log)
        tprintf("R: Job(%s) Active, Requested %d, Processed %d, Failed %d\n",
                job_ptr->job_id,
                job_ptr->num_requests,
                job_ptr->num_processed,
                job_ptr->num_failed);
  
      /* Now get the current time and compare with the start time of the job. */
      /* Probably need to add something here to retry queueing the file. No   */
      /* easy way to remove a job once queued, but maybe someone should go to */
      /* that effort.                                                         */
  
      if (job_ptr->warned == FALSE)
      {
        now = time((time_t *)NULL);

        if ((now - job_ptr->start_time) > MAX_JOBTIME)
        {
          warn("R: WARNING: Job(%s), active for %d seconds\n",
               job_ptr->job_id,
               now - job_ptr->start_time);
          job_ptr->warned = TRUE;
        }
      }

      /* Loop through each request in the job queue */
 
      for (requests=0; requests < job_ptr->num_requests; requests++)
      {
        request_ptr = &(job_ptr->request_list[requests]);

        /* If the state is staged, then move to pending. Pending is used  */
        /* to make sure we dont have too many files actually being copied */
        /* at one time.                                                   */
 
        if (request_ptr->state == STAGED) {
          request_ptr->state = PENDING;
          bu_log(BATCHLOG_PENDING, 0, request_ptr->hpss_file_name, NULL, 0, 0, NULL, 0, 0, request_ptr->job_ptr->job_id, 0, 0, 0);
          bu_files_pending_incr();
        }

        /* Here is the throttling mechanism to limit the number of threads */
        /* copying files to local space.                                   */

        if (request_ptr->state == PENDING)
        {
          lock(&Copies_Lock);
   
          if (Copies_In_Progress < batch_str.copy_thread)
          {
            Copies_In_Progress++;
            bu_files_pending_decr();
            request_ptr->state = COPYING;
            spawn_thread(&tid,do_copy,request_ptr,"do_copy");
          }
  
          unlock(&Copies_Lock);
        }
      } /* for */

      /* Save the pointer to the next job. Then look at the number of processed */
      /* files (COPIED + FAILED) to determine if a job is complete. Load our    */
      /* saved pointer back to the rover pointer.                               */

      next_job = job_ptr->next;

      if (job_ptr->num_processed >= job_ptr->num_requests)
        complete_job(job_ptr);

      job_ptr = next_job;
    } /* while job_ptr */
 
    /* Let others have a chance to play as well. If no copy jobs seem to be */
    /* out there, then we assume that nothing much needs doing. We take a   */
    /* longer break so we dont tie up the CPU. If it looks copy jobs are in */
    /* demond, then just take a quick break.                                */

    if (bu_get_cmd() > BATCH_CMD_KILL)
        sleep(Work_Interval.tv_sec);
  }
  
  bu_terminate();
  if (R_Log || Q_Log)
  {
    tprintf("R:\tReady Shutdown\n");
  }
}
 
/*===============================================================================*/
/* complete_job(): All files for a job have been copied to user space. This      */
/*                 function reports the files' status back to the user and       */
/*                 cleans up the work area for this job. Deleting resources, etc.*/
/*                                                                               */
/* Arguments:                                                                    */
/*     job_t    *job_ptr                                                         */
/*                                                                               */
/* Externals:                                                                    */
/*     job_queue_t     Job_Master                                                */
/*     int             errno                                                     */
/*     int             R_Log                                                     */
/*===============================================================================*/

void complete_job(job_t *job_ptr)  /* In - Pointer to job-request list */
{
  time_t    now;
  char      msg[1024], s64_str[32];

  /* get the current time to determine the amount of time this job took to */
  /* fulfill the request.                                                  */

  now = time((time_t *)NULL);
  u64_to_decchar(job_ptr->bytes_moved,s64_str);

  sprintf(msg,"\tJob(%s) is complete\n\t# of Requests %d\n\t# of Failures %d\n\tBytes Staged %s\n\tCompletion Time %d\n",
               job_ptr->job_id,                               
               job_ptr->num_requests,
               job_ptr->num_failed,
               s64_str,
               now - job_ptr->start_time);

/*
  notify(job_ptr->notify_email,msg);
*/

  if (R_Log)
  {
    tprintf("R:\tJob(%s) is complete\n", job_ptr->job_id);
    tprintf("R:\t# of Requests: %d\n",   job_ptr->num_requests);
    tprintf("R:\t# of Failures: %d\n",   job_ptr->num_failed);
    tprintf("R:\tBytes Moved: %s\n",     s64_str);
    tprintf("R:\tCompletion Time: %d\n", now - job_ptr->start_time);
  }
 
  /* Now set things up to remove the job from our list. Place a copy of the */
  /* status in the output directory.                                        */
 
  lock(&Update_Lock);
  finalize_working_file(job_ptr);
  remove_job(job_ptr);
  unlock(&Update_Lock);
  delete_job(job_ptr);

  return;
}

/*============================================================================*/
/* stage_function(): This is the function that is passed to the queueing code */
/*                   to execute when a stage is complete.                     */
/*                                                                            */
/* Arguments:                                                                 */
/*     request_t    *request_ptr                                              */
/*     int           error_code                                               */
/*============================================================================*/
 
void stage_function(request_t   *request_ptr,  /* In - Pointer to request    */
                    int          error_code)   /* In - Error code from queue */
{
  /* If the stage failed (indicated by error_code != 0) then update the */
  /* state information and marked it failed.                            */

  if (error_code)
  {
    request_ptr->state      = FAILED;
    request_ptr->error_code = error_code;
    request_ptr->job_ptr->num_processed++;
    request_ptr->job_ptr->num_failed++;
  }
  else
  {
    /* Otherwise, the file is ready for additional processing */
    request_ptr->state      = STAGED;
    request_ptr->error_code = 0;
  }

  return;
}

/*===========================================================================*/
/* do_copy(): The function in its own thread will attempt to copy the given  */
/*            file to the local destination.                                 */
/*                                                                           */
/* Arguments:                                                                */
/*     request_t  *request_ptr                                               */
/*===========================================================================*/

void do_copy(request_t *request_ptr)  /* In - Pointer to request */
{
  int   rc, rc2;          
  int   slot = 0;

  char  command[1023]; /* 03/11/02 GMT Believe also added by TGT for the init_move.pl script */
 
  /* 6/22/01 TGT Add next three lines to get file size for PHENIX */
  u_signed64       size64;
  hpss_fileattr_t  attr;
  char             obj_str[64];

  /* Find a free buffer */
 
  lock(&Buffer_Lock);
 
  while (Buffer_Usage[slot])
    slot++;

  if (slot >= MAX_COPIES)
  {
    dtprintf(HERE, "INTERNAL ERROR: Should never happen\n");
    exit(1);
  }

  Buffer_Usage[slot] = TRUE;

  if (R_Log)
    tprintf("R: Memory slot = %d taken\n", slot);

  unlock(&Buffer_Lock);

  sprintf(command,"%s %s %s",
		Config.transfer_script,
                request_ptr->hpss_file_name,
                request_ptr->destination_file_name);

        bu_log(BATCHLOG_COPYING, 0, request_ptr->hpss_file_name, NULL, 0, 0, NULL, 0, 0, request_ptr->job_ptr->job_id, 0, 0, 0);
        bu_files_copying_incr();

        rc = system(command);
        rc2 = rc/256;

        if (rc2 == 0)
            tprintf("File [%s] delivered.\n", request_ptr->hpss_file_name);
        else
            tprintf("File [%s] delivery failed, rc = %d, errcode = %d\n", request_ptr->hpss_file_name, rc2, errno);

        bu_log(BATCHLOG_COMPLETED, 0, request_ptr->hpss_file_name, NULL, 0, rc2, NULL, 0, 0, request_ptr->job_ptr->job_id, 0, 0, 0);
        bu_files_copying_decr();

  /*  End of TGT's chagne */

  if (R_Log)
    tprintf("R: Memory slot = %d free\n", slot);

  Buffer_Usage[slot] = FALSE;

  if (rc != 0)
  {
    request_ptr->error_code = errno;
    request_ptr->state      = FAILED;
    request_ptr->job_ptr->num_failed++;
  }
  else                                     /* Otherwise, mark copied which means everything */
  {                                        /* is done for this file.                        */
    request_ptr->state = COPIED;
  }

  request_ptr->job_ptr->num_processed++;

  /* Decrement the thread count for other copies to take place. */
  lock(&Copies_Lock);
  Copies_In_Progress--;
  unlock(&Copies_Lock);

  kill_thread("do_copy");
}
 
/*==================================================================================*/
/* copy_file(): Actually perform the copy of the file from HPSS to local user space */
/*                                                                                  */
/* Arguments:                                                                       */
/*   request_t   *request_ptr                                                       */
/*   int          slot                                                              */
/*                                                                                  */
/* Externals:                                                                       */
/*   int          errno (if error occurs)                                           */
/*                                                                                  */
/* Return Values:                                                                   */
/*   Status of transfer, rc = 0 means successful.                                   */
/*==================================================================================*/

int copy_file( request_t *request_ptr, int slot)
{
  int       fd = -1;
  int       hfd = -1;
  int       rc;
  int       len;

  double    start;
  double    elapsed;
  double    double_time();

  char     *buf;

  u_signed64       size64;
  u_signed64       count64;

  hpss_fileattr_t  attr;
  struct stat      stat_buf;

  buf = Buffer[slot];

  /* First determine if user has the right to create the local file */

  if (!check_file_access(request_ptr->destination_file_name,
                         request_ptr->job_ptr->local_uid,
                         request_ptr->job_ptr->local_gid))
  {
    dtprintf(HERE, "ERROR: User(%s) cannot create(%s): %d\n",
                     request_ptr->job_ptr->local_id_str,
                     request_ptr->destination_file_name, errno);
    bu_log(BATCHLOG_DROPPED, time((time_t) NULL), request_ptr->destination_file_name, NULL, 0, -errno, "Cannot create", 0, 0, NULL, 0, 0, 0);

    goto error;
  }
  
  /* Open the HPSS source file */
  hfd = hpss_Open(request_ptr->hpss_file_name, O_RDONLY, 0, NULL, NULL, NULL);

  if (hfd < 0)
  {
    dtprintf(HERE, "ERROR: hpss_Open(%s) failed: %d\n", request_ptr->hpss_file_name, hfd);
    bu_log(BATCHLOG_DROPPED, time((time_t) NULL), request_ptr->hpss_file_name, NULL, 0, HPSS_API_FAILED, "hpss_Open()", 0, 0, NULL, 0, 0, 0);
    goto error;
  }

  /* Go create the local file. */
 
  fd = creat(request_ptr->destination_file_name, DMASK);

  if (fd < 0)
  {
    dtprintf(HERE, "ERROR: creat(%s) failed: %d\n", request_ptr->destination_file_name,errno);
    bu_log(BATCHLOG_DROPPED, time((time_t) NULL), request_ptr->destination_file_name, NULL, 0, -errno, "Failed to create file", 0, 0, NULL, 0, 0, 0);
    goto error;
  }

  /* Change the id of the local file to that of the user */

  if (chown(request_ptr->destination_file_name,
            request_ptr->job_ptr->local_uid,
            request_ptr->job_ptr->local_gid) < 0)
  {
    dtprintf(HERE, "ERROR: chown(%s) failed: %d\n",request_ptr->destination_file_name,errno);
    bu_log(BATCHLOG_DROPPED, time((time_t) NULL), request_ptr->destination_file_name, NULL, 0, -errno, "chown() failed", 0, 0, NULL, 0, 0, 0);
    goto error;
  }

  /* Get the length of the file. */
 
  if ((rc = hpss_FileGetAttributes(request_ptr->hpss_file_name, &attr)) < 0)
  {
    dtprintf(HERE, "ERROR: hpss_FileGetAttributes(%s) failed: %d\n",request_ptr->hpss_file_name,errno);
    bu_log(BATCHLOG_DROPPED, time((time_t) NULL), request_ptr->hpss_file_name, NULL, 0, -errno, "hpss_FileGetAttributes()", 0, 0, NULL, 0, 0, 0);
    goto error;
  }

  size64 = attr.Attrs.DataLength;

  /* loop through the source files */
  count64 = cast64m(0);
  start = double_time();
  
  /* Loop until the file is transfered */
 
  while (lt64m(count64, size64))
  {
    /* read in the next chunk of data */

    len = hpss_Read(hfd, buf, BUFSIZE);

    if (len <= 0)
    {
      dtprintf(HERE, "ERROR: hpss_Read() failed: %d\n", len);
      bu_log(BATCHLOG_DROPPED, time((time_t) NULL), request_ptr->hpss_file_name, NULL, 0, -HPSS_API_FAILED, "hpss_Read()", 0, 0, NULL, 0, 0, 0);
      goto error;
    }

    /* Write the data to local file. */
    rc = write(fd, buf, len);

    if (rc != len)
    {
      dtprintf(HERE, "ERROR: write() failed: %d\n", errno);
      bu_log(BATCHLOG_DROPPED, time((time_t) NULL), request_ptr->destination_file_name, NULL, 0, -EACCES, "write()", 0, 0, NULL, 0, 0, 0);
      goto error;
    }

    count64 = add64m(count64, cast64m(len));
  }

  close(fd);
  hpss_Close(hfd);

  /* If logging is on, record the transfer speed of the copy. */

  if (R_Log)
  {
    char        s64_str[64];

    u64_to_decchar(count64, s64_str);
    elapsed = double_time() - start;

    tprintf("R: File %s: transfered %s bytes in %.3f seconds\n",
                    request_ptr->hpss_file_name, s64_str, elapsed);
  }

  request_ptr->job_ptr->bytes_moved = add64m(request_ptr->job_ptr->bytes_moved, count64);
  return(0);

  /* Gotos are bad.  We use one here anyway because of logic flow */

error:
  if (fd >= 0) close(fd);
  if (hfd >= 0) hpss_Close(hfd);
  return(-1);
}

/*==============================================================================*/
/* check_file_access() : See if a user has access to a given file or can create */
/*                       the file.                                              */
/*                                                                              */
/* Arguments:                                                                   */
/*     char    file                                                             */
/*     int     uid                                                              */
/*     int     gid                                                              */
/*                                                                              */
/* Externals:                                                                   */
/*     int     errno (if error occurs)                                          */
/*                                                                              */
/* Return Values:                                                               */
/*     TRUE if user has access, FALSE otherwise                                 */
/*==============================================================================*/
 
boolean_t check_file_access( char  *file, /* In - Name of path to check            */
                           int    uid,  /* In - User id to check access against  */
                           int    gid)  /* In - Group id to check access against */
{
  char          tmp_name[MAXPATHLEN+1];
  char         *ptr;
  struct stat   stat_buf;

  /* Test for an existing file versus one we are creating */

  strcpy(tmp_name,file);

  if (access(tmp_name,F_OK) == 0)  /* File exists */
  {
    /* now get information about it. */
    
    if (stat(tmp_name,&stat_buf) < 0)
    {
      dtprintf(HERE,"ERROR: stat(%s) failed: %d\n",tmp_name);
      errno = EIO;
      return(FALSE);   /* Should never happen */
    }

    /* See if the file is truely a "file", not a directory or symbolic link. */
    
    if ((stat_buf.st_mode & S_IFMT) != S_IFREG)
    {
      errno = EISDIR;
      return(FALSE);
    }

    /* Depending upon ownership, check permissions */

    if (stat_buf.st_uid ==uid)
    {
      if (stat_buf.st_mode & S_IWUSR)
        return(TRUE);
    }
    else
    if (stat_buf.st_gid == gid)
    {
      if (stat_buf.st_mode & S_IWGRP) 
        return(TRUE);
    }
    else
    {
      if (stat_buf.st_mode & S_IWOTH)
        return(TRUE);
    }

    /* Must not have access to the file */
    errno = EACCES;
  }
  else                  /* File doesnt yet exist */
  {
    /* check to see if directory allows us write here */
    ptr = strrchr(tmp_name,'/');

    if (ptr)
      *ptr = '\0';

    if (stat(tmp_name,&stat_buf) < 0)
    {
      errno = EIO;
      return(FALSE);      /* Should never happen */
    }

    /* If this is true, then the path is bogus. Return "no such file or */
    /* directory.                                                       */

    if ((stat_buf.st_mode & S_IFMT) != S_IFDIR)
    {
      errno = ENOENT;
      return(FALSE);
    }
 
    /* Depending upon ownership, check permissions */
    
    if (stat_buf.st_uid == uid)
    {
      if (stat_buf.st_mode & S_IWUSR)
        return(TRUE);
    }
    else
    if (stat_buf.st_gid == gid)
    {
      if (stat_buf.st_mode & S_IWGRP)
        return(TRUE);
    }
    else
    {
      if (stat_buf.st_mode & S_IWOTH) 
        return(TRUE);
    }
 
    /* Must not have access to the file */
    errno = EACCES;
  }

  return(FALSE);
}
 
/*================================================================================*/
/* queue_job(): Submit a list of files in an individual job to the queueing code. */
/*              This was put into a separate thread since long jobs were blocking */
/*              out other jobs already running.                                   */
/*                                                                                */
/* Arguments:                                                                     */
/*     job_t   *job_ptr                                                           */
/*                                                                                */
/* Externals:                                                                     */
/*     int      errno                                                             */
/*================================================================================*/

void queue_job(job_t *job_ptr)
{
  pthread_t      tid;
  request_t     *request_ptr;
  int            requests;
  int            rc;

  /* Make sure this thread is set to the correct user */

  /* Loop through each request in the job queue */

  if (Q_Log || R_Log)
        tprintf("Queuing Job (%s): %d requests\n", job_ptr->job_id, job_ptr->num_requests);
      
  for (requests=0; requests<job_ptr->num_requests; requests++)
  {
    request_ptr = &(job_ptr->request_list[requests]);

    /* New or Retry requests need to be queued up */
    
    if ((request_ptr->state == NEW) || (request_ptr->state == RETRY))
    {
      rc = hpss_QueueFileX(request_ptr->hpss_file_name,
                           request_ptr->priority,
                           (void (*)(void *))stage_function,
                           (void *)request_ptr);

      /* If on disk, then no staging actually needed. Other positive rc values */
      /* mean the file in the queue or currently be staged.                    */
 
      if (rc == FILE_DISK) {
        request_ptr->state = STAGED;
        request_ptr->error_code = 0;
        if (Q_Log || R_Log)
            tprintf("Request (%s:%s) is already on disk\n", request_ptr->job_ptr->job_id, request_ptr->hpss_file_name);
      }
      else
      if (rc > 0) {
        request_ptr->state = QUEUED;
        if (Q_Log || R_Log)
            tprintf("Request (%s:%s) is queued\n", request_ptr->job_ptr->job_id, request_ptr->hpss_file_name);
      }
      else
      {
        /* Oops, something wrong so record the error and change the state to failed */ 
        request_ptr->state = FAILED;
        tprintf("hpss_QueueFileX(%s) failed: rc = %d\n", request_ptr->hpss_file_name, rc);
        request_ptr->error_code = rc;
        job_ptr->num_processed++;
        job_ptr->num_failed++;
      }
    }
  }
 
  kill_thread("queue_job");
}

void init_debug_val()
{
  unsigned long val = DEBUG_NONE;

  if (R_Log)
     val |= DEBUG_RLOG;

  if (Q_Log)
     val |= DEBUG_QLOG;
#if 0
  val |= DEBUG_SQL;       /* Enable SQL debug */
  val |= DEBUG_SQLLOCK;   /* SQL related lock debug   */
#endif

  bu_update_debug_val(val);

}

