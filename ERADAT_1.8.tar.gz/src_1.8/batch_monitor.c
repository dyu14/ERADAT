#include <stdio.h>
#include <errno.h>

/* 022703 Grace added for TRUE */
#include "batch.h"

#include "nothread_utils.h"

/* Simple keep alive monitor program.  This is to watch the */
/* batch file process and make sure we keep it alive.       */

void main(int argc, char *argv[]) 
{
  int   pid;
  int   rc;
  int   exit_code;
  int   status;
 
  char  program[2048];

  _tprintf("Monitor program starting\n");

  while(TRUE)
  {
    
    _tprintf("Starting hpss_batch\n");
    pid = fork();

    if (pid == 0)
    {
/*
      execl("./hpss_batch", "./hpss_batch", "-r", "-q");
      execl("./hpss_batch", "./hpss_batch", NULL);
      execl("./hpss_batch", "./hpss_batch", "-Q 7", NULL);
*/
      execl("./hpss_batch", "./hpss_batch", argv[1], argv[2], argv[3], argv[4], argv[5], argv[6]);
      _dtprintf(HERE, "Trying to execute batch program failed: %d\n", errno);
      exit(1);
    } /* if pid == 0 */
    else
    if (pid < 0)
    {
      _dtprintf(HERE, "Unable to create procesed, fork failed: %d\n", errno);
      exit(1);
    }

    _tprintf("HPSS Batch File Processor Started, Pid = %d\n", pid);
    rc = wait(&status);
    exit_code=status / 256;
    printf("hpss_batch exit code: %d\n", exit_code);

    if (rc == pid)
    {
      _tprintf("Received Signal, Batch File Processor Died, exit_code = %d\n", exit_code);
    }
    else
    {
      _tprintf("Received Signal, Unknown Pid %d, exit_code = %d\n", rc, exit_code);
      exit(1);
    }

    if (exit_code == 1) {
        _tprintf("Shutdown batch_monitor\n");
        exit(1);
    }

    _tprintf("hpss_batch will be restated in 60 secs\n");
    sleep(60);
  } /* while TRUE */
}
